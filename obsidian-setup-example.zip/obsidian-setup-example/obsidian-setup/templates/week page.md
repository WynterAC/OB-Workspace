---
year: {{date:YYYY}}
week: {{date:W}}
tags:
  - Type/Week
---

# _Week {{date:W, YYYY}}_

## Goals 🎯

- [ ] 

```dataviewjs
await dv.view('obsidian-setup/view/diary')
```
