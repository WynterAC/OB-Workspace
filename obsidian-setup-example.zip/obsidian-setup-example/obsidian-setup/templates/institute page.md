---
aliases: 
  - "#Institute/<tag>"
tags:
  - Type/Institute
---

## Todo 🎯

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```