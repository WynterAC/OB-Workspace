---
aliases: []
tags:
  - Type/Paper
date: 2024-07-26
update: []
bib_link: []
bib_badge: []
bib_note: []
bib_remark: []
bib_pdf:
---

```dataviewjs
await dv.view('obsidian-setup/view/paper')
```