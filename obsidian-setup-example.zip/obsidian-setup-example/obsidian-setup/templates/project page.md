---
aliases:
  - "#Project/<name>"
tags:
  - Type/Project
---

## Todo 🎯

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```