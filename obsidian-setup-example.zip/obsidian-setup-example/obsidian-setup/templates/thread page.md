---
aliases: 
  - "#Thread/<tag>"
tags:
  - Type/Thread
max_depth: 
scroll: false
no_flow: false
no_list: false
no_bibtex: true
---

```dataviewjs
await dv.view('obsidian-setup/view/thread')
```

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```