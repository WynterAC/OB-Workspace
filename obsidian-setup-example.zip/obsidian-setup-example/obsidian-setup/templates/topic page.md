---
aliases:
  - "#Topic/<tag>"
tags: 
  - Type/Topic
---

## Todo 🎯

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```