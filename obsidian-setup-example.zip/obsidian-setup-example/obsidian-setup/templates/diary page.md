---
date: {{date:YYYY-MM-DD}}
tags:
  - Type/Diary
time_learn: 
time_deep: 
time_affair: 
time_dev: 
---

# _{{date:dddd, MMMM D, YYYY}}_

```dataviewjs
await dv.view('obsidian-setup/view/diary')
```

## Thoughts 💡
