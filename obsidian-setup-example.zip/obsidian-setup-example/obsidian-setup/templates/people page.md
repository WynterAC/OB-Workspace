---
aliases:
  - "#People/<tag>"
tags:
  - Type/People
email: 
phone: 
address: 
birthday: 
---

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```