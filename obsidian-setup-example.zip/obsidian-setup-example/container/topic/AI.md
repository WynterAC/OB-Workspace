---
aliases:
  - "#Topic/AI"
tags:
  - Type/Topic
---

## Todo 🎯

- [x] Read about AI
      [complete::2024-07-22]

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```