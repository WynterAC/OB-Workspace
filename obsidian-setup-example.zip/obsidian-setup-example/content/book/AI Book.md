---
tags:
  - Type/Book
author: 
---

This book is about [[AI]].

## Contents 📋

```dataviewjs
await dv.view('obsidian-setup/view/taglens')
```