---
tags:
  - Type/Note
  - Topic/AI
date: 2024-07-22
update:
---
AI is...