---
aliases: 
tags:
  - Type/Paper
  - Thread/AI/Application/Medical
date: 2024-07-26
update: 
bib_link:
  - "[[RumelhartDavid1986#MLP]]"
bib_badge:
  - read
  - insightful
bib_note:
  - footprint to pressure pred
  - simple mlp outperforms cnn
bib_remark:
  - patching to increase data samples
bib_pdf: 
bib_cites: 0
bib_type: article
bib_id: ZhangLiYing2024
bib_title: Prediction of Dynamic Plantar Pressure From Insole Intervention for Diabetic Patients Based on Patch-Based Multilayer Perceptron With Localization Embedding
bib_volume: 12
bib_issn: 2169-3536
bib_url: http://dx.doi.org/10.1109/ACCESS.2024.3425907
bib_doi: 10.1109/access.2024.3425907
bib_journal: IEEE Access
bib_publisher: Institute of Electrical and Electronics Engineers (IEEE)
bib_author: Zhang, Li-Ying and Ma, Ze-Qi and Yick, Kit-Lun and Li, Pui-Ling and Yip, Joanne and Ng, Sun-Pui and Liu, Qi-Long
bib_year: 2024
bib_pages: 100355–100365
---

```dataviewjs
await dv.view('obsidian-setup/view/paper')
```

