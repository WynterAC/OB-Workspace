---
alias:
  - MLP
tags:
  - Type/Paper
  - Thread/AI/Network
date: 2024-03-03
update: 
bib_link: 
bib_badge:
  - read
  - seminal
bib_note:
  - MLP w/ backprop
bib_remark: 
bib_cites: 16607
bib_pdf: "[[Learning representations by back-propagating errors.pdf]]"
bib_type: article
bib_id: RumelhartDavid1986
bib_title: Learning representations by back-propagating errors
bib_volume: 323
bib_issn: 1476-4687
bib_url: http://dx.doi.org/10.1038/323533a0
bib_doi: 10.1038/323533a0
bib_number: 6088
bib_journal: Nature
bib_publisher: Springer Science and Business Media LLC
bib_author: Rumelhart,  David E. and Hinton,  Geoffrey E. and Williams,  Ronald J.
bib_year: 1986
bib_month: 10
bib_pages: 533–536
---

The dawn of neural network.

```dataviewjs
await dv.view('obsidian-setup/view/paper')
```