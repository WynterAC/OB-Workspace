---
doi: https://doi.org/10.1109/ACCESS.2024.3425907
bibtex: 
cites:
---

```dataviewjs
await dv.view('obsidian-setup/view/doi2bib')
```