#Obsidian/plugin/dataview/DEBUG

```dataviewjs

console.log(dv);
dv.paragraph(dv.current());

```

<%-*
/*

# template

## meta~data

```dataviewfield
aliases     :: debug dataview
created     :: 2021-08-05T14:25:41-04:00
description :: evaluate [[software~Obsidian~plugin~dataview|Dataview]] `dv.current()` object with `dv.paragraph()` and `dv` object in console (`ctrl+shift+i`) as markdown list
publish     :: true
requires    :: dataview, templater-obsidian
scope       :: 
tags        :: #Obsidian/template/block/DEBUG, #Obsidian/plugin/dataview, #Obsidian/plugin/templater-obsidian
title       :: 📦 debug~plugin-dataview 🐛
type        :: template~block~debug~plugin~dataview
uuid        :: b8bf8b88-f755-4562-829a-61fbc085b961
version     :: 1
```

## meta~todo

## meta~notes

## meta~inbox

*/
_%>