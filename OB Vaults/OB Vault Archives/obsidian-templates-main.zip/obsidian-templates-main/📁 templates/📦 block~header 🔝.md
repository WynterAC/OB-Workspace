# `=this.metadata.title`

**`=this.metadata.description`**, modified: _`$=moment(dv.current().file.mtime.toString()).format('LLLL')`_

<%_*
/*
# template

## meta~data

```dataviewfield
aliases     :: header
created     :: 2021-08-05T20:17:54-04:00
description :: header (title, description, & modified) for templates
publish     :: true
requires    :: dataview, templater-obsidian
scope       :: 
tags        :: #Obsidian/template/block/header, #Obsidian/plugin/dataview, #Obsidian/plugin/templater-obsidian, javascript
title       :: 📦 header 🔝
type        :: template~block~header
uuid        :: d9c8150f-6d57-4820-9b31-67b8fdee8940
version     :: 1
```

## meta~todo

## meta~notes

## meta~inbox

*/
_%>
