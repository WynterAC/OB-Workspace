#Obsidian/plugin/templater-obsidian/DEBUG

```templater

<%*+ 
console.log(tp);
%>

```


<%-*
/*

# template

## meta~data

```dataviewfield
aliases     :: debug templater
created     :: 2021-08-05T14:27:11-04:00
description :: evaluate [[software~Obsidian~plugin~templater-obsidian|Templater]] `tp` object via [[software~obsidian#Console|Obsidian console]] (`ctrl+shift+i`)
publish     :: true
requires    :: templater-obsidian
scope       :: 
tags        :: #Obsidian/template/block/DEBUG, #Obsidian/plugin/templater-obsidian
title       :: 📦 debug~plugin~templater 🐛
type        :: template~block~debug~plugin~templater-obsidian
uuid        :: c36b9e3e-37bc-4f40-8ced-ad5636b160cf
version     :: 1
```

## meta~todo

## meta~notes

## meta~inbox

*/
_%>