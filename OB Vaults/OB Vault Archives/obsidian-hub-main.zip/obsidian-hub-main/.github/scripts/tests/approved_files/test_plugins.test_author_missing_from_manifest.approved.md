{
    "author": "Denis Olehov",
    "description": "Backup your vault with git.",
    "id": "obsidian-git",
    "isDesktopOnly": true,
    "js": "main.js",
    "mobile": "[[Desktop-only plugins|No]]",
    "name": "Obsidian Git",
    "repo": "denolehov/obsidian-git",
    "user": "denolehov",
    "version": "1.19.0"
}
