---
aliases:
- 
tags: 
- MOC
---

# 🗂️ Events

Overview of the various Events happening in the Obsidian Community.

## MOC

%% Hub MOCs: Don’t edit below  %%
-  [[01 - Community/Events/Gems of the Year 2021|Gems of the Year 2021]]
-  [[01 - Community/Events/Obsidian Community Coworking|Obsidian Community Coworking]]
-  [[01 - Community/Events/Obsidian Community Talks|Obsidian Community Talks]]
-  [[01 - Community/Events/Obsidian October 2021|Obsidian October 2021]]
%% Hub MOCs: Don’t edit above  %%

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/Events/%F0%9F%97%82%EF%B8%8F%20Events.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/Events/%F0%9F%97%82%EF%B8%8F%20Events.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
