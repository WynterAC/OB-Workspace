---
aliases:
- 
tags:
- MOC
publish: true
---

# 🗂️ Contributing to the Community

#placeholder/description 

## MOC

%% Hub MOCs: Don’t edit below  %%
-  [[01 - Community/Contributing to the Community/Plugins seeking help|Plugins seeking help]]
-  [[01 - Community/Contributing to the Community/Volunteer Plugin Doc Writers|Volunteer Plugin Doc Writers]]
%% Hub MOCs: Don’t edit above  %%

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/Contributing%20to%20the%20Community/%F0%9F%97%82%EF%B8%8F%20Contributing%20to%20the%20Community.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/Contributing%20to%20the%20Community/%F0%9F%97%82%EF%B8%8F%20Contributing%20to%20the%20Community.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
