---
aliases:
- Bob Doto
tags:
- seedling
publish: true
---

# TheHighPony

<!-- - GitHub: [TheHighPony](https://github.com/TheHighPony/) ^github-->
<!-- - Discord: `@` ^discord-->
- Website: <https://bobdoto.computer/> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish -->

%% Feel free to add a bio below this comment %%
A small excerpt taken from his website:

> Bob is an avid reader, note-taker, and [[Zettelkasten]] enthusiast who maintains a daily writing practice, usually working on three or more manuscripts at a time.
> He writes a weekly newsletter called [“The High Pony,”](https://mailchi.mp/8cc665f9d3f5/sign-up-for-the-newsletter) which covers creativity and productivity from a spiritual and socio-economic perspective.

## Author of

%% Begin Hub: Released contributions %%

<!--
### Plugins
-->

<!--
### Themes
-->

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

### Others

- [[Zettelkasten 101]]

<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: [Sponsor @TheHighPony on GitHub Sponsors](https://github.com/sponsors/TheHighPony) ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

<!--
## Follow this author
-->

<!-- - [[YouTube Channels|On YouTube]]: <https://> ^youtube-->
<!-- - Twitter: <https://> ^twitter-->
<!-- - ... -->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/TheHighPony.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/TheHighPony.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
