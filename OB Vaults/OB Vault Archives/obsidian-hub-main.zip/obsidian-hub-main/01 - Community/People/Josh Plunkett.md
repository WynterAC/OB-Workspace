---
aliases:
- Joshua Plunkett
- Sklore
- Sklex
tags: 
- 
publish: true
---

# Josh Plunkett


- Discord: `@sklore#8618` ^discord

## Author of
Tutorials for using Obsidian as a TTRPG Campaign Manager. 
- [YouTube](https://youtube.com/playlist?list=PLV5XWfKkFpk7MJTKv5YdSSpT9b-vLslWu)

## Community
- [Obsidian TTRPG Facebook Users Group](https://www.facebook.com/groups/obsidianttrpgusers)

## Sponsor this author
- [Patreon](https://www.patreon.com/JPlunkett)

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Josh%20Plunkett.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Josh%20Plunkett.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
