---
aliases:
- Dmitry Savosh
tags:
- 
publish: true
---

# Dmitry Savosh

- GitHub: [dy-sh](https://github.com/dy-sh/) ^github
<!-- - Discord: `@` ^discord-->
- Website: <https://github.com/dy-sh/> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%


## Author of

%% Begin Hub: Released contributions %%
### Plugins
- [[code-block-from-selection|Code block from selection]]
- [[remember-cursor-position|Remember cursor position]]
- [[consistent-attachments-and-links|Consistent attachments and links]]
- [[unique-attachments|Unique attachments]]
- [[find-and-replace-in-selection|Find and replace in selection]]

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->


### Others

- Playlist for [[Obsidian Training Course in Russian]]: https://youtube.com/playlist?list=PLrRc3UisLr6KVOYhzpSnywtHkCi2PEza5


<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: [Sponsor @dy-sh on GitHub Sponsors](https://github.com/sponsors/dy-sh) ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

## Follow this author

- [[YouTube Channels|On YouTube]]: [dy-sh's YouTube channel](https://www.youtube.com/c/dysh1) ^youtube
<!--
- Twitter: ^twitter
- ...
-->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/dy-sh.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/dy-sh.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
