---
aliases:
- 
tags:
- 
publish: true
---

# Mark McElroy

<!-- - GitHub: []() ^github -->
<!-- - Discord: `@` ^discord-->
- Website: <https://markmcelroy.com/> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->
 
Mark McElroy is a writer and adviser who helps people find their creative path.

## Author of

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

### Others
- Marc McElroy has written multiple blog posts on how he uses Obsidian on a daily basis to process his readings and thoughts as a knowledge worker: [All Roads Lead to… Obsidian?](https://markmcelroy.com/all-roads-lead-to-obsidian/)

<!--
## Sponsor this author
-->

<!-- - [[GitHub sponsors]]: []() ^github-sponsor-->
<!-- - [[Buy me a coffee]]: <https://> ^buy-me-a-coffee-->
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

## Follow this author

<!-- [[YouTube Channels|On YouTube]]: <> ^youtube -->
- Twitter: <https://twitter.com/markmcelroy> ^twitter
- Instagram: <https://www.instagram.com/markmcelroydotcom/>
- Facebook: <https://www.facebook.com/mark.mcelroy.378537>

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Mark%20McElroy.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Mark%20McElroy.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
