---
aliases: 
- Hugo Santos (Zektor)
tags:
- 
publish: true
---

# Zektor

GitHub: [Hugo Santos (Zektor)](https://github.com/llZektorll) ^github
%% Website:  ^website%% 
%%[[Publish sites|Publish site]]: ^publish%%
 
%% Feel free to add a bio below this comment %%


## Author of

%% Begin Hub: Released contributions %%
%%
### Plugins

- 

### Themes

- 
%%
%% End Hub: Released contributions %%  

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%


### Others

- [[OB_Template]]
- [[Template_Hub]]

### Auxilliary Tool
- [[DDC_Folder_Maker]]
- [[LCC_Folder_Maker]]


## Sponsor this author

- [PayPal](https://www.paypal.com/paypalme/llzektorll)
 
%%
- - [[GitHub sponsors]]: [Sponsor @Zektor on GitHub Sponsors](https://github.com/sponsors/llZektorll) ^github-sponsor
- [[Buy me a coffee]]: ^buy-me-a-coffee
- [[Patreon]]: ^patreon
%%

%%
## Follow this author

- [[YouTube Channels|YouTube channel]]: ^youtube

- ...
%%

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Zektor.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Zektor.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
