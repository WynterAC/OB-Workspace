---
aliases:
- Luke
- apfelstrudelig
tags:
- 
publish: true
---

# Luke

- GitHub: [lguenth](https://github.com/lguenth/) ^github
- Discord: `@apfelstrudelig#1337` ^discord
<!-- - Website: <https://> ^website-->
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%
Luke is a maintainer of the Hub. Feel free to ask him questions regarding Obsidian or anything else that's on your mind whenever you see him around on the [[🗂️ 01 - Community|Discord server]].

## Author of

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

### Others
- [mdbible](https://github.com/lguenth/mdbible): A JSON-to-Markdown converter for [Javascripture's](https://javascripture.org/) ESV Bible.

## Sponsor this author

<!-- - [[GitHub sponsors]]: []() ^github-sponsor-->
- [[Buy me a coffee]]: <https://ko-fi.com/lguenth> ^buy-me-a-coffee
<!-- - [[PayPal]]: <https://> ^paypal-->
<!-- - [[Patreon]]: <https://> ^patreon-->

<!--
## Follow this author
-->

<!-- - [[YouTube Channels|On YouTube]]: <https://> ^youtube-->
<!-- - Twitter: <https://> ^twitter-->
<!-- - ... -->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/lguenth.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/lguenth.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
