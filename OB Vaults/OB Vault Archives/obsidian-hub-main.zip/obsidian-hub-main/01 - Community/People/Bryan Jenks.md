---
aliases:
- 
tags:
- seedling
publish: true
---

# Bryan Jenks

- GitHub: [Bryan Jenks](https://github.com/tallguyjenks/) ^github
- Discord: `@tallguyjenks` ^discord
- Website: <https://www.bryanjenks.dev> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%


## Author of

%% Begin Hub: Released contributions %%

<!--
### Plugins
-->

<!--
### Themes
-->

%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

### Others

- YouTube list: [Personal Knowledge Management & Zettelkasten](https://www.youtube.com/playlist?list=PL5fd4SsfvECy0zzf8Cyo20ZoipEt6YeL3)

## Sponsor this author

- [[GitHub sponsors]]: [Sponsor @tallguyjenks on GitHub Sponsors](https://github.com/sponsors/tallguyjenks) ^github-sponsor

<!--
- [[Buy me a coffee]]: ^buy-me-a-coffee
- [[PayPal]]: ^paypal
- [[Patreon]]: ^patreon

-->

## Follow this author

- [[YouTube Channels|On YouTube]]: [Bryan Jenks's YouTube account](https://www.youtube.com/c/BryanJenksTech) ^youtube
- Twitter: [@tallguyjenks](https://twitter.com/tallguyjenks) ^twitter

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/Bryan%20Jenks.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/Bryan%20Jenks.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
