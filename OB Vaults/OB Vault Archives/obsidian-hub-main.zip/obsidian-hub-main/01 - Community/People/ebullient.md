---
aliases:
- Erin Schnabel
tags:
- 
publish: true
---

# Erin Schnabel (ebullient)

- GitHub: [ebullient](https://github.com/ebullient/) ^github
- Discord: `@ebullient#3764` ^discord
- Website: <https://github.com/ebullient> ^website
<!-- - [[Publish sites|Publish site]]: <https://> ^publish-->

%% Feel free to add a bio below this comment %%

- ⚡ [ebullient](https://www.merriam-webster.com/dictionary/ebullient) is a word, and all of its definitions apply to me.
- I enjoy [making](https://github.com/quarkusio/quarkus) [things](https://github.com/quarkiverse/quarkus-micrometer-registry), [especially](https://github.com/ebullient/monster-combat) [ridiculous](https://github.com/ebullient/fc5-convert-cli) [things](https://github.com/gameontext).

## Author of

%% Begin Hub: Released contributions %%
### Plugins
- [[obsidian-task-collector|Task Collector (TC)]]
- [[obsidian-snippetor|Snippetor]]

### Themes
- [[Ebullientworks]]
%% End Hub: Released contributions %%

%% Add links to any plugins, themes or other notes that the author has created but are not (yet) included in the `obsidian-releases` repo %%

<!--
### Unlisted plugins
-->

<!--
### Others
-->

## Sponsor this author

- [[Buy me a coffee]]: [Buy @ebullient a coffee](https://www.buymeacoffee.com/ebullient) ^buy-me-a-coffee

<!--- [[GitHub sponsors]]: [Sponsor @ebullient on GitHub Sponsors](https://github.com/sponsors/ebullient) ^github-sponsor
- [[PayPal]]: ^paypal
- [[Patreon]]: ^patreon
-->

## Follow this author

- Twitter: [@ebullientworks](https://twitter.com/ebullientworks) ^twitter

<!--
- [[YouTube Channels|On YouTube]]: ^youtube
- ...
-->

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/01%20-%20Community/People/ebullient.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/01%20-%20Community/People/ebullient.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
