---
aliases:
- 
tags: 
- MOC
---

# 🗂️ 01 Templates

%% Hub MOCs: Don’t edit below  %%
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Author|T - Author]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Auxiliary Tool Category|T - Auxiliary Tool Category]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Auxiliary tool|T - Auxiliary tool]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Blog posts|T - Blog posts]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - CSS Snippet|T - CSS Snippet]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Digital garden site|T - Digital garden site]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Folder structure|T - Folder structure]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - GitHub Repository|T - GitHub Repository]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - How to|T - How to]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - MOCs|T - MOCs]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - New Concept|T - New Concept]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - New Note|T - New Note]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Note showcase|T - Note showcase]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Plugin Category|T - Plugin Category]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Publish site|T - Publish site]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Templates|T - Templates]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Title|T - Title]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - TODO|T - TODO]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Vault showcase|T - Vault showcase]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - Website|T - Website]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - YouTube Channel|T - YouTube Channel]]
-  [[00 - Contribute to the Obsidian Hub/01 Templates/T - YouTube Video|T - YouTube Video]]
%% Hub MOCs: Don’t edit above  %%

