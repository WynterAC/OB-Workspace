# Contributing with community plugins and themes

Each note has been populated with some basic contents and structure based on the [obsidian-releases]() repository. However, notes in this folder might have missing information. 
Substitute any #placeholder tag with the required information or comment it out if it's not applicable.

Once you're done making changes, you can [[How to add content through GitHub|submit your changes to GitHub]].

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/Contributing%20with%20community%20plugins%20and%20themes.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/Contributing%20with%20community%20plugins%20and%20themes.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
