---
aliases:
- 
tags:
- 
---

# Discussion Needed

Mostly minor improvements over what we already have:

- [[Content Comments]]
- [[Content People]]
- [[Content Plugins]]
- [[Content Themes]]
- [[Content Lists]]

Next time

- [[GitHub Actions for the Hub]]
- [[Content Lifecycle of Extensions]]
- Categories on issues
    - When to use Good First Issue?
    - Whether to mark "New Features" in Scripting?
- Prioritise the [Hub Tools & Scripts](https://github.com/obsidian-community/obsidian-hub/projects/1) project backlog

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/Discussion%20Needed.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/Discussion%20Needed.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
