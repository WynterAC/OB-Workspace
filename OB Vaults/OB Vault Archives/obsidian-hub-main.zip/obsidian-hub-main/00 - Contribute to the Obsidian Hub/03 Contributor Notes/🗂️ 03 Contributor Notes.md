---
aliases:
- 
tags:
- MOC
publish: true
---

# 🗂️ 03 Contributor Notes

The notes in this folder are a kind of behind-the-scenes place to keep notes about managing this vault.

## MOC

%% Hub MOCs: Don’t edit below  %%
-  [[00 - Contribute to the Obsidian Hub/03 Contributor Notes/03.01 Structure/🗂️ 03.01 Structure|🗂️ 03.01 Structure]]
-  [[00 - Contribute to the Obsidian Hub/03 Contributor Notes/03.02 Design Decisions/🗂️ 03.02 Design Decisions|🗂️ 03.02 Design Decisions]]
-  [[00 - Contribute to the Obsidian Hub/03 Contributor Notes/03.03 Scripts and Automation/🗂️ 03.03 Scripts and Automation|🗂️ 03.03 Scripts and Automation]]
-  [[00 - Contribute to the Obsidian Hub/03 Contributor Notes/Discussion Needed|Discussion Needed]]
%% Hub MOCs: Don’t edit above  %%

%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/%F0%9F%97%82%EF%B8%8F%2003%20Contributor%20Notes.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/%F0%9F%97%82%EF%B8%8F%2003%20Contributor%20Notes.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
