---
aliases:
- 
tags:
- 
---

# Content: Plugins

## Change plugins template to simplify manual intervention, when running `update-releases.py`

Apply the conventions proposed in [[Content Comments]] to this file.



Replace these comments with new convention

```markdown
%% ----- Badges ----- %%
...
%% ----- Badges ----- %%

%% ----- Do not edit this section ----- %%
...
%% ----- Do not edit anything above this line ----- %% 
```



Change this:

```markdown
%% ![[claremacrae#Sponsor this author]] %%
```

To this:

```markdown
<!-- ![[claremacrae#Sponsor this author]] -->
```




%% Hub footer: Please don't edit anything below this line %%

# This note in GitHub

<span class="git-footer">[Edit In GitHub](https://github.dev/obsidian-community/obsidian-hub/blob/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/03.02%20Design%20Decisions/Content%20Plugins.md "git-hub-edit-note") | [Copy this note](https://raw.githubusercontent.com/obsidian-community/obsidian-hub/main/00%20-%20Contribute%20to%20the%20Obsidian%20Hub/03%20Contributor%20Notes/03.02%20Design%20Decisions/Content%20Plugins.md "git-hub-copy-note") | [Download this vault](https://github.com/obsidian-community/obsidian-hub/archive/refs/heads/main.zip "git-hub-download-vault") </span>
