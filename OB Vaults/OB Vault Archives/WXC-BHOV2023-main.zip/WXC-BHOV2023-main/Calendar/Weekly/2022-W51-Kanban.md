---

kanban-plugin: basic

---

## To Do



## In Progress



## Done

**Complete**


## Waiting On





%% kanban:settings
```
{"kanban-plugin":"basic"}
  ```
  %%