---
aliases: [Workout]
tags: [workout]
title: Workout
reps:
weight:
linter-yaml-title-alias: Workout
date created: Thursday, December 15th 2022, 1:13:46 pm
date modified: Thursday, December 15th 2022, 1:13:57 pm
---

# <% tp.system.prompt("What Is the Full Name of This Workout?") %>