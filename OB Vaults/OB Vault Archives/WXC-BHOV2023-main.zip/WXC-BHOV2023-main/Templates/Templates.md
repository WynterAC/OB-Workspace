---
tags: 
title: Templates
date created: Tuesday, December 13th 2022, 12:02:18 am
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

%% Begin Waypoint %%
- [[Daily]]
- [[People]]
- [[Quarterly]]
- [[Recipes]]
- [[Weekly]]
- [[Workout]]
- [[Zettelkasten Note]]

%% End Waypoint %%