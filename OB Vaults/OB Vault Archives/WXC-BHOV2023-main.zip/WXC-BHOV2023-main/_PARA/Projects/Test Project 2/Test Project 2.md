---
tags: 
title: Test Project 2
date created: Sunday, December 11th 2022, 1:55:45 am
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

> [!info] Project Description
> [What is my purpose?](https://youtu.be/X7HmltUWXgs)

%% Begin Waypoint %%
- [[Kanban]]
- [[Resources]]
- [[Scratchpad]]

%% End Waypoint %%

