---
tags: []
kanban-plugin: basic
title: Kanban
date created: Sunday, December 11th 2022, 1:55:45 am
date modified: Wednesday, December 14th 2022, 4:44:52 pm
---

## To Do

- [ ] a task for test project 2!


## In Progress



## Done

**Complete**


## Waiting On





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%