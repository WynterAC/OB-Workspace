---
tags: []
title: Scratchpad
date created: Sunday, December 11th 2022, 1:55:45 am
date modified: Thursday, December 15th 2022, 12:04:07 pm
---

> quote the raven…quickadd! - [[2022-12-15]]
