---
tags: []
kanban-plugin: basic
title: Kanban
date created: Sunday, December 11th 2022, 1:55:37 am
date modified: Wednesday, December 14th 2022, 4:44:43 pm
---

## To Do
- [ ] 2022-12-15 - - [ ] an example task added by quickadd!

- [ ] a task for test project!


## In Progress



## Done

**Complete**


## Waiting On





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%