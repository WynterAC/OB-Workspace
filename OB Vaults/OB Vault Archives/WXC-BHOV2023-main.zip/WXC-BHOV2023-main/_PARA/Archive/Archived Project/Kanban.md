---
tags: []
kanban-plugin: basic
title: Kanban
date created: Thursday, December 8th 2022, 2:42:09 am
date modified: Wednesday, December 14th 2022, 4:44:33 pm
---

## To Do



## In Progress



## Done

**Complete**
- [x] we
- [x] did
- [x] a
- [x] lot!!!


## Waiting On





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%