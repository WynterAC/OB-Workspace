module.exports = (params) => { 
    params.variables.fileType = {
        folder: "Projects", 
        //folderExclude: "", 
        // There's no folder to exclude so I commented it out
        filename:"Kanban" 
    };
}