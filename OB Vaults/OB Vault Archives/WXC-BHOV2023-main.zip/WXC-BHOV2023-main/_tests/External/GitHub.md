---
aliases: [publishing to GitHub]
tags: 
title: publishing to GitHub
linter-yaml-title-alias: publishing to GitHub
date created: Thursday, December 8th 2022, 5:15:03 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

In this vault, Obsidian Git is used for:
- version control
- backups

>[!warning]
>You should add `/Private` to `.gitignore` using the "Edit .gitignore" command

# Publishing to GitHub