---
tags: 
title: Private
date created: Wednesday, December 7th 2022, 11:34:44 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

> [!warning]
> Private notes should have a icon in front of them to show they will not propogate to [Obsidian Publish](https://obsidian.md/publish)

You should see the shh emoji (🤫) to the left of this private note -> [[Secret Note]][^1]
You should **not** see the shh emoji (🤫) next to this public note -> [[README]]

Daily Notes should also be kept private imo, but this is optional -- you should see a  calendar emoji (📆) before a daily note -> [[2022-12-11]]

## Resources

[Link Icons Tutorial](https://youtu.be/uWyeJLWKXUI)

[^1]: This sometimes breaks. Go into settings `ctrl-,` and click on "Supercharged Links" to see if this loads the style