---
aliases: [Squats]
tags: [workout]
title: Squats
reps: 5
weight: 135
linter-yaml-title-alias: Squats
date created: Thursday, December 15th 2022, 1:13:46 pm
date modified: Thursday, December 15th 2022, 1:15:18 pm
---

# Squats


## Form

<iframe src='https://gfycat.com/ifr/HonoredFondKawala' frameborder='0' scrolling='no' allowfullscreen width='640' height='684'></iframe><p> <a href="https://gfycat.com/honoredfondkawala">via Gfycat</a></p>

<iframe src='https://gfycat.com/ifr/FrayedDiligentDogwoodclubgall' frameborder='0' scrolling='no' allowfullscreen width='640' height='404'></iframe>
