---
aliases: [Instant Pot Fried Rice]
tags: [recipes, instant-pot]
title: Instant Pot Fried Rice
date created: Thursday, December 15th 2022, 1:00:22 pm
date modified: Thursday, December 15th 2022, 1:00:55 pm
linter-yaml-title-alias: Instant Pot Fried Rice
---

# Instant Pot Fried Rice

## PDF

![[Instant Pot Fried Rice - Little Sunny Kitchen.pdf]]