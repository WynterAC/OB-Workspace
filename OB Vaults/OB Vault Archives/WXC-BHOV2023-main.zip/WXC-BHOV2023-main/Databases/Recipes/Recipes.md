
%% Begin Waypoint %%
- [[Instant Pot Fried Rice]]

%% End Waypoint %%
