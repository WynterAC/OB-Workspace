---
aliases: [John Doe]
tags: [people]
phone: 1234567
email: john@email.com
url: https://www.google.com
instagram: johndoe
twitter: johndoe
linkedin: johndoe
birthday: 01/01/1980
lastContacted: 2022-01-01
relationship: cousin
title: John Doe
date created: Friday, December 9th 2022, 12:11:22 pm
date modified: Thursday, December 15th 2022, 1:01:58 pm
linter-yaml-title-alias: John Doe
---

# John Doe

## Likes

1. Stuffed Wallets that Dont Fit in Pockets
2. Being On Hold on the Phone
3. Super Soaker Relay Races

## Dislikes

1. the color shmurple
2. the sequel to the movie 300
3. MakeDonalds

## Last Thing We Talked About

Are knapsacks overrated?
