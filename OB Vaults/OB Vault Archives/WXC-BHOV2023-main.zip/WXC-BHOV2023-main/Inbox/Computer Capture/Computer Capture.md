---
tags: 
title: Computer Capture
date created: Saturday, December 10th 2022, 5:13:48 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---
%% Begin Waypoint %%
- [[2022-12-11--12-00-00]]
- [[2022-12-15-14-50-23]]
- [[2022-12-15-14-50-51]]

%% End Waypoint %%