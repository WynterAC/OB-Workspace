---
tags: []
title: Hotkeys
date created: Thursday, December 8th 2022, 12:18:03 am
date modified: Wednesday, December 14th 2022, 4:52:45 pm
---


`ctrl-p` -> open command palette
`ctrl-shift-e` -> [auto link title](obsidian://show-plugin?id=obsidian-auto-link-title)  
`ctrl-shift-p` -> show [projects](obsidian://show-plugin?id=obsidian-projects)  
`ctrl-click` a folder name -> create a [folder note](obsidian://show-plugin?id=folder-note-plugin)  
`ctrl-shift-f` -> [omnisearch](obsidian://show-plugin?id=omnisearch) vault search  
`alt-shift-f` -> [footnote](obsidian://show-plugin?id=obsidian-footnotes) insertion  
`alt-shift-d` -> open daily note  
`alt-shift-w` -> open weekly note  
`alt-shift-q` -> open quarterly note 
`alt-shift-'` -> reveal current file in navigation
`ctrl-.` -> toggle pin note  
`alt-shift-z` -> search Zettelkasten notes by H1  
`ctl-alt-l` -> lint file
