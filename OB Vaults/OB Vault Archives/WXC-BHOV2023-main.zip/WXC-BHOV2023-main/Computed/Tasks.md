---
aliases: [Tasks in Daily Notes]
tags: 
title: Tasks in Daily Notes
linter-yaml-title-alias: Tasks in Daily Notes
date created: Monday, December 12th 2022, 10:11:07 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

# Tasks in Daily Notes
```tasks
not done
heading includes todo/daily
```


# Tasks in Inbox
```tasks
not done
path includes Inbox
```

# Tasks in Projects
```tasks
not done
path includes _PARA/Projects
heading includes To Do
```

# Tasks in Weekly

## Monday

```tasks
not done
path includes Calendar
heading includes todo/monday
```

## Tuesday

```tasks
not done
path includes Calendar
heading includes todo/tuesday
```

## Wednesday

```tasks
not done
path includes Calendar
heading includes todo/wednesday
```

## Thursday

```tasks
not done
path includes Calendar
heading includes todo/thursday
```

## Friday

```tasks
not done
path includes Calendar
heading includes todo/friday
```

## Saturday

```tasks
not done
path includes Calendar
heading includes todo/saturday
```

## Sunday

```tasks
not done
path includes Calendar
heading includes todo/sunday
```

