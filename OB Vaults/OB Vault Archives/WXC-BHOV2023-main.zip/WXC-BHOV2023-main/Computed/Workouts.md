
```dataview
table reps, weight
from "Databases/Workouts"
where file.name != "Workouts"
```