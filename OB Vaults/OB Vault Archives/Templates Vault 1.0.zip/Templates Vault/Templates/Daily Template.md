
 [[<% tp.date.yesterday("YYYY-MM-DD") %>]] |[[<% tp.date.tomorrow("YYYY-MM-DD") %>]]

# Intentions

# Highlight

# Log

# Reflection
