# [[<% tp.file.title %>]]
**Created:** [[<% tp.date.now( ) %>]]


<% await tp.file.move("/Templates" + "/" + tp.file.title) %>