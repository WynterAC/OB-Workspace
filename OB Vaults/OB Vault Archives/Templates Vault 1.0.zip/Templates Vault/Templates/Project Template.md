# [[<% tp.file.title %>]]
**Created:** [[<% tp.date.now() %>]]


# Overview

# Outcome

# Key People

# Tasks

# Notes

# Log

---


<% await tp.file.move("/Projects" + "/" + tp.file.title) %>
