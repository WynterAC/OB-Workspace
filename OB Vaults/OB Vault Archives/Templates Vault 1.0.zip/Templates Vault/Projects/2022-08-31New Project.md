# [[2022-08-31New Project]]
**Created:** [[2022-08-31]]


# Overview

# Outcome

# Key People

# Tasks

# Notes

# Log

---



