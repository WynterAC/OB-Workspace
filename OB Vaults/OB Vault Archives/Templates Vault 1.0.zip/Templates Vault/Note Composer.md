# Note Composer

Text originally in [[One More Plugin]]
**Created:** [[2022-08-30]]

The Note Composer Plugin allows you to specify a few additional pieces of data in your template using your script. Let's create that template first and then we'll give the Note Composer Core plugin a run for its money.


