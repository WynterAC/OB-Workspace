# Zettelkasten Plugin

Text originally in [[One More Plugin]]
**Created:** [[2022-08-30]]

Note: You might also want to use the Unique Note Creator Plugin which also lets you create a template for Zettelkasten style notes. That said, I personally can't make sense of a Zettelkasten file structure based on date codes so with the information you already have you'll be able to use this plugin and I hope some day you'll help me see how a Zettelkasten based on date and time codes can make sense to someone.


