# [[2022-09-05 Team Meeting]]
[[2022-08-31]]



# Agenda
## Standing Items
- [ ] Review [Project List](www.linktoourprojectlist.com)
- [ ] What items should we include in monthly all hands meeting
- [ ] Discuss new intiatives from President's Round Table
## New Business

## Old Business

---
# Attendees
- [ ] Steve
- [ ] Alina
- [ ] Jessica
- [ ] Trenton
- [ ] Parker
- [ ] Kara

# Notes


# Action Items
- [ ] Distribute notes from meetin

---



