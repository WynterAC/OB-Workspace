---
date_created: "{{date}}"
tags: [ type/fleeting ]
---

