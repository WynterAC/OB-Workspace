---
date_created: "{{date}}"
tags: [ type/permanent ]
---

