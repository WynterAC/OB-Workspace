---
date_created: "{{date}}"
tags: [ type/literature ]
---

