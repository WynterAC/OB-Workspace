---
tags: type/goal {{main_topic_tag:text:topic/}}
emoji: "{{icon}}"
template-filename: "{{title}}"
template-output: Goals
template-replacement: "[[{{filename}}]]"
template-should-replace: "always" 
template-input: title, now, main_topic_tag
zettel-prefix: "{{now:currentDate:yyyyMMddHHmm}}"
---

# {{icon}}{{title}}


## 🔥 Milestones
* [ ] 


## 🌱 Goal Projects
```button
name Add Project
type command
action From Template: Project
```
* 


## ✍️ Journal
* 
