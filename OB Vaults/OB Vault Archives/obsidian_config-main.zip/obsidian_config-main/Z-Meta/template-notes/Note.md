---
tags: {{main_topic_tag:text:type/note/default topic/default purpose/default}}
template-filename: "{{now:currentDate:yyyyMMddHHmm}} {{title}}"
template-output: Notes
template-replacement: "[[{{filename}}]]"
template-input: title, now, main_topic_tag, author
zettel-prefix: "{{now:currentDate:yyyyMMddHHmm}}"
author: {{author}}
---

# {{title}}
