---
tags: type/note/web purpose/default topic/default
template-filename: "{{now:currentDate:yyyyMMddHHmm}} {{title}}"
template-replacement: "* [[{{filename}}]]"
template-input: title, now, icon
zettel-prefix: "{{now:currentDate:yyyyMMddHHmm}}"
url: 
---

## Web Notes