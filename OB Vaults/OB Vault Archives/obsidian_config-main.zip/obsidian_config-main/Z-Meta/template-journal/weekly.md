---
tags: journal/weekly
---

`button-weekprevious` `button-weeknext`

* [[#Domingo ({{sunday:gggg-MM-DD}})]]
* [[#Lunes ({{monday:gggg-MM-DD}})]]
* [[#Martes ({{tuesday:gggg-MM-DD}})]]
* [[#Miércoles ({{wednesday:gggg-MM-DD}})]]
* [[#Jueves ({{thursday:gggg-MM-DD}})]]
* [[#Viernes ({{friday:gggg-MM-DD}})]]
* [[#Sábado ({{saturday:gggg-MM-DD}})]]

-----
# Domingo ({{sunday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{sunday:gggg-MM-DD}}]]

* 

-----
# Lunes ({{monday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{monday:gggg-MM-DD}}]]

* 

-----
# Martes ({{tuesday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{tuesday:gggg-MM-DD}}]]

* 

-----
# Miércoles ({{wednesday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{wednesday:gggg-MM-DD}}]]

* 

-----
# Jueves ({{thursday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{thursday:gggg-MM-DD}}]]

* 

-----
# Viernes ({{friday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{friday:gggg-MM-DD}}]]

* 

-----
# Sábado ({{saturday:gggg-MM-DD}})
* Day Planning:  [[Y-Journal/DailyPlanning/{{saturday:gggg-MM-DD}}]]

* 
