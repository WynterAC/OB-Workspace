
# Weekly notes

```button
name Previous
type command
action QuickAdd: Pinned Previous Weekly Note
```
^button-weekprevious

```button
name Next
type command
action QuickAdd: Pinned Next Weekly Note
```
^button-weeknext
