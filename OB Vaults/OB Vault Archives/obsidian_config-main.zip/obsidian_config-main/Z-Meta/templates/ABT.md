* A
	* 
	* **Y** 
* B
	* **Pero** 
* T
	* **Por esto/Entonces** 