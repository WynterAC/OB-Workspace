## Daily Journal

#### Estoy agradecido de

#### Que hice ayer? que puedo mejorar?

#### Quien soy? como será hoy?