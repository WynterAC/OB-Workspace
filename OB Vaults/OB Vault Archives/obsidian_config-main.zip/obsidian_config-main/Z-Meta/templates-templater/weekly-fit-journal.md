---
tags: journal/weekly note/type/fitness
---

[[Y-Journal/Fitness/<% tp.date.weekday("[fit]-gggg-[W]WW[|][fit]-gggg-[W]WW", -2, tp.file.title, "[fit]-gggg-[W]WW") %>]] | This Week | [[Y-Journal/Fitness/<% tp.date.weekday("[fit]-gggg-[W]WW[|][fit]-gggg-[W]WW", 14, tp.file.title, "[fit]-gggg-[W]WW") %>]]

* [[#Domingo (<% tp.date.weekday("YYYY-MM-DD", 0, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Lunes (<% tp.date.weekday("YYYY-MM-DD", 1, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Martes (<% tp.date.weekday("YYYY-MM-DD", 2, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Miércoles (<% tp.date.weekday("YYYY-MM-DD", 3, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Jueves (<% tp.date.weekday("YYYY-MM-DD", 4, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Viernes (<% tp.date.weekday("YYYY-MM-DD", 5, tp.file.title, "[fit]-gggg-[W]WW") %>)]]
* [[#Sábado (<% tp.date.weekday("YYYY-MM-DD", 6, tp.file.title, "[fit]-gggg-[W]WW") %>)]]

-----
# Domingo (<% tp.date.weekday("YYYY-MM-DD", 0, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Lunes (<% tp.date.weekday("YYYY-MM-DD", 1, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Martes (<% tp.date.weekday("YYYY-MM-DD", 2, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Miércoles (<% tp.date.weekday("YYYY-MM-DD", 3, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Jueves (<% tp.date.weekday("YYYY-MM-DD", 4, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Viernes (<% tp.date.weekday("YYYY-MM-DD", 5, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 

-----
# Sábado (<% tp.date.weekday("YYYY-MM-DD", 6, tp.file.title, "[fit]-gggg-[W]WW") %>)

## Workout
* 

## Training Journal
* 
