asdfsdafasd
<% await tp.file.content %>
qwerty