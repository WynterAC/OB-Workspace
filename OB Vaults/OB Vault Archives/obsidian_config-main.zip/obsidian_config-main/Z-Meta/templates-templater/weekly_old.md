---
tags: journal/weekly
---

[[Y-Journal/Weekly/<% tp.date.weekday("gggg-[W]WW[|]gggg-[W]WW", -2, tp.file.title, "gggg-[W]WW") %>]] | This Week | [[Y-Journal/Weekly/<% tp.date.weekday("gggg-[W]WW[|]gggg-[W]WW", 14, tp.file.title, "gggg-[W]WW") %>]]

* [[#Domingo (<% tp.date.weekday("YYYY-MM-DD", 0, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Lunes (<% tp.date.weekday("YYYY-MM-DD", 1, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Martes (<% tp.date.weekday("YYYY-MM-DD", 2, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Miércoles (<% tp.date.weekday("YYYY-MM-DD", 3, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Jueves (<% tp.date.weekday("YYYY-MM-DD", 4, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Viernes (<% tp.date.weekday("YYYY-MM-DD", 5, tp.file.title, "gggg-[W]WW") %>)]]
* [[#Sábado (<% tp.date.weekday("YYYY-MM-DD", 6, tp.file.title, "gggg-[W]WW") %>)]]

-----
# Domingo (<% tp.date.weekday("YYYY-MM-DD", 0, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 0, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Lunes (<% tp.date.weekday("YYYY-MM-DD", 1, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 1, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Martes (<% tp.date.weekday("YYYY-MM-DD", 2, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 2, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Miércoles (<% tp.date.weekday("YYYY-MM-DD", 3, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 3, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Jueves (<% tp.date.weekday("YYYY-MM-DD", 4, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 4, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Viernes (<% tp.date.weekday("YYYY-MM-DD", 5, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 5, tp.file.title, "gggg-[W]WW") %>]]

* 

-----
# Sábado (<% tp.date.weekday("YYYY-MM-DD", 6, tp.file.title, "gggg-[W]WW") %>)
* Day Planning:  [[Y-Journal/DailyPlanning/<% tp.date.weekday("YYYY-MM-DD", 6, tp.file.title, "gggg-[W]WW") %>]]

* 
