---
icon: disappointed_relieved
tags : type/area purpose/organizing topic/notetaking/discarded archive
up: [[index]]
---
# Discarted

## Discarted (For now)
 * [[Python Gui on Windows]]
 * [[Memoir]] - Un paso para poder escribir libros o articulos
 * [[Bookmarks]] - Filtrador de Bookmarks
 * [[Plani Cuarentena Fit]] - A entrenar!
 * [[Proyectos Listos]] -- Si logre terminar algún proyecto, las notas irán en esta sección (Se usa Done de arriba)
 * [[202105101915-BoxMagicProjects]]
 * [[Boykot]] - Optimización flujo de pedidos

## Old Projects
* [[vivespropiedades]] -- Proyecto Django para mejorar vivespropiedades.cl

## Oldies
* [[Scratchpad]]
