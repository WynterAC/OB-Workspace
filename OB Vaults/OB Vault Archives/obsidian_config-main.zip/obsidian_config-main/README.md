# Obsidian Config

Based on Thomas Frank second brain implementation on Notion (https://www.youtube.com/watch?v=vs8WQh2k-Ow), I decided to try this implementation of 2nd Brain in Obsidian, using mostly tags, and plugins like Dataview, Breadcrumbs, and others

Soon, I'll write about how to use this configuration in Obsidian. For now, the repo includes .obsidian folder (without workspaces), and templates used for plugin Note From Template (https://github.com/mo-seph/obsidian-note-from-template)
