*This product is constantly being developed and updated so feel free to check back from time to time*

The templates folder is an Obsidian vault in itself so you can open it as a vault :)

Download Obsidian here: https://obsidian.md/
