---
obsidianUIMode: preview
cssclass: nobacklinks
---

<iframe src="https://cubox.pro/web/save/inbox" style="position: absolute; top: 0; left: 0; width:100%; border: none;  height:100%;">