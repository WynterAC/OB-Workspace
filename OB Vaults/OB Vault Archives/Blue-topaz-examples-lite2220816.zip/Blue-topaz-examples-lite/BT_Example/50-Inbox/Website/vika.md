---
obsidianUIMode: preview
cssclass: nobacklinks
---

<div style="display: block; position: absolute; left: 0; top: 0; width: 100%; height: 100%; --aspect-ratio:9/16; padding-bottom: calc(var(--aspect-ratio) * 100%);"><iframe src="https://vika.cn/" allow="fullscreen" style="position: absolute; top: 0px; left: 0px; border:none; height: 100%; width: 100%;"></iframe></div>