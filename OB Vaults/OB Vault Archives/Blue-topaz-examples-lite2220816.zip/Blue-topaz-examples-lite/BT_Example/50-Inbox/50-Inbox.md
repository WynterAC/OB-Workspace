---
cssclass: kanban gridlist noyaml
tag: moc
obsidianUIMode: preview
--- `button-homewp`  `button-browsevault`  `button-browsenext` `button-browserefresh` 
%% Begin Waypoint %%
- **[[50-Inbox]]**
	- [[50-Inbox]]
	- **Logs**
	- **Other**
	- **People**
		- [[李四]]
	- **Study**
		- [[20220815181830]]
		- [[cesce]]
	- **[[Website]]**
	- **Work**

%% End Waypoint %%