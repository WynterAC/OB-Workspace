---
alias: 
tags: 学习
cdate: 2022-08-15 12:14
uid: 20220815121451 
cssclass: 
Cover: 
---

## Metadata
Status::    #笔记状态/🌱发芽
Source Type::  #📥/💭想法 
Topic:: [[undefined]]
Author:: 
Source URL:: 

## 长青笔记
一句话概括这篇笔记的内容
Summary:: 

## 自我重述
用自己的话去重述提取的重点内容


## 重点摘抄
摘抄部分原文后，进行筛选加粗然后对加粗的继续进行筛选荧光笔选出。


## 相关文章
Page Link::  
