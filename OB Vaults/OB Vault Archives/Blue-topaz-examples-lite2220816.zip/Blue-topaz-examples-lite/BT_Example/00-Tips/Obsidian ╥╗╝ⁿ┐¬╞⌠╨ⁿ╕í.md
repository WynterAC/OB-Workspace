﻿---
updated: 2022-03-15 14:15
---
## ✍ 前言
 借助 [obsidian-hover-editor](https://github.com/nothingislost/obsidian-hover-editor)插件实现Ob悬浮操作，视频讲解了如果从侧边栏开启一键悬浮memos
 本示例库已经支持此功能。
 
## 📀视频地址
 
[Obsidian 一键开启悬浮窗口 一切皆可悬浮 快来试试吧_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1BL411P7Tx?spm_id_from=444.41.0.0)

