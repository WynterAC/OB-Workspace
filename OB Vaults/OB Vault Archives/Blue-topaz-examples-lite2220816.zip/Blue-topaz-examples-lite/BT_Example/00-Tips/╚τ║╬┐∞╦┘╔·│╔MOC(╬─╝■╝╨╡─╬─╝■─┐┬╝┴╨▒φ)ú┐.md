---
title: 如何快速生成文件夹的文件目录列表？
updated:: 2022-04-07 16:23:42
created:: 2022-04-07 16:13:42
---

## 👉  如何使用？

有两种方式生成MOC：
```ad-example
title: 第一种
1. 需要安装插件 [waypoint](obsidian://show-plugin?id=waypoint)
2. 运行命令 templater：88-Template/tp_foldermoc 或者点击👉 `button-genmoc`
3. 选择 要生成的文件夹
自动就生成了 所选择的文件夹以及子文件夹的moc

```

```ad-example
title: 第二种
1. 需要安装插件 [waypoint](obsidian://show-plugin?id=waypoint)
2. 安装插件 [folder note](obsidian://show-plugin?id=folder-note-plugin)
3. 按住ctrl并点击目录文件夹即可自动生成moc

```
