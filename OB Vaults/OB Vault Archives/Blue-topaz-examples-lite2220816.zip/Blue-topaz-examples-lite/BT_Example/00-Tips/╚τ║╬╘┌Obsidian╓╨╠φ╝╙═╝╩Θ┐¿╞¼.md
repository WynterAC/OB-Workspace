﻿## ✍ 前言
- 图书数据卡片获取通过Quickadd 调用`88-Template\script\bookfromdouban.js`。
- 卡片视图通过 dataview table 配合 cssclass cards实现。
- 需要启用【卡片视图】cards.css片段
## 👉  如何使用？
- ctrl+p  命令行输入`添加图书` 然后输入豆瓣读书对应的URL地址即可.例如`https://book.douban.com/subject/1007305/`
- 图书模板文件位于`88-template\tp-book.md`，图书生成文件位于`30-Reading`中
-  配合search-on-internet插件使用更佳

比如搜索 微习惯 这本书

![[豆瓣添加图书.gif]]