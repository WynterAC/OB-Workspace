﻿判断obsidian插件和主题无法加载的前提有以下3点
1.  obsidian插件和主题是位于raw.githubcontent.com
2.  因为种种问题可能无法访问Github
3.  我们可以通过访问github国内镜像网站。

> 通过fastgithub 可以解决Obsidian在国内无法访问社区，无法更新插件，无法更新主题的问题。

内附文件下载

[fastgithub 可为你加速访问 GitHub - 飞书文档 (feishu.cn)](https://kknwfe6755.feishu.cn/docs/doccnlz0w9txyJT96MYhASQkVIh)
