
> Booknote插件（跟 bookxnote 软件没有任何关系）是 @围城 最新力作，可以用来管理指定目录下的文档，这个目录可以是库外目录，电脑上的任意路径都可以。目前可以对pdf office等文档进行标注和管理。
> 本插件目前处于内测阶段，在**win10,mac**下测试通过。
> 插件项目地址： https://github.com/chenghongyao/obsidian-booknote-plugin

插件下载和使用说明
[更新0.2.4(20211214)如何安装并使用booknote插件？ - 飞书文档 (feishu.cn)](https://kknwfe6755.feishu.cn/docs/doccnBfbtETItLHMmbDBGBRdPrh)