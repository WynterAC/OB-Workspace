
> 此插件是在cMenu1.1.2 跟随悬浮效果 基础上魔改而成，增加了 固定和跟随选项设置
- 增加位置固定和跟随选项。
- 增加了 cmenu 风格 tiny样式，更紧凑。
- 修复了 插件跟随位置判断
- 修复了悬浮效果在边界触发溢出的问题
- 修复了按钮超过一行，背景框不对应问题。
- 修复 黑暗模式图标颜色不一致
- 修复 工具栏越界问题

本示例库已经集成。
文件下载链接:
[Release cmenu 1.1.30 魔改版 · cumany/cMenu-Plugin (github.com)](https://github.com/cumany/cMenu-Plugin/releases/tag/1.1.30)

介绍文章：
[Cmenu插件魔改版1.1.23 Obsidian上的工具栏 - 飞书文档 (feishu.cn)](https://kknwfe6755.feishu.cn/docs/doccnQpRTqGYqMT3GAKka5IRnMf)
