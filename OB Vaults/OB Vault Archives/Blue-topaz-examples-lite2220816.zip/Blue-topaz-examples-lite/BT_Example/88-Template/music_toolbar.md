﻿---
obsidianUIMode: preview
cssclass: mytools
---

````ad-music
title: 音乐
collapse: close
```jsx::Musicbar
6894168416
```

````