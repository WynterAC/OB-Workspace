---
cover: {{VALUE:Poster}}
tags: Movie 
banner_icon: 🎞
status: 
progress: 
---

![poster|inlR|240]({{VALUE:Poster}})
title:: {{VALUE:fileName}}
category:: {{VALUE:typeLink}}
director:: {{VALUE:directorLink}}
genre:: {{VALUE:genreLinks}}
imdbId:: {{VALUE:imdbID}}
ratingImdb:: {{VALUE:imdbRating}}
rating:: {{VALUE:imdbRating}}
year:: {{VALUE:Year}}
cast:: {{VALUE:actorLinks}}
plot:: {{VALUE:Plot}}


