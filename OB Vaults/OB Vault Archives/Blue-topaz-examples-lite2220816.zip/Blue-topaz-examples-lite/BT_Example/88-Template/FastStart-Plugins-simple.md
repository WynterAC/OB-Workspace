workspaces-plus

cmenu-plugin
Enhanced-editing
markdown-table-editor
obsidian-advanced-uri
obsidian-banners
obsidian-contextual-typography
obsidian-dynamic-highlights
obsidian-kanban
obsidian-memos
obsidian-sortable
buttons
obsidian-table-to-csv-exporter
obsidian-view-mode-by-frontmatter
obsidian42-brat
periodic-notes
recent-files-obsidian
various-complements
waypoint

