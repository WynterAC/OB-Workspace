> 此文件由[[获取插件列表]]自动生成

<% Object.values(app.plugins.manifests).map(p=>p.id).sort((a,b)=>a.localeCompare(b)).join('\n') %>