﻿
[喜于微 (lillianwho.com)](http://lillianwho.com/)
 [Obsidian | 喜于微 (lillian-who.github.io)](https://lillian-who.github.io/tag/g5VDCYGAxnP/)
 
 Obsidian必读文章有：

[Obsidian入门：从第一个文件开始 | 喜于微 (lillianwho.com)](http://lillianwho.com/post/obsidian%E5%85%A5%E9%97%A8/)

[Obsidian最强插件：quickadd (lillian-who.github.io)](https://lillian-who.github.io/post/Obsidian%E6%9C%80%E5%BC%BA%E6%8F%92%E4%BB%B6quickadd/)

[obsidian插件之dataview入门 | 喜于微 (lillian-who.github.io)](https://lillian-who.github.io/post/obsidian%E6%8F%92%E4%BB%B6%E4%B9%8Bdataview%E5%85%A5%E9%97%A8/)


 
 
 
 