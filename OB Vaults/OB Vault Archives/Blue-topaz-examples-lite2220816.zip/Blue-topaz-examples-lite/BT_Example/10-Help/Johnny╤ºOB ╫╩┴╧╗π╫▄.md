﻿>- Johnny学OB 资料汇总 非常适合新手入门的系列视频
>- 另外还有Ob跟Vika或者Airtable 双向同步的脚本 可以实现更高级的玩法，值得一试。



[Johnny学OB 资料汇总 - 飞书文档 (feishu.cn)](https://milinshushe.feishu.cn/docs/doccnfCDGSUJls2wYzr1gS80ZVf)

[Johnny学的公开课 第一集 将近3小时的Obsidian小白入门课，都是基础知识，学会了就能上手OB，一个社区插件都没讲_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1i3411k7TQ?from=search&seid=6184241891973295245)
