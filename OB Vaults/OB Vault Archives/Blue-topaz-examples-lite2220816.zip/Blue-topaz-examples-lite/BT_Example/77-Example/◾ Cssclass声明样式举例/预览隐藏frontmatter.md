---
alias: "测试dataview 长表格"
cssclass: "noyaml"
usage: "预览状态不显示frontmatter区域"
时间: 
status: 2
rating: 0
tags:
 - "dvtest"
 - "good"
 - "test"
 - "dataview"
updated: 
---

```ad-tip
- 测试dataview表格内容不分行紧凑显示。
- 需要在style setting 中3.6 Dataview中开启Dataview Table表格紧凑显示即可。
```


---
字段1:: AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBB我是很长很长的内容
字段2:: 我也不是省油的灯。。。。。。。。。。。

表格效果参考：[[全宽显示-表格测试|测试dataview 长表格2]]

