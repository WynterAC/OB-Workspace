---
cssclass: flatBlue, wideTable
---

# Flat Blue table
<br>


| Planet  | Distance from the Sun | 1 Planetary day  | Moons |
|---------|-----------------------|------------------|-------|
| Mercury | 57.9 million km       | 58.7 Earth days  | 0     |
| Venus   | 108.2 million km      | 243 Earth days   | 0     |
| Earth   | 149.6 million km      | 24 hours         | 1     |
| Mars    | 227.9 million km      | 24.6 Earth hours | 2     |
| Jupiter | 778.3 million km      | 9.84 Earth hours | 67    |
| Saturn  | 1,427.0 million km    | 10.2 Earth hours | 62    |
| Uranus  | 2,871.0 million km    | 17.9 Earth hours | 27    |
| Neptune | 4,497.1 million km    | 19.1 Earth hours | 13    |
