---

kanban-plugin: basic

---

## Project 1

- [ ] 下面是两个卡片<br>- card 1<br>- card 2<br>	- card 2.1<br>	- card 2.2
- [ ] ### card 3
- [ ] - [ ] card 3
- [ ] 1. card 2<br>2. card3
- [ ] [[card4]]


## Project 2

- [ ] card 1
- [ ] [[Word count]]
- [ ] [[card 2]]
- [ ] card 1
- [ ] - [x] card 3


## Project 3

- [ ] eee


## Project 4



## Project 5



## Project 6





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%