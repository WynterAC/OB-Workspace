---
cssclass: kanban gridlist
tag: moc
obsidianUIMode: preview
--- `button-homewp`  `button-browsevault`  `button-browsenext` `button-browserefresh` 
%% Begin Waypoint %%
- **[[40-Booknote]]**
	- [[40-Booknote]]
	- **[[books-data]]**

%% End Waypoint %%
