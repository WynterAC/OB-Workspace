---
name: 困在时间里的父亲 The Father
cover: https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2628877926.jpg
tags: Movie
douban_url: https://movie.douban.com/subject/33432655/
director: '佛罗莱恩·泽勒'
alias: "爸爸可否不要�?�? / 父亲(�? / 老父"
rating: 8.6
year: 2021-06-18(中国大陆)
genre: 剧情
banner_icon: 🎞
banner: "https://img9.doubanio.com/view/photo/1/public/p2628877926.jpg"
IMDb:  t10272386
lead: '安东尼·霍普金�?奥利维娅·科尔�?马克·加蒂�?奥莉维亚·威廉姆斯/伊莫琴·普�?卢夫斯·塞维尔/阿耶莎·达尔�?罗曼·泽勒/雷·伯内特/阿德南·昆�?斯科特·穆林斯/布赖恩·罗�?艾薇·�? 
language: 英语 
country: 英国 / 法国 
updated: 
viewtime:
status: 
grade: 
---
> [!bookinfo|noicon]+ 🎬《困在时间里的父�?The Father�?> ![bookcover|200](https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2628877926.jpg)
>
| 属�?| 内容                                       |
|:---- |:------------------------------------------ |
| 导演 | '佛罗莱恩·泽勒'                         |
| 主演 | '安东尼·霍普金�?奥利维娅·科尔�?马克·加蒂�?奥莉维亚·威廉姆斯/伊莫琴·普�?卢夫斯·塞维尔/阿耶莎·达尔�?罗曼·泽勒/雷·伯内特/阿德南·昆�?斯科特·穆林斯/布赖恩·罗�?艾薇·�?                             |
| 上映 | 2021-06-18(中国大陆)                             |
| 时长 | 97分钟                   |
| 来源 | [困在时间里的父亲 The Father](https://movie.douban.com/subject/33432655/) |
| 评分 | 8.6                           |
| 分类 | 剧情                            |
| IMDb | t10272386                             | 

> [!abstract]- **内容简�?*
>  影片以重复加碎片式的感官叙事手法，讲述了年迈且身患疾病的安东尼（安东尼·霍普金�?Anthony Hopkins 饰）正在面临一项艰难的人生选择——是搬到养老院还是接受女儿寻找的新护工。在这个过程中，安东尼发现自己仿佛进入了一场奇怪的时空之旅，错乱的记忆和时间线交织出一段段匪夷所思的故事，而一个个陌生又熟悉的人也让他陷入迷茫�?
















影片根据法国小说家兼剧作家佛罗莱恩·泽勒的舞台剧《父亲》改编�?>  
## 心得体会

