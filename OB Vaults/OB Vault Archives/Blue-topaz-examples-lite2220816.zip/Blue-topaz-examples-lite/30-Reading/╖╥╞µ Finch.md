---
name: 芬奇 Finch
cover: https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2721066869.jpg
tags: Movie
douban_url: https://movie.douban.com/subject/26897885/
director: '米格尔·萨普什尼克'
alias: "芬奇的旅程 / 生化 / 人生 / BIOS"
rating: 8.4
year: 2021-11-05(美国)
genre: 剧情
banner_icon: 🎞
banner: "https://img1.doubanio.com/view/photo/1/public/p2721066869.jpg"
IMDb:  t3420504
lead: '汤姆·汉克斯/卡赖伯·兰德里·琼斯/希默斯/洛拉·玛汀内斯-康宁安/玛丽·瓦根曼/OscarAvila' 
language: 英语 
country: 美国 
viewtime:
updated: 
status: 
grade: 
---
> [!bookinfo|noicon]+ 🎬《芬奇 Finch》
> ![bookcover|200](https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2721066869.jpg)
>
| 属性 | 内容                                       |
|:---- |:------------------------------------------ |
| 导演 | '米格尔·萨普什尼克'                         |
| 主演 | '汤姆·汉克斯/卡赖伯·兰德里·琼斯/希默斯/洛拉·玛汀内斯-康宁安/玛丽·瓦根曼/OscarAvila'                             |
| 上映 | 2021-11-05(美国)                             |
| 时长 | 115分钟                   |
| 来源 | [芬奇 Finch](https://movie.douban.com/subject/26897885/) |
| 评分 | 8.4                           |
| 分类 | 剧情                            |
| IMDb | t3420504                             | 

> [!abstract]- **内容简介**
>  在世界末日后的地球上，一个为保护造物主的爱犬而生的机器人，学习生活、爱情、友谊以及作为人类意味着什么。
>  
## 心得体会
