---
name: Fundamentals of Computer Graphics 5th Edition
cover: https://img1.doubanio.com/view/subject/l/public/s34110589.jpg
tags:
  - book
douban_url: https://book.douban.com/subject/35755152/
author: SteveMarschner/PeterShirley
isbn: 9780367505035
rating: null
banner: "https://img1.doubanio.com/view/subject/l/public/s34110589.jpg"
banner_icon: 📚
publish: A K Peters/CRC Press
grade: null
readtime: null
status: 已完成
pagecount: 700
pageprogress: null
updated: 2022-04-25
---
## 内容简介
《Fundamentals of Computer Graphics 5th Edition》
![bookcover|inlR|260](https://img1.doubanio.com/view/subject/l/public/s34110589.jpg)
Drawing on an impressive roster of experts in the field, Fundamentals of Computer Graphics, Fifth Edition offers an ideal resource for computer course curricula as well as a user-friendly personal or professional reference.
Focusing on geometric intuition, this book gives the necessary information for understanding how images get onto the screen by using the complementary appro...
## 心得体会
