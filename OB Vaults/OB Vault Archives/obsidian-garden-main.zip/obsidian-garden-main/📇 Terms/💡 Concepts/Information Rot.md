---
aliases: [Information Rot, Data Rot]
type: term
description: A description of information rot
---
%%
Status:: #in-progress  
%%

---
**Tags**:: #term #knowledge-management #information-rot
**Category**:: #concepts
**Links**:: [[📇 Glossary]] [[📇 Terms/🧠 Knowledge Systems/🗃 Knowledge Management|Knowledge Management]]

---

## Definition
The process by which information degrades in quality over time without proper backup

## Sources
<!-- Link any sources related to the term -->

## Uses
<!-- Provide some example uses of the term, or where it may be used -->