---
alias: [Link, link, links]
type: term
description: Description of a Link
---
%%
Status:: #in-progress 
%%

---
**Category**:: #obsidian 
Tags: #term #link #obsidian #tutorials 
Links: [[📇 Glossary]]

---

## Definition
A connection between pieces of information in [[📇 Terms/🪨 Obsidian/🪨 Obsidian]]

## Sources
- [Obsidian Documentation](https://help.obsidian.md/How+to/Internal+link)

## Uses
To creation [[📇 Terms/💡 Concepts/Connection]] between pages