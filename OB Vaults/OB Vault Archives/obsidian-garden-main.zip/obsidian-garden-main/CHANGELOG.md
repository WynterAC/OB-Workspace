## [Unreleased]

### Changed
- Moved important query variables to `Value::` properties instead of [[📇 Terms/🪨 Obsidian/Front Matter|frontmatter]].

## [0.0.0] - 2021-06-13

Initial public release of the [[👩‍🌾 Gardening Tips/🪨  🌳  Obsidian Garden]] - a toolset for knowledge collection, creating connections and nurturing ideas.

In this initial release there is some basic documentation on use, some basic dashboards and a starter struture with templates.

Expect a lot of digging in the garden in the next few days!