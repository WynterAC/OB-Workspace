---
kanban-plugin: basic
type: kanban
description: A basic stucture for creating Kanban boards for your projects
---
%%
Status:: #triage
%%

---
Tags:: #kanban-boad
Links::

---

## Ready to pick up



## In Progress



## Blocked



## Done

**Complete**


