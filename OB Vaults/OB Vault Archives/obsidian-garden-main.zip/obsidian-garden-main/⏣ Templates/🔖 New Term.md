---
type: term
description: A basic structure for a term, these are used to build up your glossary of terms across the knowledge base
---
%%
Status:: #triage 
%%

---
**Tags**:: #term 
**Category**:: <!-- Add a term category for the glossary -->
**Links**:: [[📇 Glossary]]

---

## Definition
<!-- Enter the definition of the term here, such as a dictionary definition or your own. A term can be anything from a concept, a product or a method -->

## Sources
<!-- Link any sources related to the term -->

## Uses
<!-- Provide some example uses of the term, or where it may be used -->