---
type: note
description: A basic note structure with no additional properties other than status and tags and links
---
%%
Status:: #triage 
%%

---
**Tags**:: <!-- Add any tags for this note -->
**Links**:: <!-- Add any links for this note -->

---

> Plant a new 🌱 seed so that 👩‍🌾 you can 🚜 harvest your 🌽 ideas