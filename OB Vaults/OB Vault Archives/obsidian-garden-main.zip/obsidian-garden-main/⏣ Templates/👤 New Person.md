---
type: person
description: A basic structure for capturing the details of a person, they could be a contact or a research subject
---
%%
Status:: #triage
%%

---
**Tags**:: #person <% tp.system.suggester(["This person is a contact", "This person is not a contact"], ["#contact", ""]) %>
**Links**:: [[👨‍👧‍👦 People]]

---

## Biography
<!-- If you have a bio of the person, you can enter it here -->

## Contact Details
<!-- If the person is a contact, put their details here -->
Email:: 
Mobile::
Twitter::
GithHub::

## Links
<!-- Any links go here, like book or article links, links to bios, wiki pages, etc -->

## Notes
<!-- Any additional notes -->