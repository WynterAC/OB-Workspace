---
type: todoList
description: A basic structure for a todo list - inside the list create headers and sets of tasks - you can also add additional notes 
---
%%
Status:: #triage 
%%

---
**Started**:: <!-- Enter a start date and time here -->
**Ended**:: <!-- Enter a end date and time here -->
**Tags**:: #todo-list
**Links**:: [[⏰ ToDo Lists]]

---

## Tasks
- [ ] Task 1

## Notes
