---
type: link
description: A basic structure for a link that you want to collect
---
%%
Status:: #triage 
%%

---
**Link URL**::
**Tags**:: <!-- Add any tags for this note -->
**Links**:: <!-- Add any links for this note -->

---

# Notes