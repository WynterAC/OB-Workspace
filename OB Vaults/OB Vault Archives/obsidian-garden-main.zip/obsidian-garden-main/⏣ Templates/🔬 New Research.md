---
type: research
description: A basic structure for carrying out a research topic with hypothesis, goals and conclusions
---
%%
Status:: #triage 
%%

---
**Tags**:: #research
**Links**:: [[🔬 Research]]

---

## Hypothesis

<!-- What is the hypothesis of this research -->

## Goals
<!-- Are there any assigned goals to this research -->

## Assumptions
<!-- Are there any assumptions about this research -->

## Questions
<!-- What remains for you to consider? -->

## Notes
<!-- Any additional research notes -->

## References
<!-- Link any references here -->

## Conclusion

<!-- What was the conclusion of the research -->