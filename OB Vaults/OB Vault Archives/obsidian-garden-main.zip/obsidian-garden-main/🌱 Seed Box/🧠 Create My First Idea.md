---
type: note
description: Use this file as a place to put your first thoughts down on
---
%%
Status:: #triage
%%

---
**Tags**:: #idea #obsidian #knowledge-management 
**Links**:: [[📇 Terms/🧠 Knowledge Systems/🗃 Knowledge Management]] [[📇 Terms/🪨 Obsidian/🪨 Obsidian]] [[📇 Terms/💡 Concepts/Connection]]

---

## What is your next great idea?

> Plant a new 🌱 seed so that 👩‍🌾 you can 🚜 harvest your 🌽 ideas
> Use this file as a canvas to put down your thoughts.

