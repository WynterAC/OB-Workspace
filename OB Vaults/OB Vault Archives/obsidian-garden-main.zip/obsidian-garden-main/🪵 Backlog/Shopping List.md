---
type: todoList
description: Using a todo list as a shopping list
---
Status:: #ready 
Tags: #todo-list #shopping #backlog
Links: [[⏰ ToDo Lists]]

## Shopping
- [ ] Eggs
- [ ] Milk
- [ ] Bread
- [ ] Cheese
- [ ] NVIDIA GeForce RTX 3090

## Notes
