---
type: todoList
description: The next steps for this garden
---
Status:: #in-progress  
Started:: 2021-06-14
Ended:: <!-- Enter a end date and time here -->
Tags: #todo-list
Links: [[⏰ ToDo Lists]]

## My New Garden Tasks
- [ ] Set up my new garden
- [ ] Think of a project I want to succeed in
- [ ] Start Gathering resources, thoughts, ideas

## Notes

> 🥔 I'm a tiny potato and I believe in you
