---
type: tutorial
description: A tutorial on using tags in Obsidian to create richer links between data
---
%%
Status:: #triage 
%%

---
**Tags**:: <!-- Add any tags for this note -->
**Links**:: <!-- Add any links for this note -->

---

> Plant a new 🌱 seed so that 👩‍🌾 you can 🚜 harvest your 🌽 ideas