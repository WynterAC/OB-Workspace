---
aliases: [Project Stucture, project structure, projects]
type: tutorial
description: How to use this folder
---
## Projects all the way down
Inside Projects, use it as a normal folder stucture to organise your content - each project can represent something like a website, book, or other project where you need to collect data.

Inside each folder you can replecate some of the garden stucture - create your own sub [[⏰ ToDo Lists]] or [[👨‍👧‍👦 People]] page using tagging and properties to make it more specific.