---
type: person
---
%%
Status:: #done
%%

---
**Tags**:: #person #youtube #obsidian #tutorials
**Links**:: [[👨‍👧‍👦 People]] [[📇 Terms/🧠 Knowledge Systems/🗃 Knowledge Management]]

---

# Links
- [Youtube](https://www.youtube.com/channel/UCPcIIq_EMs2U0QQzEF9qbtA)

# Notes

- Introduced a method via his video [How to use Obsidian to write a book](https://www.youtube.com/watch?v=pP4AeGY2mz4) 