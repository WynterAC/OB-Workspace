---
aliases: [👨🏻‍🌾 Bob]
type: person
description: A person record for Bob, our friendly knowledge gardener
---
%%
Status:: #in-progress 
%%

---
**Tags**:: #person 
**Links**:: [[👨‍👧‍👦 People]] [[👩‍🌾 Gardening Tips/🪨  🌳  Obsidian Garden|🪨 🌳 Obsidian Garden]]

---

# 👨🏻‍🌾 Hi Bob!

Bob is our friendly mentor on how to set up and input content in to your [[📇 Terms/🧠 Knowledge Systems/🌳 Digital Garden|🌳 Digital Garden]].

Bob will be around when you need to know how to [[👩‍🌾 Gardening Tips/🪴 Sowing Your Garden/🌱 Planting Seeds|🌱 plant seeds]], [[📇 Terms/🪨 Obsidian/Link|link]] content together, enrich with [[👩‍🌾 Gardening Tips/🪴 Sowing Your Garden/🏷 Using Tags]] and [[variables]].

Bob will also show to create new [[⏣ Templates]] and use the [[Templater]] tags to generate your content based on rules.

