### <% tp.date.now("YYYY-MM-DD") %>
<% tp.user.author_count() %>