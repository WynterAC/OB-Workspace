---
cssclass: mytools
obsidianUIMode: preview
---

```ad-abstract
title:便捷按钮
collapse: open
`button-ssjj`    `button-xzrw` `button-cggd`
```