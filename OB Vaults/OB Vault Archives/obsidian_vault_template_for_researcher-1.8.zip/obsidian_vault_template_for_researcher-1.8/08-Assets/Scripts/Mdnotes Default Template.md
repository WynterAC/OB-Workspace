---
alias: %(citekey)
tags: unread
rating: ⭐
share: false
ptype: article
---

{{title}}
<cite>{{author}}</cite>

{{DOI}}

{{localLibrary}}

***

### 初读印象

comment:: 


