---
tags: WeeklyNote
searchterm: "#bird"
duration: 1 year
cssclass: 
---

Dates: {{monday:YYYY年MM月DD日}} ~ {{friday:YYYY年MM月DD日}}

## Weekly Todos
- [ ] 1
- [ ] 2


# {{DATE: gggg-ww}}
![[{{monday:YYYY年MM月DD日}}#^1]] 
![[{{tuesday:YYYY年MM月DD日}}#^1]] 
![[{{wednesday:YYYY年MM月DD日}}#^1]] 
![[{{thursday:YYYY年MM月DD日}}#^1]] 
![[{{friday:YYYY年MM月DD日}}#^1]] 
![[{{saturday:YYYY年MM月DD日}}#^1]] 
![[{{sunday:YYYY年MM月DD日}}#^1]] 

# Weekly Log
## Weight
```ad-kanban
- [[小灰灰]]
- [[胖胖]]
```
