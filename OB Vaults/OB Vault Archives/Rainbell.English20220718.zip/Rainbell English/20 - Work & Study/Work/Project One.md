---
target: tasks
status: in progress
tags: project/open work
---

# Project progress overview

- [x] 1
- [ ] 2
- [ ] 3

# Basic Information

Written :: [[Qin]]
Time :: 2022-02-01
Department :: Game Department
Reviewer :: [[One]]
Review :: 2022-05-18

Project :: Get a Silver Medal
Version :: 0.0.0

# project instruction
| Project Approval Department | Project Name | Version Number | Project Applicator | Application Time |
| -------- | -------- | ------ | ---------- | -------- |
| R&D Department | | | | |


## background

The background of the pending project.

## Project scope
- Analysis of user needs;
- Development Scope (Product Design)
- Market and marketing feasibility analysis
- Feasibility analysis of developing technical solutions
- Feasibility analysis of time resources

## Objectives and acceptance criteria
- Anticipated business goals
	- main target
- Staged goals
	- Quality goal
- Quantitative acceptance criteria

## Strategy
- Project preliminary plan

## resource
- manpower, funds, equipment, facilities, technology, methods, information, time
- Project manager, project composition
- Project Executive Committee, Project Steering Committee


## Budget
- project budget

## time plan

## Risks and Issues

- potential risks
- Project estimates
- Schedule
- Technical conquer
- Personnel in place
与此原文有关的更多信息要查看其他翻译信息，您必须输入相应原文
发送反馈
侧边栏