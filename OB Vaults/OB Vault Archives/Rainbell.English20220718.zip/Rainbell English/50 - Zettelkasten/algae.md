---
tags: zettelkasten 生词/英文 
---
alga /ˈalgə/ noun. Pl. algae /ˈaldʒi:, ˈalgi:/. M16.
Latin = seaweed.

description :: 水藻

_Algae_ is actually the plural form of the word _alga_, which in Latin means, you guessed it: "seaweed." Algae isn't just something gross looking floating on the water. It's actually important in aquatic ecology because the tiny organisms that live suspended in algae are the food base for most marine food chains.