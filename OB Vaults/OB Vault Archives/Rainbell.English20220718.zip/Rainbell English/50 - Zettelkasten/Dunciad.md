---
tags: zettelkasten 生词/英文 
---

description :: a mock epic poem by Alexander Pope, satirizing literary dunces

