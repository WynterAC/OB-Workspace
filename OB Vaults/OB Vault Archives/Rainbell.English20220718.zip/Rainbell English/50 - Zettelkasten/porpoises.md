---
tags: zettelkasten 生词/英文 
---

description:: 鼠海豚

鼠海豚（学名*Phocoenidae*），鲸目的一科，体型非常像海豚，但吻部不尖，又像鲸，共分为三个属

![](https://wiki-gateway.eudic.net/wikipedia_en/I/m/Phocoena_phocoena.2.jpg)