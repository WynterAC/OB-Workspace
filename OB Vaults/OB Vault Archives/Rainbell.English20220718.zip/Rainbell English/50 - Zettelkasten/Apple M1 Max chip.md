---
tags: computer zettelkasten
---
description :: 基于ARM的用于Macbook Pro的芯片。

The Apple M1 Pro and M1 Max are systems-on-chip (SoC) designed by Apple Inc. for the MacBook Pro laptop and the Mac Studio desktop, based on the licensed ARM architecture, and manufactured on TSMC's N5 process. They were announced at an Apple event on October 18, 2021.

