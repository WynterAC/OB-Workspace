---
tags: zettelkasten 生词/英文 
---

description:: 本初子午线，正午的；经络的

meridian channels