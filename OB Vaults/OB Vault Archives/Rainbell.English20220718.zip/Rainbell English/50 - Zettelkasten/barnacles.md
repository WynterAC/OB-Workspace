---
tags: zettelkasten 生词/英文 
---

description:: 藤壶

a marine [[crustacean]] with an external shell, which attaches itself permanently to a surface and feeds by filtering particles from the water using its modified feathery legs.

![](https://wiki-gateway.eudic.net/wikipedia_en/I/m/Anim1032_-_Flickr_-_NOAA_Photo_Library.jpg)