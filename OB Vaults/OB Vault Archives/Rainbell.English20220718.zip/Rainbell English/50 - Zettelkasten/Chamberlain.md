---
tags: zettelkasten 生词/英文 
---

description:: 内务大臣
_historical_ an officer who managed the household of a monarch or noble.