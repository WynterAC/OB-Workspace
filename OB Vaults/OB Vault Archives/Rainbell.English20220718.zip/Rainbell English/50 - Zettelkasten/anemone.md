---
tags: zettelkasten 生词/英文 
---
/əˈnɛməni/

description :: 海葵。

_Anemone_ is a Greek word that means "windflower" or literally "daughter of the wind," from _anemos_, "wind," and the feminine suffix _-one_.