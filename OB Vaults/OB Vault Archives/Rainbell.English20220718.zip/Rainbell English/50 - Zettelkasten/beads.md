---
tags: zettelkasten 生词/英文 
---

description:: 祈祷（来源于bid）

sing. & (usu.) in pl. Prayer; devotions, latterly spec. using a rosary. arch. OE

