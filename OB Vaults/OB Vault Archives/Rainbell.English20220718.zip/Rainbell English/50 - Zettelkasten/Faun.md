---
tags: zettelkasten 生词/英文 
---

description:: （罗马神话）农牧神

_Roman Mythology_

one of a class of lustful rural gods, represented as a man with a goat's horns, ears, legs, and tail.