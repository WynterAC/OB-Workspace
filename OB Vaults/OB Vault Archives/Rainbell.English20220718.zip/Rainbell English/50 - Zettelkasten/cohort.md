---
tags: zettelkasten 生词/英文 
---

A _cohort_ is a group of people who are around the same age, like a _cohort_ of college students who have similar experiences and concerns.

  
description :: Roman History. A body of infantry of the Roman army, ten of which made up a legion; a body of auxiliary troops or (later) of cavalry of similar strength. LME.