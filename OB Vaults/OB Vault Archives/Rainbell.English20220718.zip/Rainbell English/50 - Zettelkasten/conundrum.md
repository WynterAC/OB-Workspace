---
tags: zettelkasten 生词/英文 
---

description :: 谜题

Pronunciation: Brit.sound/kəˈnʌndrəm/, U.S.sound/kəˈnəndrəm/

