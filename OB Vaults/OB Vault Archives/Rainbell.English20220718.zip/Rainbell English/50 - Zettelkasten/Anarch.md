---
tags: zettelkasten 生词/英文 
---

description :: < Greek _ἄναρχ-ος_ without a chief or head; compare French _anarche_ in Cotgrave 1611. But the English use is conformed to that of other derivatives in _-arch_, as _monarch_, _tetrarch_, etc.