---
tags: zettelkasten computer operator
---

description :: &是解引用运算符*的逆运算。因此*&s等价于s。