---
tags: 
title: Scratchpad
date created: Thursday, December 8th 2022, 2:42:09 am
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

- resource link 1
- some thought I had
- ==a **really** relevant thought==
- ~~turns out not so much actually~~
- [x] revisit this thought i had on a walk and turn it into a note
