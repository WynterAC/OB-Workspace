---
tags: []
title: Scratchpad
date created: Friday, December 9th 2022, 1:09:12 am
date modified: Wednesday, December 14th 2022, 4:07:30 pm
---

> [!info] shimmering obsidian scratchpad
> if you're using [Shimmering Obsidian](https://github.com/chrisgrieser/shimmering-obsidian), this can be your scratchpad file