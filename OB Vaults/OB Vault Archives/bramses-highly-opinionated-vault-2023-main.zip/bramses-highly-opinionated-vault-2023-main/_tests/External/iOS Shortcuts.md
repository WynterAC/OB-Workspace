---
tags: 
title: iOS Shortcuts
date created: Thursday, December 8th 2022, 5:14:43 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---
`todo`