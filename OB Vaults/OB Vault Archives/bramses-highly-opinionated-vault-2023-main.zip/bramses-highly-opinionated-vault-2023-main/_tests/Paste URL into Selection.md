---
tags: 
title: Paste URL into Selection
date created: Thursday, December 8th 2022, 12:18:37 am
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

>[!info]
>Test to check pasting URL into selected text

Here's a link: https://obsidian.md/

1. Copy the link
2. Highlight this text -> Obsidian <- and paste the URL
3. See if you can paste it directly, you should see [Obsidian](https://obsidian.md/)
