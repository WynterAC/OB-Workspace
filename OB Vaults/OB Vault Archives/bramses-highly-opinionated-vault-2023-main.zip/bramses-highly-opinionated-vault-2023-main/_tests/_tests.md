---
tags: 
title: _tests
date created: Wednesday, December 7th 2022, 11:26:33 pm
date modified: Wednesday, December 14th 2022, 3:33:55 pm
---

>[!info]
>Sometimes plugins get updated and things break. It's ok! This folder will give you an idea if something doesn't work to spec

%% Begin Waypoint %%
- **External**
	- [[Alfred]]
	- [[GitHub]]
	- [[iOS Shortcuts]]
	- [[_tests/External/Readwise]]
- [[Paste URL into Selection]]
- [[Private]]
- [[Project Management]]

%% End Waypoint %%