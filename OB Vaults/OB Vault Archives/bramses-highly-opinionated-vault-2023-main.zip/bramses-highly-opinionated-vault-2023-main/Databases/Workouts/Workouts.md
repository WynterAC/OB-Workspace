
%% Begin Waypoint %%
- [[Squats]]

%% End Waypoint %%