---
aliases: [Lorem Ipsum]
tags: [zettel]
projects: []
title: Lorem Ipsum
linter-yaml-title-alias: Lorem Ipsum
date created: <% tp.date.now("dddd, MMMM Do YYYY, h:mm:ss a") %>
date modified: <% tp.date.now("dddd, MMMM Do YYYY, h:mm:ss a") %>
---

# <% tp.system.prompt("What is the title of this Zettel?") %>

<% tp.system.clipboard() %>[^1]

[^1]: Lorem ipsum dolor sit amet