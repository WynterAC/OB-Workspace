---
tags: [recipes]
title: Recipes
date created: <% tp.date.now("dddd, MMMM Do YYYY, h:mm:ss a") %>
date modified: <% tp.date.now("dddd, MMMM Do YYYY, h:mm:ss a") %>
---

# <% tp.system.prompt("What is the name of this recipe?") %>

## PDF