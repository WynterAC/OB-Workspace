---
aliases: [People]
tags: [people]
phone:
email:
url:
instagram:
twitter:
linkedin:
birthday:
lastContacted:
relationship:
title: People
linter-yaml-title-alias: People
date created: Friday, December 9th 2022, 12:06:08 pm
date modified: Thursday, December 15th 2022, 1:02:29 pm
---

# <% tp.system.prompt("What Is the Full Name of This person?") %>

## Notes
