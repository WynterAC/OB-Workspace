---
tags: [articles, to-process]
author: DSF Antique Jewelry
fullTitle: The Ancient Japanese Technique That Produces Lumber Without Cutting Trees
category: #articles
url: "https://dsfantiquejewelry.com/blogs/interesting-facts/the-ancient-japanese-technique-that-produces-lumber-without-cutting-trees"
projects: [Test Project]
title: The Ancient Japanese Technique That Produces Lumber Without Cutting Trees
date created: Thursday, December 8th 2022, 5:17:13 pm
date modified: Wednesday, December 14th 2022, 5:21:18 pm
---


## Highlights
---

> ![](https://cdn.shopify.com/s/files/1/0142/3405/8816/files/poza1_4.jpg?v=1652662357) ([View Highlight](https://read.readwise.io/read/01gkm5mj94j7xhptk1663cbm0s))

---
---


> The shoots are carefully and gently pruned by hand every two years leaving only the top boughs, allowing them to grow straight. Harvesting takes 20 years and old 'tree stock' can grow up to a hundred shoots at a time ([View Highlight](https://read.readwise.io/read/01gkm5n9a625vhyfqca6xaak1t))[^1]

---

[[202212120002]][^2]

---
---

## New highlights added December 12, 2022 at 12:00pm #to-process [^3]

> The shoots are carefully and gently pruned by hand every two years leaving only the top boughs, allowing them to grow straight. Harvesting takes 20 years and old 'tree stock' can grow up to a hundred shoots at a time ([View Highlight](https://read.readwise.io/read/01gkm5n9a625vhyfqca6xaak1t))

[^1]: an example of a raw highlight passed in from Readwise

[^2]: the same example converted into a Zettelkasten using Progressive Summarization leveraging the clipboard + new note combo

[^3]: an example of a highlight coming in later and re inserting it into the [[To Process]] notes. Once processed, simply delete the "to-process" tag in the header
