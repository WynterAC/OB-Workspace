---
banner: https://wallpapercave.com/wp/wp4957445.jpg
banner_x: 0.5
banner_y: 0.6486
---
⠀
# Weekly Overview
```dataview
LIST
FROM "03 Periodic/02 Weekly"
SORT file.name DESCENDING
WHERE file.name != "02 Weekly"
LIMIT 8
```
