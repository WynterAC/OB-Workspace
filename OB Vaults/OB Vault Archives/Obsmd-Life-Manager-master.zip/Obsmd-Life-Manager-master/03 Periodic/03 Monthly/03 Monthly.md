---
banner: https://i.pinimg.com/originals/9d/1f/2e/9d1f2e441590c09d737125a61b5f5281.png
banner_x: 0.5
banner_y: 0.53614
---
⠀
# Monthly Overview
```dataview
LIST
FROM "03 Periodic/03 Monthly"
SORT file.name DESCENDING
WHERE file.name != "03 Monthly"
LIMIT 12
```
