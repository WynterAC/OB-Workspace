---
tags: monthly-note
month: 01-Jan
year: 2022
banner: https://preview.redd.it/arqa352ph7x61.jpg?width=960&crop=smart&auto=webp&s=84f9245d607b029667d5bfc4abf36547fc6213de
---
⠀
###### [[2022-W01|↶ PREVIOUS WEEK]] ⁝ [[2022-W03|FOLLOWING WEEK ↷]]
# ◌ 2022 - 02-February

## Weeks
```dataview
TABLE
month as "Month"
FROM "03 Periodic/02 Weekly"
WHERE month = "2022 - 02-February"
```

## Days
```dataview
TABLE
month as "Month"
FROM "03 Periodic/01 Daily"
WHERE month = "2022 - 02-February"
```