# Periodic Notes
The periodic notes act as a daily tasks page, a habit tracker, periodic reviews, and whatever else you'd like!

It is highly recommended to create the periodic notes either from the periodic notes icon in the sidebar, or from the calendar. Failure to do so could result in the folder structure of the periodic notes to get wonky. (I.E. A week in march showing up in the folder for Feb.)

The weekly and monthly notes simply have a dataview of the contained days and weeks. You are encouraged to pull in whatever other data you find useful in these.

## More Info
- [[Daily Note]]
- [[Weekly Note]]
- [[Monthly Note]]