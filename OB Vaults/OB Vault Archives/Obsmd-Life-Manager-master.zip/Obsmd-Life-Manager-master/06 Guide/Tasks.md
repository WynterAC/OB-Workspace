[[‼️ Overdue Tasks]]  ⠀•⠀ [[🗓️ Upcoming Tasks]]  ⠀•⠀ [[☑️ Completed Tasks]]
  
---
## All Tasks
Shows all incomplete tasks not associated with a project.
*tasks code*
```
tasks
not done
hide task count
hide backlinks
path includes Tasks
sort by due reverse
```
## Project Tasks
Shows all incomplete tasks associated with a project.
*tasks code*
```
tasks
not done
hide task count
path includes Projects
sort by path
```