---
tags: project
---
# Completed Project

[Goal :: [[Create Cool Stuff]]]  ⠀•⠀ [Deadline :: 📅 2022-02-27 ] ⠀•⠀ [Complete :: ✅]
[Target :: To complete this project]


---
### Tasks
- [x] I did a this! 📅 2022-02-26 ✅ 2022-02-28