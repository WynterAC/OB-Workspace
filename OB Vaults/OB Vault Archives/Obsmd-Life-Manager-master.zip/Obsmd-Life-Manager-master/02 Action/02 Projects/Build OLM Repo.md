---
tags: project
---
# Build OLM Repo

[Goal :: [[Create Cool Stuff]]]  ⠀•⠀ [Deadline :: 📅 2022-02-28 ] ⠀•⠀ [Complete :: ❌]
[Target :: Publish it]


---
### Tasks
- [ ] Finish Build 🔼 📅 2022-02-27
- [ ] Finish Guide 🔼 📅 2022-02-28