---
tags: project
---
# Make homemade pesto

[Goal :: [[Learn to make pastas]]]  ⠀•⠀ [Deadline :: Invalid date] ⠀•⠀ [Complete :: ❌]
[Target :: Make a tasty pesto]


---
### Tasks
- [ ] Buy herbs & garlic 🔼 📅 2022-02-28
- [ ] Find recipe ⏫ 📅 2022-02-28