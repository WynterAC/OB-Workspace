---
tags: goal
---
# Create Cool Stuff

[Why :: Because why wouldn't you]  ⠀•⠀ [Value:: [[Prolific]]]  ⠀•⠀ [Deadline :: 📅 2022-03-06]  ⠀•⠀ [Complete :: ❌]

---
## Related Projects
```dataview
TABLE
	target AS "Target",
	goal AS "Goal",
	deadline as "Deadline",
	complete as "Complete"
FROM "02 Action/02 Projects"
WHERE goal = [[Create Cool Stuff]]
SORT complete DESCENDING
```