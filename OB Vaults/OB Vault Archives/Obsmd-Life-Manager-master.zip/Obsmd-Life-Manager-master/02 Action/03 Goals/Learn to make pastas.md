---
tags: goal
---
# Learn to make pastas

[Why :: For zest!]  ⠀•⠀ [Value:: [[Be Zesty]]]  ⠀•⠀ [Deadline :: 📅 2022-03-06]  ⠀•⠀ [Complete :: ❌]

---
## Related Projects
```dataview
TABLE
	target AS "Target",
	goal AS "Goal",
	deadline as "Deadline",
	complete as "Complete"
FROM "02 Action/02 Projects"
WHERE goal = [[Create Cool Stuff]]
SORT complete DESCENDING
```