[[01 Tasks|All Tasks]]  ⠀•⠀ [[🗓️ Upcoming Tasks]]  ⠀•⠀ [[☑️ Completed Tasks]]

---
```tasks
not done
due before today
sort by due
```