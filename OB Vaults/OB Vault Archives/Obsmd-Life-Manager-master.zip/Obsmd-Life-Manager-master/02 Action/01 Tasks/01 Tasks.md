---
banner: https://onedesblog.com/wp-content/uploads/2021/07/landscape-minimal-mountains-art-wallpaper.jpg
---
⠀
[[‼️ Overdue Tasks]]  ⠀•⠀ [[🗓️ Upcoming Tasks]]  ⠀•⠀ [[☑️ Completed Tasks]]
  
---
## All Tasks
```tasks
not done
hide task count
hide backlinks
path includes Tasks
sort by due reverse
```
## Project Tasks
```tasks
not done
hide task count
path includes Projects
sort by path
```