---
cssClasses: cards
banner: https://wallpaperboat.com/wp-content/uploads/2019/06/minimalist-desktop-36.jpg
---
⠀
# Values Dashboard
```dataview
TABLE
why AS "Why"
FROM "02 Action/04 Values"
WHERE file.name != "04 Values"
```