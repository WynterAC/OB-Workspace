---
aliases:
date: <% tp.date.now() %>
type: definition
subject: $SUBJECT
field: $FIELD
lecture: $LECTURE
difficulty:
tags:
---

> [[$SUBJECT]]
> [[$LECTURE]]

# Definition

