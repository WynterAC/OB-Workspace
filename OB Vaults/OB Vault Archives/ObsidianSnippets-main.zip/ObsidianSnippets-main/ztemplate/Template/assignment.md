---
date: <% tp.date.now() %>
duedate: $DUEDATE
status: not started
type: assignment
subject: $SUBJECT
---
