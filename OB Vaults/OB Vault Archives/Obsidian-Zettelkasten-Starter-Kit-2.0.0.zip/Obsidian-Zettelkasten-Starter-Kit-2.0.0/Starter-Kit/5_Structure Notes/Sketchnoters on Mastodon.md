---
tags: type/structure structure/list
#theme/ - build cluster 
#index/ - define entry point
# 
#type/ - how note looks like
#source/ - where note comes from
#target/ - where note will go to
# 
#chart/ - from #type/chart 
#kanban/ - from #type/kanban
#role/ - from #type/person
#structure/ - from #type/structure
#visual/ - from #type/visual
#
aliases: 
created: 2022-11-26, 15:50
modified: 2022-11-26, 15:50
---

# Sketchnoters on Mastodon

<!-- Main content of my thoughts really -->

**Bildung**  
- Katha Bluhm - https://bildung.social/@kathabluhm

**Darmstadt**
- Edmund Gröpl - https://darmstadt.social/@groepl

**Hessen**
- Christopher Henke - https://hessen.social/@christopherhenke
- Edmund Gröpl - https://hessen.social/@groepl

**Kopfkino**
- Klaus Eck - https://kopfkino.social/@Klauseck

**Mastodon**
- Makayla Lewis - https://mastodon.social/@maccymacx - 12.11.2022
- Mauro Toselli - https://mastodon.social/@xLontrax - 23.11.2016
- Mike Rohde - https://mastodon.online/@rohdesign - 04.11.2022
- Tanmay Vora - https://mastodon.social/@tnvora - 08.11.2019
- Claudio Nichele - https://mastodon.online/@Cnichele65 - 31.10.2022
- Alberto Cairo - https://mastodon.social/@albertocairo - 28.10.2022

**Mastodon.green**
- Franziska Köppe - https://mastodon.green/@madiko

**Toot Berlin**
- Nadine Roßa - https://toot.berlin/@nadine - 08.04.2017

**Troet cafe**
- https://troet.cafe/@inessketchnoted
- Ralph Rute - https://troet.cafe/@ralphruthe - 26.04.2022
- Tobias Vogel - https://troet.cafe/@kriegundfreitag - 26-04.2022

---
## Questions
<!-- What remains for you to consider? --> 
- .

## Terms
<!-- Links to definition pages -->
- [Mastodon](Mastodon.md)

## References
<!-- Links to pages not referenced in the content -->
- https://contentnation.net/de/favstarmafia/artikel2











