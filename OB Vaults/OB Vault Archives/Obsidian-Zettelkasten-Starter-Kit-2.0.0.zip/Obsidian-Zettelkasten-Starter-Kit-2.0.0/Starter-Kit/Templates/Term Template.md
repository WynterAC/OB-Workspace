---
tags: type/term
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
lead: +++ Term definition goes here +++
source: +++ source undefined +++
visual:
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Term
template-version: "1.8"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!-- Term definition and source from frontmatter goes here. Also used for Dataview glossary. -->

> [!Definition]
> `= this.lead`
>  — `= this.source`

<!-- Additional term description if needed -->


---
## References
<!-- Links to pages not referenced in the content -->
- 


