---
tags: type/structure structure/bujo
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: BuJo Weekly
template-version: "1.3"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}


![[{{monday:gggg-MM-DD ddd}}]] 
![[{{tuesday:gggg-MM-DD ddd}}]] 
![[{{wednesday:gggg-MM-DD ddd}}]] 
![[{{thursday:gggg-MM-DD ddd}}]] 
![[{{friday:gggg-MM-DD ddd}}]] 
![[{{saturday:gggg-MM-DD ddd}}]]
![[{{sunday:gggg-MM-DD ddd}}]]