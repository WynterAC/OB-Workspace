---
tags: type/person, role/expert
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
birthday:
bio_short:
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Expert
template-version: "1.7"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

## Bio
<!-- Short biography of the EXPERT -->

> [!Bio short]
> `= this.bio_short`

## Skills
- 

## Community
<!-- Only most important I‘ve read -->
- 


## Notes
<!-- The main content of my thoughts really -->
- 


## Quotes
<!-- Notable quotes with reference to their page or location -->
- 

---
## Questions
<!-- What remains for you to consider? -->
- 

## References
<!-- Links to pages not referenced in the content -->
- 



