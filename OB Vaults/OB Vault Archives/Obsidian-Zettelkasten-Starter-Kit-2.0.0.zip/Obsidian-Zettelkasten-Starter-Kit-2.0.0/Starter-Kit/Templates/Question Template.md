---
tags: type/question
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases:
lead:
visual:
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Question
template-version: "1.7"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!-- Detailed question from short title in front matter -->

> [!Question]
> `= this.lead`

<!-- Answer the detailed question  -->



---
## Terms
<!-- Links to definition pages -->
- 

## References
<!-- Links to pages where the answer is used for -->
- 











