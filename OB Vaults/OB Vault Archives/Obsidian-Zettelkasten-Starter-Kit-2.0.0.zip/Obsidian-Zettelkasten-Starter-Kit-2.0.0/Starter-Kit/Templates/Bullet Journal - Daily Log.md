---
tags: type/structure structure/bujo
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: BuJo Daily
template-version: "1.3"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

- 