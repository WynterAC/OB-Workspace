---
tags: type/quote
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
quote: 
author:
year:
visual:
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Quote
template-version: "1.6"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!-- Quote and author from frontmatter goes here. Also used for Dataview list of quotes. -->

> [!QUOTE]
>  `= this.quote`
>  — `= this.author`


---
## Annotations
<!-- Context, questions, own ideas for usage, … -->
- 


## References
<!-- Links to pages, internal and external, not referenced in the content -->
- 













