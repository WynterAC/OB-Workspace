---
tags: type/structure structure/list structure/bujo
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: BuJo Future
template-version: "1.4"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---
# Future Log {{Title}}

<!-- Main STRUCTURE of my content -->
[Future Log Archive](Future%20Log%20Archive.md) | [[2023]] | [Ideas 2022](Ideas%202022.md) | [Vision Board 2022](Vision%20Board%202022.md)
___

**Objectives & Key Results | 3-4 & 1-4**


___

**Key Actions | 1+**


___

**Tasks**


___

**January**

**February**

**March**

**April**

**May**

**June**

**July**

**August**

**September**

**October**

**November**

**December**


___
##### Questions
<!-- What remains for you to consider? --> 
- 

##### Terms
<!-- Links to definition pages -->


##### References
<!-- Links to pages not referenced in the content -->
