# <% tp.file.title %>

### Metadata
authors: 
citation key:
link to file: 
topics: 
status: #status/maybe-consume
type: #source/paper
date added: <% tp.date.now("YYYY-MM-DD") %>

---

## Summary and high-level thoughts



## Highlights