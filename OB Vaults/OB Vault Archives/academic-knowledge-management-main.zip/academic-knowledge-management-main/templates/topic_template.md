# <% tp.file.title %>

### Metadata
topics: 
type: #topic


### Self-test and recall questions


### Remaining to do / to understand


---

## Summary and high-level thoughts



### subheading 1



### subheading 2



### subheading 3



---

## References
- [add the atomic papers here, plus any other related resources]
- 
