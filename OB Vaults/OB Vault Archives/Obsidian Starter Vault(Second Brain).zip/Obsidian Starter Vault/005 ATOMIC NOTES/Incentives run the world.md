> It is difficult to get a man to understand something when his salary depends on his not understanding it — Upton Sinclair

If you don't understand incentives you can't rise above the limits set for you by the society.

I used to watch videos of Sajan Shrestha where he used to react on funny videos. I wondered why the fuck is he laughing so hard. Once I understood incentives, it was clear. He laughs so hard because thats what he is getting paid for. They are getting paid for spreading the fake news and creating 

Last week, I was at the end of semester. I had barely attended any classes. Our topper friend was there to help. He decided to take a class. He was so good that he finished the whole course which took the teachers 6 months to teach.

You see all these fake news and bullshit on facebook and youtube. Even the makers know that these news are bullshit. But they get more views, clicks and ultimately money, they will keep doing that.

I don't think, the teachers can't do that. They can do better. But they are being paid for teaching the course for 6 months. They won't be paid if the course is finished in a week.

Incentives drive human behavior and once you understand you unlock the fast track to reaching your potentials.



----
**Type:** #permanentnote 
**Topics:**
**Reference:** 

