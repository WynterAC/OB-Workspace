It's common to have multiple interests, to want to do all things. But practically, thats not possible. Don't be distracted with every shiny idea or project. 

Trying to do multiple things will accomplish none. Don't try to juggle them all at once. 

Set clear priorities on what you'd like to do and stick to it even just for a month or few months. Let ideas incubate. See through it. You might not attain mastery in three months but you will go further than the person merely thinking about doing those projects.

There's a difference between being good and thinking about being good. 


----
**Type:** #permanentnote 
**Topics:** [[Priortize & Focus]]
**Reference:** [[You’re Trying to Do Too Much. Why our enthusiasm fails to translate]]

