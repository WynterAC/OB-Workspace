Time is the most valuable thing in the world. It passes so quickly. It feels as if yesterday I was there. I just joined college yesterday, but I am one year short of graduation. 

Where has the time gone? What have I done with all that time? I can't grieve on the time that's lost but I can use this moment for better. 

I have to set clear priorities on what I want. Whatever I want to do, I have to do now. I don't have tomorrow. 

Five years from now, I don't want to be wondering where all the time went by.

Life is short. You can't redeem your time. But you can invest your time on to building memories, experiences, and learning. 

----
**Type:** #permanentnote 
**Topics:** [[Time is Precious]] [[Protect your time]] [[Procrastination]]
**Reference:** [[Life is short. Live every day for god]]

