Everyone is a content creator. Most people don't realize this. 

If you are posting photos on instagram, writing on twitter, or posting in facebook, you are already a creator. 

You only need to be more intentional about what you are publishing online. Then with a little guidance and direction you can start to make money doing what you are already doing. 



----
**Type:** #permanentnote 
**Reference:** [[My Unsexy Income Streams are Low-Key Easy to Recreate]]

