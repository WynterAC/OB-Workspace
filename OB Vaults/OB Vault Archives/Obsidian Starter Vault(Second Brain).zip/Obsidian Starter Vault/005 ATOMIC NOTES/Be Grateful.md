
**Reference:** [[The Almanack of Naval Ravikant]]
**Type:** #permanentnote 
**Topics:** [[Happiness]] [[Success]]
**Related:** [[Happiness is a skill]] 

----


The secret to happiness is to be grateful. As humans, we take everything for grated. We don't look around and see all the blessings we have. Some people don't even find anything to be grateful for.

We are sitting indoors, wearing clothes, walking and communicating with each other through time and space. Instead we should be two monkeys sitting in the jungle right now watching the sun going down, asking ourselves if we'd survive till tomorrow.

There are so many gifts adn abundance that we have around us all the time. Realizing this and ebing grateful for all these things we have is a trick to be happy.