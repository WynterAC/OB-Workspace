To be a good trader, you have to win fear. And to win fear you have to take away the greed of making money. You have to be free. 

Only when you are free from fear and greed, your skill will unleash. You will play the game unbiased. And when you start playing the game without the fear of losing, without the greed of winning, you will be a good trader.

Making or losing money  doesn't matter in this game. What matters is you playing the game. 

If you play with the goal of making money, you will not be able to play well. You will suffer. You will always have fear in your head that will stop you from giving your best. 

Not playing to make money doesn't mean you have to stop thinking about making money. Its what the fools think and do. 

The wise is the one who focuses on perfecting his skill. He who is always improving, learning and studying himself and the market. 

And when he trades, he trades without fear. He has nothing to lose. 


----
**Type:** #permanentnote 
**Topics:** [[How to Master Trading]]
**Reference:** [[A Master's Secret Whispers]]]

