Before the time of internet, every activity had a end. You start reding a book, watch a movie, or go out with your friends. All of these things ended after a certain time.

But with internet and internet activities, there's no end. You open facebook, instagram, youtube or even google, there's no end. You can scroll endlessly. 

This makes it harder to stop using them. Also when we post something online, the reactions are not all at once. They come one by one. This forces us to keep checking our social media profile every 5 minutes. Which makes it harder to fully focus on what you are doing at the moment. 