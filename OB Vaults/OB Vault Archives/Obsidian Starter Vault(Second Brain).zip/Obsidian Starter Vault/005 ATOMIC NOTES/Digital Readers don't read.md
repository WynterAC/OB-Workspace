Digital readers don't read like others. Heck, they don't even read. They skim.

They have too many things fighting their attention. They quickly skim to see if they have anything valuable to takeaway from there.

They make judgments in mini-seconds to determine whether something is worth their time or not. 

They only start reading after they are convinced that there's something that speaks to their interests.


----
**Type:** #permanentnote 
**Topics:**  [[Fundamental Truths About Writing Online]]
**Reference:**  [[Are Your Medium Articles Skimmable If Not, You’re Losing Views]]

