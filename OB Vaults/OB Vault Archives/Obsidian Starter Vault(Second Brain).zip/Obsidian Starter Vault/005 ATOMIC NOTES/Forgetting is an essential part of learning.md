Imagine, if you remembered everything that you have ever read, ever watched, or experienced. Your brain will probably pop out. 

Forgetting is an essential part of the learnin process. Your brain forgets almost 95% you feed to it after a few days. What will your brain do with the trash information anyways. So it takes care of the trash by forgetting. It will not remember anything that's not important.

If you need to learn or remember something, you need to signal you brain about its importance. You can do so by disturbing the forgetting curve. You can practice spaced repitition. 

----
**Type:** #permanentnote 
**Topics:** [[How to learn anything fast]]
**Reference:** [[Master Learning and Unlock Your Potential]]

