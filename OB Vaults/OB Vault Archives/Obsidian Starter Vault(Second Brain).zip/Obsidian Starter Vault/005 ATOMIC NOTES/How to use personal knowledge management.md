We are living in an age of information abundance. Everywhere you look is new information seeking your attention. 

The purpose of PKM is to collect the information and store it so that it can be helpful in future. 

Unlike what we used to do in the past, collect information, store it somewhere and forget about it. It doesn't do any work. 

You have to follow a different path. Here's a better way to make the best use of personal knowledge manangement.
- Capture new ideas and information as you find it
- Process and add enough context so that it can be relevant to you in future. 
- Let the ideas incubate
- Make connection between ideas
- Create new things out of those ideas.
> The primary purpose of personal knowledge management is creation. It is to make the process of creation easy. 


----
**Type:** #permanentnote 
**Topics:** 
**Reference:** [[004 ARCHIVE/4 Steps to Smart Personal Knowledge Management for Digital Marketers]]

