[[Trading plan]] is essential for trading success. As someone said failing to plan is planning to fail. Trading plan should be written in a stone. It is subject to reevaluation and adjustment according to the market condition but you shouldn't be always looking to modify it as you wish. 

A trading plan should have following things:
- Clear indication as to in which condition to enter a trade(Strategies)
- When to exit
- When to take profits
- Stop loss
- Proper risk management


> Treat trading as a business and not as gambling. 