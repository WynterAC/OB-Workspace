Most parents are doomed from the beginning. They start playing the role of a father or mother. A parent never sees his child as another human being. 

When you play a role of a parent, you only see from that perspective. 

If you want to be a good parent, you have to release yourself from the role of parent. See your child as just another human being. 


----
**Type:** #permanentnote 
**Topics:** [[Parenting]]
**Reference:** [[A Master's Secret Whispers]]

