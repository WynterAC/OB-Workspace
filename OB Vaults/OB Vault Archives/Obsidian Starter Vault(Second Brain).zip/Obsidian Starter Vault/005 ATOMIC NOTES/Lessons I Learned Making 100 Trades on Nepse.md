The biggest risk is in not taking the risk.
1. Buying in the month of Asar is not a wise decision. (Don't trade when there is unstability in the market)
2. Don't act like you know the market.
3. Don't interrupt a stock when it has just started making a move from correction
4. **Never make a trade without stop loss**
5. Don't decide in a live market with a fear of missing out.
6. Don't buy the index leader. Choose others undervalued stocks  in the trending index
7. Don't Sell if it is a minor correction only.
8. Know when to exit before you enter a trade. Don't wait and wait and wait in hope.
9. **Don't expect the market to move as you think. Stick with your strategy and be disciplined about it**
10. When external factors cause market to sharply decrease or increase, it is often reversed. In this case, the market follows netwons' third law of motion. Every action has equal and opposite reaction.
11. Don't run in a trade with the fear of missing out. The market is always open and will provide some better opportunities in the future to trade.
12. Wait for the market to retest or buy at the breakout. Don't buy in the middle of the market. It will make the loss heavier and profit less
13. Don't fight against the mass. Ride the wave. 
14. *When the market is going down and its nearing strong support* if it drops heavily during the first hour due to fear, its a good time to profit using intraday trading. Don't buy with the thought of holding for the long term.
15. 