Digital gardens are on the rise these days. They are somewhat similar to blogs but unlike blogs, they don't follow any rules.

They are not polished to perfection. Rather they are work-in-progress. They are a representation of what you think an d believe at the moment. 

They allow you to share as you learn not after a decade when you are an expert. 

With digital gardens, you are not intending to talk to a larger audience. You are talking to yourself. You are having a conversation with yourself. 

You discover new ideas. You think and connect with the previous ideas. Your garden evolves as you grow. 


----
**Type:** #permanentnote 
**Topics:** [[Note-taking]] [[Writing]]
**Reference:** [[004 ARCHIVE/Digital Gardens Let You Cultivate Your Own Little Bit of the Internet]]

