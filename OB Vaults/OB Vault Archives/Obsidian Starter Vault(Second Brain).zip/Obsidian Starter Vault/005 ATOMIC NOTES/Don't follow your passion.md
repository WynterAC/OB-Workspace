“Follow your passion is dangerous advice.” The path to happiness or fulfillment is quite more complicated than just asking yourself “what should I do with my life?”

There are people who end up loving what they do while many others fail to do so. And all these people, they don’t reach there by following their passion.

Following your passion is conventional wisdom that’s seriously flawed.

Most people live with a false belief that they have to find what they love. and the only way to do great work is to love what you do. They keep on looking and looking, changing jobs and jobs. They believe that they are only a few walks away from finding their dream job.

Everyone says the same thing: To be happy, follow your passion. But is it so?

Yes! having a passion for your work is vital, but it is a fool’s errand to try to figure out in advance what work will lead to this passion.

It happens only in movies where the lead character chase their dreams and it becomes a reality. In real life, things happen in stages. 

It’s hard to predict what you’ll eventually grow to love. If you look around the most successful people in the world, they sure do love what they do. But the life they are living often has complex origins and rejects the idea that you have to follow your passion.


----
**Type:** #permanentnote 
**Topics:** [[Finding your passion]]
**Reference:** [[So Good They Can't Ignore You]]

