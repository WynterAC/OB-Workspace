Being a critic is easy. It's easy to criticize someone from the comfort of your couch eating doritos. 

But creating something, and shipping it to the world requires a lot of effort. 

As a builder, your job is to create a vision. There will always be critics who will be ready to tear it down. 

It's easy to just consume and yell at others but creating something is difficult. 


----
**Type:** #permanentnote 
**Reference:** [[The Top Seven Painful Excuses We Use for Not Starting a Side Hustle]]

