When you stimulate your brain with addictions, it responds by demanding more stimulation. If you are addicted to social media, it will demand more of it. If you are addicted to drugs, it will demand more of it. 

No matter the addiction, its always the same. And often addictions are hard to reset.

The dopamine circuits motivate the addicts to use and threatens them to shut down completely if it doesn't get what it wants. 



----
**Type:** #permanentnote 
**Topics:** [[Dopamine]]
**Reference:** [[The Molecule of More]]

