---
alias: How to be valued for what you know
---
There are a lot of people who are not valued for what they're worth. Simply because they haven't shared their work publicly. 

People value credibility. And your credibility increases with your expertise. And to increase your credibility, you have to show people that you are an expert in what you do.

So, how do you do that? By sharing your work online.

We're living in a global economy. Internet is making the world smaller. If you want to be valued for what you are or more than what you are, you have to show the world. You have to publish your work online as a proof that you are the master at what you do.

----
**Type:** #permanentnote 
**Topics:** [[Show Your Work]]
**Reference:** [[The tragedy that most learners quietly suffer]] 

