
**Reference:** [[Three Lines Forecasting Forex Price Action]]
**Type:** #permanentnote 
**Topics:** [[💹Stock Market]] [[Trading]] [[Types of Trading]]
**Related:**

----
Traders who day trade enter and exit the trade within a day. They don't hold their positions overnight. They wait for good opportunities and enter  the trade.

They hold their positions longer than scalpers. 

It demands a lot of time and is good for people who have time to analyze, execute, and monitor trades.

