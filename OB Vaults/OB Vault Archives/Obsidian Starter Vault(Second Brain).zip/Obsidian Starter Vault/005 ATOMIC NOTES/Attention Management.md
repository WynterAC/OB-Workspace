You only have 24 hours in a day. Scheduling everything in that time won't help you achieve more rather the opposite. 

Time management is not the solution, attention management.

Priortize people, projects and tasks that matter. Focus on getting the right things done. 

Being productive is not about analyzing how you spend time. It's about working on what consumes your attention and working on it. 

----
**Type:** #permanentnote 
**Topics:** [[Time and Energy]] [[Priortize & Focus]]
**Reference:** [[Productivity Isn’t About Time Management. It’s About Attention Management]]

