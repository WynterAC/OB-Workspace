
**Reference:** [[Deep Breathing is the secret to your unkown power.]]
**Type:** #permanentnote 
**Topics:** [[Meditation]] [[Pranayama]] 
**Related:**

----

If you are stressed, unhappy or really uninspired, there's one secret to overcome this situation.

Do deep breathing. Breathe as fast as you can. Go to the extreme. This will force you to come out of pain or dilemma and give you a new feeling.

This will  completely reset and refresh your brain.

