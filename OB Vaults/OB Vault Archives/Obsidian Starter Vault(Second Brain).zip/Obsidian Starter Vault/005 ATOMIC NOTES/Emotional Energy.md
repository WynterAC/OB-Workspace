
**Reference:** [[Why managing energy not time is the key to producitivity]]
**Type:** #permanentnote 
**Topics:**[[Time vs energy]]

----
Stress and regrets deprive ourselves of the joy of being in the moment. 

We as humans are not psychologically capable of sustaining highly positive emotions for a long period. Thats one of the reason why negativity creeps in so easily in our life.


## How to recharge your emotional energy
Create rituals that fuel positive emotions such as expression appreciation of others, call them, e-mail or conversations with the loved ones. 

- Make it a priority to recognize the accomplishments and talk about the life of others


----

