
**Reference:** [[Manage energy not your time]]
**Type:** #permanentnote 
**Topics:** [[Time vs energy]]

----
Yeah, Its hard to build habits. But habits help you to make things almost effortless. You don't need to actively think and focus on the task. 

Managing your energy also means developing habits around your most important values. 

Habits turn complex tasks into simple ones.



