We are selfish by nature. The harsh truth about life is no one cares about you. Everyone is concerned about themselves. 

These are the rarest of rare people who care about others. 

If you are helping others, you are not being nice to them. You are just expressing your nature. 

No one helps anyone. Everybody do what is in their nature to do. 


----
**Type:** #permanentnote 
**Topics:** [[Human nature]]
**Reference:** [[A Master's Secret Whispers]]

