Craftsman mindset focuses on what you can offere the world instead of the contrary. Regardless of what you do, you should have a craftsman mindset. You should put your head down and work on getting good. 

You have to practice through discomfort until it becomes confortable. The reason why most people are so good at what they do is not because of their innate abiliites but because of the craftsman mindset, the lifetime accumulation of deliberate practice. 

----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[So Good They Can't Ignore You]]

