Imposter syndrome is doubting your own skills and abilities. You feel like a fraud and a phony. You ask yourself if you even deserve all the accolades that you receive.

Imposter syndrome comes out of trying to compare yourself to the experts or who are already at the top in your field. 

You think you are nobody infront of them and you don't deserve to be sitting next to them. 

Imposter syndrome is severe for creatives because they don't have anything to show for what they are. They don't have degrees. They don't have any certifications. This makes it even more severe problem. 

One way to overcome imposter syndrome is to compare yourself to the old version of yourself instead of comparing yourself to the experts.

Another way to fight imposter syndrome is to fight if by faking it. Everyone suffers from imposter syndrome. You beat if by being better every day.

> Remember: You having imposter syndrome doesn't serve the world. You are a mental millionaire. You know more that 99% of people. Be a good teacher. Be the link in the chain to pass wisdom from one generation to the another. 

Nobody is thinking you are an imposter, Everyone is thinking about themselves.

----
**Type:** #permanentnote 
**Topics:** [[Creative Struggles]]
**Reference:** [[The Brutal Truth About Reading If You Don’t Take Notes Right, You’ll Forget Nearly Everything]]

