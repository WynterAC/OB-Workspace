 When you are living in an environment, you don't have a free will. But when you are designing it, you have free will. 

 Instead of motivating yourself 24/7 to push through design an environment where it is easy. 

 Just like a glass of cold water will adjust itself to the room temperature, you will go in sync with your environment. 

 You will eventually do what the people in your surrounding do, what they talk and what they think. 

 Use your free will to design an environment where you can be in sync with the surrounding to achieve your goals.


----
**Type:** #permanentnote 
**Topics:**
**Reference:** David perell Thoughts on free will email  

