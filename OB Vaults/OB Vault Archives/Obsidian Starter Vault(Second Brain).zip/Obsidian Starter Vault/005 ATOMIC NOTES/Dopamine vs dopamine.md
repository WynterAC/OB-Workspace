Imagine a car with only accelerator. Would you ride it? It's dangerous. Just like a car needs brakes, our brains also need something similar that can control us. They are called the dopamine control circuits.

Dopamine control circuits involve the frontal lobe that has evolved recently. It uses willpower, planning, strategies and abstractions to imagine the long-term consequences of alternate choices. 

In the modern world which drives desire dopamine circuits, it is more important than ever to make a balance. 

Too much dopamine will only keep us on pursuing more and more. To keep on chasing one thing after another. It will often lead to productive misery. Therefore, it is important take a step back, be present, activate the H&N system and enjoy.


----
**Type:** #permanentnote 
**Topics:** [[Dopamine]]
**Reference:** [[The Molecule of More]]

