**Reference:** [[202107251620-  Discipline Equals Freedom]]
**Type:** #permanentnote 
**Topics:** [[Discipline]] [[Why You Need to Be Disciplined]] [[How to Be Disciplined]] 
**Related:**
___

Self-discipline doesn't restrict your life. Rather, it gives you freedom. People who are not disciplined are slaves. They are slaves to their feelings. They are slaves to their moods. Only once you are disciplined, you are free in your life.

Being disciplined about something will not just make you stronger, smarter, better and faster but also more healthier and happier than anything else.Be disciplined and embrace its relentless power.



