Knowledge is the new money. It is the medium of exchange and store of value. Those who don't have it are at risk. 

With the fast paced development of new technologies, there's a potential for people with skills and knowledge.

If you can learn and master new knowledge faster than anyone else, there's plenty of opportunities availabel for you out there. 

Knowledge is no longer a luxury. It's a necessity. 

Even if you are extremely busy, schedule at least a hour of your time to learning, reading and gaining new knowledge. This will make you invaluable as a person and open opportunities that you may never have thought of. 


----
**Type:** #permanentnote 
**Topics:** [[Learning]] [[Books]]
**Reference:** [[If you are not spending 5 hours per week learning, you're being irresponsible]]

