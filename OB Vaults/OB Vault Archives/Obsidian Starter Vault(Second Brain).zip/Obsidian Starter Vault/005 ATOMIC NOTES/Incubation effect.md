Incubation effect is when you have that 'aha' moment. You crack the solution to the problem that you've been trying to solve after a break. 

The unconsiouc processing in your brain leads to many undiscovered insights.