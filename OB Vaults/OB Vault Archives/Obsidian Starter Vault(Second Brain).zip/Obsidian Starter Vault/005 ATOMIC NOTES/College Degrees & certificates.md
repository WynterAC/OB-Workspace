It's a shame that we put too much emphasis on degrees & ceritificates even today. 
They are an awful way to learn anything valuable.

Because they don't teach you anything. They don't differentiate you. 
What they really do is transfer passive information from one person to another.

----
**Reference: ** Esat Artug Linkedin 
**Type:** #permanentnote 
**Topics:** [[Degrees are Useless]]



