When dog barks after you in the street, don't hit him with stones. Instead always carry a biscuit with him and give him biscuit. 

Do the same in your life. If you have haters in your life, Make them you fan. Teach them, help them be better, live better.

----

**Reference: **
**Type:** #permanentnote 
**Topics:** [[Haters]] [[Criticism]]
