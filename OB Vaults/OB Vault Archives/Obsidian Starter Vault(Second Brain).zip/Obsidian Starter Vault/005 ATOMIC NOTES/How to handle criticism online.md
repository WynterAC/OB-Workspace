When you write online, and produce content something online, you expose yourself to many people and you will be criticized often.
Many People will get offended but one way to handle this is to be aware of this fact:
They aren't talking about you. They are talking about the online you. They are criticizing the online avatar that has the same name as you.
Public comments are something that you get on something you made. Take it as a feedback to improve yourself.


----
**Type:** #permanentnote 
**Topics:** 
**Reference:** [[Hell Yeah Or No]]

