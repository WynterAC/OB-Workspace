
**Reference:**[[The Almanack of Naval Ravikant]]
**Type:** #permanentnote 
**Topics:** [[Success]]
**Related:**

---

One of the most common bad advice that's out there in the world is: "you are too young." But if you see back, most of the history was built by young people. They just got credit when they got older.

When you are young, that's exactly when you should do things. Things you love doing, Things that are really hard to do but very rewarding. Because once you age, you won't have the same energy and the enthusiasm as you have in your young age. So, take advantage of it.

Also remember that when you are doing great things, great outcomes will come. You surely need to have patience but you have to keep doing the great things. The outcomes will come. 