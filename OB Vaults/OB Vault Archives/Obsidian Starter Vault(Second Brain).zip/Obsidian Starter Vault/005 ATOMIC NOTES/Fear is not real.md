Fear is a fake emotion. There is nothing to be actually fearful about.

Fear is a reaction. A reaction that arouse during the time time when there was a chance that you would be eaten by a tiger when you were sleeping


----
**Type:** #permanentnote 
**Topics:**
**Reference:** 

