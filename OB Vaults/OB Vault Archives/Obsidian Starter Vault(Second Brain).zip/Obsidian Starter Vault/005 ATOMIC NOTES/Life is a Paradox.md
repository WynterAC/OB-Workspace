People run from rain but sit in bathtubs full of water. Life is full of paradox. 


If you don't understand this, you will expect the world to be logical. You will live your life in complete illusion. 

The world is not logical. Its random. There are paradoxes to everything. 

----
**Type:** #permanentnote 
**Topics:**
**Reference:** 
