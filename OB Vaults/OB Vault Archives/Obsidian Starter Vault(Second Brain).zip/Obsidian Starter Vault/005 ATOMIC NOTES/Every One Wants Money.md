Everyone desires riches. It has been proven throughout the history that: No matter how much money is demonized in public discourse, secretly, everyone wants money.
The government wants money. The temple, church and the mosques wants money. The prime minister wants money. You, I and everyone else wants money.

Most people who say they don’t care about money are slaves to it. They spend their life working for money and being in debt.
_____________________________________________

Type: #permanentnote 
Topic: [[Money]] [[Lust for money is bad]]