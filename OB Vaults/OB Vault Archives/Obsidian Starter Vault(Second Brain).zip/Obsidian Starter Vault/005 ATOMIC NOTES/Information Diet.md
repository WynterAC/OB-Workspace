There are two types of readers: One who reads everything that comes his way. He have no filter for information. He read whatever the others want to read. The other is someone who reads because he is curious. He reads to learn more and explore more.


In the age of information overload and the internet chaos, it becomes extremely important to know what not to read. 

Be intentional about what you read. Don't must read whatever pops up. Think and act like a curator. Read only quality information and ideas. 

Choose only the best sources to study from and store only the best ideas. 

Treat information as the food you eat. More food doesn't mean better. Junk doesn't make you better. 

Have a system that allows you to read, store, and retrieve the quality information that you read. 


----
**Type:** #permanentnote 
**Topics:** [[Note-taking]] [[Building a Second Brain]]
**Reference:** [[David perell smart sync workshop with tiago forte]]

