Writing and editing uses two different parts of your brain. The right side of the brain is responsible for the createive and intuitive function while the left side is responsible for cognitive and analytical functions. 

The right side is activated when you do creative writing while the left is activated when you edit.

Trying to do both at the same time is like stepping on the gas and the peddle at the same time. 

If you want to speed up your writing seperate the writing and editing tasks and batch writing sessions for different articles.

As someone said, "Write without fear, edit without mercy."


----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[A Highly Effective Method for Publishing 1–3 Articles A day]]

