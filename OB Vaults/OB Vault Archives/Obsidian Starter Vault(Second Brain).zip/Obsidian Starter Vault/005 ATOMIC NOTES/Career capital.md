Career capital are the rare and valuable skills and resources that increases the impact of your future career. Having career capital gives you leverage. With enough career capital you can easily transition into a new carreer. But if you change your careers without enough capital, you are doomed to fail. 


----
**Type:** #permanentnote 
**Topics:** [[Finding your passion]]
**Reference:** [[[So Good They Can't Ignore You]]]

