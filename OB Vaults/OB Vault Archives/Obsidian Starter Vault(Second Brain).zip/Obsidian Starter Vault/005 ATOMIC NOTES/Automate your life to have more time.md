
**Reference:** [[Save time by automating your life]]
**Type:** #permanentnote 
**Topics:** [[Productivity]] [[how to have more time]] [[Time Management]]

----
We all have the same 24 hours. But some people are able to do way much than you could ever. Why is that? 
It's because they are able to automate their life. 

They don't do everything. They only do things that are valuable and that makes a difference in their life. They don't try to do something, just because they can. They live an automated life. They avoid things that don't leverage their effort or create any opportunity in the future.

Automation may cost you money at first but the dividend it pays in the long term is unmatchable. It has a snowball effect.

You sholdn't be procrastinating on automating your life. It's the best investment you can do in yourself. Automate the easy and mundane tasks so that you can focus on the biggger opporutunities.

**Be smart about your time**


----

