
**Reference:**
**Type:** #permanentnote 
**Topics:** [[Goal setting]] 

----
Set goals. Not to change your future. But to change your present actions. Good goals allow you to take action now. 

A goal shows what's right and wrong. What you should do and what you shouldn't do.

Whatever moves you closer to your goal is the right thing to do and whatever doesn't move you closer to your goal is not the right thing.



