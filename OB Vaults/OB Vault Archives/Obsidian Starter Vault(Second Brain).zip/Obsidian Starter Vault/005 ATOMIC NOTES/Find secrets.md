The world is full of secrets. And the one who disovers the secret reaps the rewards. If you want to take a leap in life, you have to be obsessed with the secrets. 

Nokia failed as a company when they didn't recognize the secret of touch phones.

**A secret is an important truth or a fact that ver few people agree with.**
You can't discover the secrets all alone. You have to surround yourself with the independent thinkers.


----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[Why Peter Thiel Searches for Reality-Bending ‘Secrets’]]

