

**Reference: **
**Type:** #permanentnote 
**Topics:** [[Luck]]

----
I had the privilige of being born in a middle-class family. I was lucky to grow in a peaceful period of time. I was lucky to be born in the era of technology. And most of all, I was lucky to be stumbling upon some self-help and business books that have guided and taught me a lot.