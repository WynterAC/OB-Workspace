
If you spend a lot of time consuming content, you should consider creating a curated newsletter. People want to read the latest, top and interesting things. 

If you are already doing this, You can make it easy for them by curating through a lot of good sources. 

Creating a curated newsletter comes down to simple things:
- Don't try to sell
- Keep it simple and short
- Don't try to go wide before you have gone enough deep
- Make it compelling to encourage CTR
- Share interesting resourcess and ideas

----
**Type:** #permanentnote 
**Reference:** [[Stand Out from The Crowd with a Curated Newsletter]]

