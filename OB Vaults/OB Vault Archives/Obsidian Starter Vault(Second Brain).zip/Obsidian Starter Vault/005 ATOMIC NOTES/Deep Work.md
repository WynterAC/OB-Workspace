
**Reference:** [[Why you should manage your energy and not your time]]
**Type:** #permanentnote 
**Topics:** [[Time vs energy]]

----
Deep work is the uninterrupted time that you assign to a  task. During that time, you only have one focus. Completing the task at your hand.

You can't be distracted. You can't multi-task. 

And then you will be able to tap into your inner power of deep and focused work.

3-4 hours of deep work can beat people who do unfocused work for a week.

----

