When you are surrounded by something, it is impossible to see it. That's exactly true about different culture across the world. Just because something is not in the culture doesn't mean it is not true.

Most people live in this illusion. 

Most people are just a fish who don't know they are in the water. And, in some aspects of your life, you are too.




----
**Type:** #permanentnote 
**Topics:**  
**Reference:** [[Hell Yeah Or No]]

