You will get the greatest returns on your ideas when you share them with the world. 

When you are excited with a new idea, share it. If you don't you will slowly start to lose enthusiasm. 

The idea becomes more and more obvious and you start to lose your empathy for what its like to be a beginner.

Share your ideas when they are new to you becaue sharing help you remmber and there are other people you can help with your ideas. 

Sharing as you learn also helps to cure [[Imposter Syndrome]].


----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[The Brutal Truth About Reading If You Don’t Take Notes Right, You’ll Forget Nearly Everything]]

