Creator: Grow More
Source: https://www.youtube.com/watch?v=SbWJkxC20zs
Type: #litnote 
Topics: [[💹Stock Market]] [[Trading]]

---------------------------------
# Fibonacci Series
Fibonacci series is the series of sum of preceeding two numbers. For example: 0,1,2,3,5,8,13,....
# Golden Ratio
Golden ratio is the ratio obtained by dividing a number by its precedding number. It's value is 1.618 at in mathematics and the its different values are used in stock market such as 1,0.618,0.382,0.236, etc.
# Fibonacci in Nature 

# Fibonacci Misconception
- Prediction of the rise or fall of market 
- It only tells you about the retracement of market from certain points
# Precautions
- Never rely on it alone: USE MA, consider trading volume as well and use your personal favorite tools
- The larger the timeframe, the better results (use daily or weekly)
- Follow the long term trend( Trend is your frend until it bends)