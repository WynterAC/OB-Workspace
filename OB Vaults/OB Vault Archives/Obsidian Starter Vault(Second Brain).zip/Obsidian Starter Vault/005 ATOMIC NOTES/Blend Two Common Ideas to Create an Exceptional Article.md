
**Reference:** [[How to write an exceptional article for better humans]]
**Type:** #permanentnote 
**Topics:** [[Writing]][[Writing Tips]] [[Tips to Write an Exceptional Article]]
**Related:**

----


Creativity is all about mixing things up and presenting them in a new way. One way to create an exceptional article is to mix two topics.

List out the topics that you are interested or curios about and mix up any two of them. Find an intersection point between those two topics and share it with the wold.

For example if you are an expert in judo, you can mix it with how it helped you with your office work. How it helps in builiding confidence, etc. These are just ideas