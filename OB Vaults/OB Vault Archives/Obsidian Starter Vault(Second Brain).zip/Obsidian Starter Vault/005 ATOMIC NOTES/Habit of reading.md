
Whatever you want to learn, its written somewhere in the book. You can gain the wisdom of lifetime at the cost of lunch. Isn't that amazing. 


It is one of the highest leverage activity. Unlike other activities, reading doesn't provide linear returns. Its returns are exponential. You will seperate yourself from the crowd when you [[Be a Perpetual learner]]. It will not only help you to learn more but also broaden your horizon

As the saying goes: the more you learn, the more you earn. 

----
**Type:** #permanentnote 
**Topics:** [[Habits]]
**Reference:** [[The 5 Non- Negotiable Daily Habits I used to Radically Improve My Life]]

