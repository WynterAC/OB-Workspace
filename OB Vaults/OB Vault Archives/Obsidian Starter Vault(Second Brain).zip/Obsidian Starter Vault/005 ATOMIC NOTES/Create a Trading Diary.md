
**Reference:** [[& The disciplined trader]]
**Type:** #permanentnote 
**Topics:** [[Trading]] [[Mastering trading psychology]] 

----
If you want to consistently make money in trading, you have to keep a trading diary. If you don't have start today. 

Assess your trades. Question every trade. What motivated you? How was the trade managed? Was it successful? Why? Did you lose? Why?

You have define your behaviors and actions and record them. Because if you don't, you can't repeat your wins and prevent your losses. 

You can't know what you have to do to win the trade, if you don't know waht you did to win last time. 

----

