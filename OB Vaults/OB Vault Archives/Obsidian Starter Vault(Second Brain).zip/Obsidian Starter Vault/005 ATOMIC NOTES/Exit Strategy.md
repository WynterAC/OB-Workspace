People take entry, set stop loss and forget about taking profits. If you don't know when to take profits, your profits might all be wiped out in a minute. 


----
**Type:** #permanentnote 
**Topics:** [[Trading]]
**Reference:** [[Taking Profits on Trading]]

