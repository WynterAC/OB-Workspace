
**Reference:** [[Focus one Thing at a Time]]
**Type:** #permanentnote 
**Topics:** [[Productivity]] [[Focus]] [[Personal Development]]
**Related:**

----

We have multiple things we want to do. But if you run behind everything you want to do, you will achieve none. So, a better strategy is to at least focus only one thing from one category at a time.


If you stop tieing yourself to everything, you will be more happy. Focus on single task with extreme focus.

stop overwhelming yourself with a big list of tasks that you have to do. Don't focus on multiple things in the same category at a time.

