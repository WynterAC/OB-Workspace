Fleeting notes are the reminders of what you have on your head. They are your everyday thoughts that you might think to be important. You don't have to worry about where or how you can write them. You can have a simple notebook or an inbox system. But if your thoughts are already sorted and you have time, you can skip this step and write down the ideas directly as permanent note for your slip-box.  They are only the reminders and can be written in any kind of way and will end up in trash within a day or two.




----
**Type:** #permanentnote 
**Topics:** [[Zettelkasten System]] [[Permanent Notes]] [[Literature Notes]]
**Reference:** [[How to Take Smart Notes]]

