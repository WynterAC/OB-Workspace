
**Reference:** [[Why 80,000 Followers On Medium Means Nothing]]
**Type:** #permanentnote 
**Topics:** [[Social Media]] [[Content Creation]] [[Make Money Online]]

----
People are obsesseed with followers and views. In reality, they don't mean shit. The performance of any one piece of content doesn't matter any more.

What matters is to produce quality content with volume. Nobody knows you even exist until you hit that publish button. 

Algorithms on different social media and all other platforms are changing. They have all shifted from followers based to algorithm and engagement based.

Stop chasing followers and start builiding a big library of content that's of quality and valuable to your content. 



----

