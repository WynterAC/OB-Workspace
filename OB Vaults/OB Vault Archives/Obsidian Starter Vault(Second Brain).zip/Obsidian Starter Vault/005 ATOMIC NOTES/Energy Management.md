We have finite time but not energy. Energy fluctuates. There are times when we feel like we can move the mountains and there are times when it feel likes we can't even get off the couch. You can have all the time in the world but if you have no energy, nothing gets accomplished.

Better than time manangement is the energy management. Energy management is managing your life around your energy levels. 

Energy levels fluctuate throughout the day. If you begin a task without taking energy in consideration, you migh stretch a task that takes 10 minutes to 1 hour. 

Therefore, it is important to analyze your natural rythms and patterns. Here's how:

Create an energy audit. Find out what drains your energy and what gives you energy. Find out the times when you are at your peak and when you are at your low. 

Now schedule everything around that time. Do things that are important and that requires more energy at your peak times and schedule the mundane tasks when you are at your low. 

Learning to manage your energy will bring singnificant changes in your life

----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[Time vs energy management]]

