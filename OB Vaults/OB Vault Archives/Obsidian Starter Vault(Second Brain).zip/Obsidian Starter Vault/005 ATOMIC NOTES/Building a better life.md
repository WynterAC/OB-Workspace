In earthquake prone areas, millions and millions are invested for making anti-sesmic buildings. Although, it is possible to build normal buildings, its not viable for the long-term. Imagine you built a building and it collapses after a small shock of earthquake.

Our life is quite similar. There are adversities in our life just like earthquakes. 

Today you can do whatever you want. You can eat whatever you want. You can watch whatever you want. You can spend your money however you want. But tomorrow will not be the same. 

If your build a normal life, If you spend your present seeking pleasure, you will be shattered by even the smallest of adversities that come into your life. You will be sick. You will be depressed. You will fall apart. 

Don't lose the sight of the future. Invest in your present to create a future that you want to live for. Don't seek pleasure, seek satisfaction.




----
**Type:** #permanentnote 
**Topics:** 
**Reference:** [[Deficiency of this Mineral may Destroy your Mental and Physical Health]]


