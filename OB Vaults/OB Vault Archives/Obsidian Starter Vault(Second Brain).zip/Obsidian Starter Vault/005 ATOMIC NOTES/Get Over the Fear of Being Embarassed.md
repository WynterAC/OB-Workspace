You’ll never regret trying and failing, but you’ll always regret inaction. Rejection, embarrassment, and ego-bruises fade. The thought of ‘_what could’ve been_’ sticks with you until you die.
 No one likes to be embarassed or fail. Once you get over the fear of being embarassed or failing, it allows you to go into the lanes that you wouldn't otherwise go into. It's hard to rewire someone.
 
 One way to change the philosophy of your life is by changing your thinking of failure as learning

---
Reference: 
Type: #permanentnote 
Topics: [[Failure]] [[Take Action]]
