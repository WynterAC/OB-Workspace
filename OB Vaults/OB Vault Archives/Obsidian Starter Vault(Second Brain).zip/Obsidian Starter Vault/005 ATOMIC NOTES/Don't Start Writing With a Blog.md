
**Reference:** [[@ Why You Shouldn’t Start A Blog]]
**Type:** #permanentnote 
**Topics:** [[Writing]] [[Tips for Beginner Writers who want to make money online]]
**Related:**

----
Many people start writing with a blog and quit eventually. It's frustrating to see yourself putting so much effort in your writing and seeing no results.

Therefore, if your aim is to build something online, you should never start with your own personal blog.

When you start a blog, nobody knows it exist. People will never notice what you publish no matter how good you write. 

Therefore, you should start writing on platforms that already have audience. These type of platforms help you to get more visibility. You can get access to the hundreds and thousands of eyeballs through these platforms


