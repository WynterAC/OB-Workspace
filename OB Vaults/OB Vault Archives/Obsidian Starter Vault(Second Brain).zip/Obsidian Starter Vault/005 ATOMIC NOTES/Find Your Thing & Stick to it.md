
**Reference:** [[The Almanack of Naval Ravikant]]
**Type:** #permanentnote 
**Topics:** [[Personal Development]]
**Related:** 

----
The odds of you being the riches man in the world or even in your country are very low. But you can be the best version of yourself. 

Everyone is motivated at doing different things. If you want to be the best version of yourself, you have to find your thing and stick to it. 