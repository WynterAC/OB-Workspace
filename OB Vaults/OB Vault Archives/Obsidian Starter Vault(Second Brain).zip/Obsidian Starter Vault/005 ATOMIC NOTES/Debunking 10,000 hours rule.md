The 10,000 hour rule popularized by Malcolm Gadwell through his book outliers is misunderstood by a lot of people. 

According to the book, if you want to be world-class at a particular thing, you need to spend 10,000 hours doing the same thing. 

While that may be true, many people misunderstood this rules that people need 10,000 hours to learn something. That's far from the truth.

Learning something, being good at it and being the absolute best are three different things.

----
**Type:** #permanentnote 
**Topics:** [[How to learn anything fast ]]
**Reference:** [[The 100-Hour Rule Forgotten Study Shows How You Can Become World Class In 100 Hours]]
[[The 100 hour rule]]
