People only understand from their perspective. So, don't argue with people. You can't change their mind. Even if you change, you'll end up hurting their feelings which in either way is not good for you. 99% of the times, avoid arguing with people.

---
Reference: 
Type: #permanentnote 
Topics: [[Stop Arguing]]