Thinking is often a waste of time. If you are trying to do something new, something scary, you have to build a momentum and start acting. 

If you allow yourself to think, you will stay where you are. Our brains are stupid and hearts, tiny. They doubt, overthink and hesitate. 

Once you commit to something, don't think. Stay stubborn until you finish it. The worst thing to do is to stop and think.

If you start thinking rationally, you will never act big. You should act from your intuition and instinct.


----
**Type:** #permanentnote 
**Topics:**
**Reference:** [[& Do the Work]]

