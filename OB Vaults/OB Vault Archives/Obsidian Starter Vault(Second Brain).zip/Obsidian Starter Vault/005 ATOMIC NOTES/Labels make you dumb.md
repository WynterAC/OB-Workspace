When you put a label to yourself, you can't think clearly. When something becomes your identity, you can't think out of it.

Religion and politics is an example of how putting lables makes us dumb. How everyone acts up as an expert yet they contradict each other. 

They can't engage in fruitful discussions till they engage their identity in it. 

To have better arguments, and to think better, you need to to have as few identities as possible. 


----
**Type:** #permanentnote 
**Reference:** [[004 ARCHIVE/Keep Your Identity Small]]

