
**Reference:** [[Who Moved My Cheese]]
**Type:** #permanentnote 
**Topics:** [[Change]] [[Fundamental Truths of Life]]

----
The world is constantly changing and with the improvement in technology it's even faster. Most people are afraid to change. People often ask,"Why should I change?" They have the feeling of superiority. They often resist change because they are afraid to change. They are comfortable where they are and they don't want to leave that place.

Human belief systems hold them from doing what they should be doing. They are fearful. They are afraid of the unknown. Fear is good sometimes. But if you are so afraid that it keeps you from doing anything, it's not good. Most of the human fears are irrational and keep you from changing when you need to. You have to take action. You have to ask yourself the question, "What would you do if you weren't afraid?"

