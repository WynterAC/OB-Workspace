Digital readers lack attention. They have so many choices to make. They won't spend 5 minutes on your article without knowing there's something for them.

Before they start reading your article, they will make a quick skim to make a snap judgement whether the read is worth their time or not. 

Therefore, as a 


----
**Type:** #permanentnote 
**Topics:**
**Reference:** 

