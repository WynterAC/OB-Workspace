

**Reference: ** [[Why We Sleep]]
**Type:** #permanentnote 
**Topics:** [[Humans are emotional beings]] [[habit Builiding]]

----
We, human beings are emotional beings. Every action we took is  governed by two simple rules: Staying away from something that feels bad and doing something that feels good.

Emotion makes us do things. Positive emotions makes us do things and negative emotions try to avoid doing things.