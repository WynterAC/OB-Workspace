
**Reference:** [[Money cheat codes I stole from people smarter than me]]
**Type:** #permanentnote 
**Topics:** [[Money]] [[Habits that will make you poor forever]]

----
You have to invest on assets. 

Naval said, 'If your income is coming from labor rather than assets, you're being decimated by hidden inflation.

Money is created out of thin air. Governments print money and that money goes directly to bank which they lend to others. 

Why do you think even after so much crisis in the world, stock market is skyrocketing. Because all of the money that is printed goes inthe hands of rich fellas.

The money you have saved somewhere in the bank or you locker loses its value every day. You have to buy assets to save yourself from this financial disaster called hidden inflation.

----

