
I'm not generalizing here but the vast majority of our parents, moms and dadsdon't want to accept the new things and view point of the world.

Generally they say they are older than us which gives them more insights and wisdom which is mostly false. Most parents are stuck on their ego centric view of the world and they want to control their children and how they see the world and how it must be done. I'm not trying to insult the moms and dads out ther who put a lot of work but from an outsider perspective, it seems really ignorant and selfish. 

A lot of parent would rather have their child get paid very little money being someone they think is an honorable job maybe in the medical industry or government job than a multi-millionaire video game player or an athlete. 

As time goes on, our children will be smarter than us, in the same sense how we are smarter than our parents.  Because knowledge and understanding of the world deepens as our society ages and discover new things.

People don't want to let go off their ego. It takes letting go of their ego and stubborness as well as a little bit of intellect to understand that we are not living in their time and we have to adapt to our time.

---
Reference: 
Type: #permanentnote 
Topics: [[Ego]] [[Mindset Shift]]