

**Reference: ** [[202107251620-  Discipline Equals Freedom]]
**Type:** #permanentnote  
**Topics:** [[failure]] [[Success]] 

----
What do you think about failure. 
People mostly think failure is bad. It keeps you away from taking the risk. It can leave you sitting at the same place of your comfort zone and paralyze you into not taking action. Which obviously is bad.
But that's not always the case, failure is good too.

Fear of failure keeps you awake at night. It keeps you training hard. It keeps your thinking and relentlessly prepared for the battle. 

Therefore, it is important to be afraid of failure. You should be horrified and even more terrified of sitting on the sidelines and doing nothing, achieving mothing.

