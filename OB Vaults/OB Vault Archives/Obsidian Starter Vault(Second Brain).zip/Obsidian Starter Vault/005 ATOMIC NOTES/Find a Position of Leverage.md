
**Reference:** [[The Almanack of Naval Ravikant]]
**Type:** #permanentnote 
**Topics:** [[Productivity]] [[Wealth]]
**Related:**

----


"Give me a lever long enough and I will move the earth". Someone said this 1000s of years ago and hold true till date. If you want to do something great in life, you can't do it all alone by yourself. You have to find leverage. You have to let leverage do the work. 

There are 3 types of leverge: labour, capital and technology. And among these all technology is the most useful form of levearge. It can help you multiply your efforts without involving labour. All you need is a mobile phone or a computer.

There are two forms of leveraging technology: Content, code.

These two are the most powerful weapons of the present age to do whatever you want. These will help you get what you want: money, fame, power and what not.