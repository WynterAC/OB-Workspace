As human beings, we need to connections to survive. Connecting with other fellow monkeys is only one type of connection. You should be connected to your purpose, passion, people and nature. 

Imbalance in these connections will bring stress and burnout. Connections make your life better. They help you stay sane no matter the extent of adversities. 




----
**Type:** #permanentnote 
**Topics:** [[Habits]]
**Reference:** [[The 5 Non- Negotiable Daily Habits I used to Radically Improve My Life]]

