---
---
**Source:** Tim denning newsletter
**Author:** Tim denning
**Type:** #litnote 
**Topics:**  [[Financial Freedom]] 

----
- Hard to outearn bad spending
	- Most of the poor people are the ones who actually make a lot of money. People who are earning a lot. 
	- Spend more than they earn. 
	- Their income is a slave to their debt.
	- People are addicted to spending
	- We talk about different addiction but never talk about spending addiction
	- James clear says fix overspending before it becomes a lifestyle.
	- If you earn more, don't spend more. Instead invest more in assets that bring more money
- [[You can't outearn a bad spending]]
- **Buy assets is a means of survival**
	- If your income is coming from labor rather than assets, you’re being decimated by hidden inflation — Naval
	- I don't love stocks neither do I talk about them to look cool. I just understand about the hidden inflation.
	- Money is created out of thin air.
	- since March of 2020 40% of all US dollars in history were created out of thin air. This is called money printing.
	- Ends up with the rich
	- The stock market is record high 
	- Money create out of thin air goes to banks and then they lend. 
- [[Buy assets as a means of survival]]
- The average investor has no access
	- crypto makes easy access 
	- You can buy and sell anything and anywhere instantly
	- 