---
---
**Source:** https://medium.com/swlh/welcome-to-the-note-taking-apocalypse-64a74481a5ab
**Author:** Tim King
**Type:** #litnote 
**Topics:** [[PKM]] [[Note Taking]]

----
- More choices makes it harder than having no choice at all
- Note- taking: Incredibly personal. What works for others might not work for you. 
- Note-taking should be as effortless as possible
- Frictionless
- Copy paste feature can save ton of rework
- Different platform integration to use it in a way users expects not lazy developer demand
- Customizability
- Wiki-like superpowers

No note taking software is perfect. but you can get close. You'll never find the 'perfect' state of note-taking. New methods and feature will turn yoru workflow on its head. 

Learn from others and don't try to remake everything that came before. Use it the way that benefits you the most.
