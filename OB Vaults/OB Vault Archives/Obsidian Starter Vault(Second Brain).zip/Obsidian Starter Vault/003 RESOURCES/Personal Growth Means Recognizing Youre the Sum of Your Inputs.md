---
---
**Source:** https://www.entrepreneur.com/article/390865
**Author:** Dyalan Ogline
**Type:** #litnote 
**Topics:** [[Content Creation]] [[Personal Development]]

----

- Finding the best ingredients
- Master the craft of identifying the best ingredients
- What kind of ingredients are you cooking with
- Bad ingredients= bad meal
- GUT LEVEL
	- fast food, alcohol? what results do you see? Lazy sluggish?
	- Clean meal, plant based? energetic
- Body
	- Productive machine or entire day in sofas? exercise walking and standing?
- Mind
	- Attention economy fights for you. 
	- Netflix, memes, facebook or book, lectures, courses and meditation?
	- Motivated or compulsive need for stimulation
- wORK
	- Filled Distractions, chats and urgent things or what?
	- Low-level tasks or deep work
	- Ruthlessly eliminate and delegate unimportant tasks
- Relationships
	- Who is in your crowd? People who settle for good enough or go-getters who encourage you to take risks and excel
	- Sage social circle stuck in neutral or risiing tide that lifts all the boats?
- Change your inputs if you want to change your output. If you want a different version of yourself
- Replace depleting ingredients with better ones.
- Don't pick fights, unfollow people. 
- Takes discipline to see results. 

**Different outcomes are created by different inputs. Change the way you do different things.**