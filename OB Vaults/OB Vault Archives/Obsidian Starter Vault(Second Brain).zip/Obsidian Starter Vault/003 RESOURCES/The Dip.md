---
title: The Dip
author: Seth Godin
category: Business & Economics
publisher: Penguin
publish_date: 2007
total_page: 96
cover_url: "https://books.google.com/books/content?id=95-xBXd4vn8C&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1591841666
isbn13: 9781591841661
---
**Title:** The Dip
**Author:** Seth Godin
**Type:** #litnote #todevelop #book 

---
You often hear people saying never quit. But, it is not what it is. Quitting can be an excellent idea, sometimes. A better advice can be “Never quit something with great long-term potential just because you can’t deal with the stress of the moment.”