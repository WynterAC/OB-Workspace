---
---
**Source:** (https://2madness.com/why-short-form-content-will-skyrocket-your-writing-6304a455d899)
**Type:** #litnote 


----
- The success of tiktok proves that people love to-the-point content. And it goes beyond videos: it applies to writing as well
- **Shortform is not lazy writing. You can bring enough value with just shortform writing**
- Write articles less than 500 words to diversify your content, increase your audience, and skyrocket your earnings.
1. **There's a new audience**
	1. Some people just prefer unique content. They don't want extensive analysis. They want quick thought provoking content.
2. **Increase the quantity**
	1. Writing is the game of numbers
	2. Writing 500 words is 10X faster than writing 2000 words
	3. It motivates  you to write 500 words unlike 2000 words article
3. **Shortform is challenging**
	1. You have to cut the fluff. find the core idea and present it to the audience.
	2. It will make you a better editor
4. **Helps with consistency**
	1. Take small step and write 500 words. You'll be more consistent. 
	2. It will skyrocket your writing and earnings as well. 

**Don't write shortform ony. Diversify the formats and find what works best for you.**