---
---
**Title:** 10 Productivity-Friendly Ways to Automate Your Life
**Source:** https://betterhumans.pub/10-productivity-friendly-ways-to-automate-your-life-2b06be4661e2
**Author:** Michelle Loucandoux
**Type:** #litnote 
**Topics:** [[Time Management]] [[Money]] [[Personal Development]] 

----
Time is valuable. You have to use it wisely.
- Automate smaller things
- Don't do things that don't add value 
- Automation cost, pays dividends in longterm
- Expensive but has snowball effect
- Try to avoid tasks with no leverage or opportunity in future.
- Don't procrastinate automation
- saves a lot of your time
- Be smart about your time
- 