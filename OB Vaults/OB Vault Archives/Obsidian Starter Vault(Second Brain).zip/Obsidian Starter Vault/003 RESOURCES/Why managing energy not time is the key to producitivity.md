---
---
**Source:** https://www.happify.com/hd/why-managing-energy-not-time-is-the-key-to-productivity/
**Author:**
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]] [[Energy Management not Time Management]]

----
- Our desire to live fully is often based on our ability to manage time. 
- We think of making efficient use of every moment. But its not how we are built to function as human beings.
- You should slow down and procrastinate in the between so that you can your body can recover physically, mentally and emotionally to be at the peak performance during the next period of productivity.
- Here are four sources of energy that build on each other
- **Physical energy:**
	- More regularly, exercise and take rest to 
	- High energy levels= 3X engagement in work
	- Don't sit for long time at your desks and TV. Move out take breaks, do physical activity
- Emotional activity
	- Stress and regrets darin our energy
	- Wandering mind helps being creative but not inf you want to be productive. Directing energy in here and there thoughts deprive ourselves of the joy of being in the moment.
- Mental energy
	- We can't focus deeply on one task at a time
	- Shut off all distractions and let  your mind focus on one task at a time
- Spritual energy
	- Tap into whatever feeds your soul
	- Pray, meditate, read a good book, play with someone
	- Be creative, Make art or 


Life is short. Don't rush to cross the items on your to-do list without engaging fully. Live in the present moment. 

You can truly maximize the value of your time when  you learn to manage your energy levels. 