---
---
**Title:**[The Formula for Creative Success When So Many Fail
**Source:** (https://medium.com/swlh/the-formula-for-creative-success-when-so-many-fail-7d92085df374) 
**Author:** Taylor Foreman
**Type:** #litnote 
**Topics:** [[Creativity]] [[Writing]]

----
- The secret backdoors to human psychology
- Risk Aversion:
	- We hate losing twice as much we love winnning
	- not win always but if we lose always, we will die. We 
	- Creature defined by death
- You are afraid to follow your dreams 
- You want to play it safe rather than lose

# Quantum Flow
Flow is our maximum potential. At our best, we are dancers, not planners.

# The talent paradox
Everyone talent. Dive into yourself. Stop jealousy, be you.