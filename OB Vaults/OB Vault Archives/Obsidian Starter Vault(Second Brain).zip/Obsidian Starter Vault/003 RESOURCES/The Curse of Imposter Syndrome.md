---
---
**Source:** https://medium.com/creators-hub/the-curse-of-imposter-syndrome-21ff9cc4efa8
**Type:** #litnote 

----
- You think other writers are real and you are not. You are only until you are found out.
- [[Imposter Syndrome]] is for people in creative field
- Everyone suffers. creative people do most
- More vulnerable. No benchmark
- You decided yourself. You believed in yourself
- Writing is an act of sheer confidence
- Assumes you have something to say and you are in a position to say it
- On good days we ignore. On bad days, "Who am I to declare I have something to say?"
- Destructive. Learn to fake it. 
- No amount of success can permanently erase the sense of being an imposter. 
- Defeat it by being better every single day.
- Everyone starts by faking it. 
- How well can you act as faking it

I’ve never met anyone who doesn’t have a stubborn streak of insecurity about doing this work