---
title: The Tipping Point
author: Malcolm Gladwell
category: 
publisher: Findaway World
publish_date: 2014
total_page: 288
cover_url: "https://books.google.com/books/content?id=C1jkoAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1408705575
isbn13: 9781408705575
---
**Title:** The Tipping Point
**Author:** Malcolm Gladwell
**Type:** #litnote #book #todevelop 

---