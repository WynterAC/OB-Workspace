---
---
Reference: 
Type: #permanentnote 
Topics: [[Money]]

----
Why do people expect rich people to solve the problem of the world. People expect them to give half of their wealth to the world.
Well, let me ask you something first, Do you give half of your monthly salary to others? If you don't, then why do you expect others to do so?

It's equally your responsibility to save the world as much as it is theirs.

Related: [[Every One Wants Money]]