---
---
**Source:**](http://www.aaronsw.com/weblog/hatethenews)
**Author:** Aaron Swartz
**Type:** #litnote 
**Topics:** [[Social Media]] [[Mindfulness]]

----
- News is waste of time. It doesn't make you good citizen either as most people seem to think
- None of the news makes any relevance to  your life
- People think news expose the wrong-doing of people and stop the wrong=doers but it is not so. It makes the wrong-doers do the crime more subtly.
- Don't need to watch news everyday if you want to vote, can just read the guide about the candidate and issues before election
- No need to suffer the back and forth allegation on the news. Your life won't change by reading or listening to the news
- Instead of watching news daily why not do it weekly or even annualy? 
- Its not just a waste of time but also unhealthy
- If your life doesn't improve with it, or can't be greatly enhanced by it, you can stop watching and reading the news