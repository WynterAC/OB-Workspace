---
---
**Source:**  https://medium.com/swlh/how-im-growing-my-newsletter-like-fire-6a0acd958772
**Author:** Niharikaa Kaur Sodhi
**Type:** #litnote
**Topics:** [[Newsletter]] [[Content Creation]] [[Make Money Online]]

----

- Be regular for them
	- Appear at same time and day everytime
- Give them insight into your life, what you ar upto
- Be vulnerable as hell
- [[Don't be a superhuman]]
	- Not a robot. Don't be perfect. share imperfections, failures. How you handle them. DOn't sound to be somebody you are not
- Be interesting. Experiment with your style
- Provoke a thought.
	- Leave a question or something for them to think about
