---
---
**Creator:** Lifehack
**Source:** (https://start.lifehack.org/hacking-procrastination-1?utm_campaign=hacking_procrastination_v1_2&utm_content=hacking_procrastination_v1_2&utm_id=hacking_procrastination_v1_2&utm_medium=newsletter&utm_source=email&utm_term=email_1&vgo_ee=Mf9Ttk5CmPLbNZ8DoE9oLKyPUFd7JHyq9acdSgULWaM%3D)
**Type:** #litnote 
**Topics:**

---

- Part-1: The #1 Goal Killer; Distractions [[Use distractions as a tool to strengthen your focus]]
	- Every 11 minutes, 25 minutes to get on optimum focus
	- Top performers are more focused 6/2 instead of 2/6
	- Distraction is not the enemy
	- You can't defeat distractions with sheer willpower
	- Change your mindset about distractions
	- More distractions means you have an advantage
	- 90% of the time, we choose to be distracted subconsciously
	- Power lies in you
	- Distractions are reflection of internal struggle
	- Distraction are as a result of an action your mind hasn't fully decided on 
	- Other things pour your attention
	- Commit yourself to something fully both physically and mentally
	- Each distractions help you to strengthen focus
- Part 2: Reel it in method [[Write down the distractions to improve focus]]
	- Create distraction follow up list
	- You don't ignore. You commit to it but not right now
	- You schedule it later to do it later
	- You now come back to your present task at hand
	- This helps to ease the distraction
	- 