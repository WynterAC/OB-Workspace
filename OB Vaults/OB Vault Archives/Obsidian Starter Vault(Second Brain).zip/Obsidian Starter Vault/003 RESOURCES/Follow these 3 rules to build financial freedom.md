---
---
**Source:** https://themakingofamillionaire.com/follow-these-3-rules-to-build-financial-freedom-9ca2583489b4
**Author:** Ayodeji Awosika
**Type:** #litnote 
**Topics:** [[Financial Freedom]] [[Wealth]][[Money]]

----
- No happiness but right amount of money + right way of earnig it can give next best hing to happiness.
- Money reacts to how you treat it. Treat scarce, and it will run. Treat abundance and it will com eot you
- Think evil and it will not come to you. Think useful and it will comeback to you.
- Financial freedom= not having to worry about money.


- Common argument I hear is teacher should be payed like athelets.
- Sounds valid from the intrinsic point of view but not from a economic. 
- The more you can impact the more money you can make. 
- Market values education over entertainment
- Barriet to entry is high for professional athelets.
- Low supply+high demand = increased value
- what you think doesn't matter. The market treats well to people with profitable skills.


- Lifestyle inflation
- Don't let it creep into your life
- More money equlas more spending
- Don't stop working just because you have made some money. Double down on it. Triple down on it and keep dong your work