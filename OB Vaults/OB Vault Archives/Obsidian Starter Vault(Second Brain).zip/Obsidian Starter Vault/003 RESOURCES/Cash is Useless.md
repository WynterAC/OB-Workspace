---
---

**Reference: ** [[The Simple Path to Wealth]]
**Type:** #permanentnote 
**Topics:** [[Wealth]] [[Money]] 

----
At the present scenario, cash is not of much use. It is only good to have around to cover routine expenses and to meet emergencies.

It's the best things to have during deflation becasue the more prices drop, the more your cash can buy. 
But when prices rise, the value of cash erodes.

- Therefore a better strategy is to keep as little cash as possible as per your needs