---
title: Ten Arguments for Deleting Your Social Media Accounts Right Now
author: Jaron Lanier
category: Computers
publisher: Picador
publish_date: 2019
total_page: 208
cover_url: "https://books.google.com/books/content?id=alyrvgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Completed
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1250239087
isbn13: 9781250239082
---
**Title:** Ten Arguments for Deleting Your Social Media Accounts Right Now
**Author:** Jaron Lanier
**Type:** #litnote #book #todevelop 

----

Dogs are loyal and dependable. They work for us love us. But still, cats are more popular in the internet. One reason why is because, they have done something seemingly impossible. They haven't given up being themselves. They are still in charge. 

No one has take control over the cat unlike dogs. 

Even though we like our dogs, nobody wants to be like dogs. But we are afraid that social meida is slowly turning us into dogs. 

This book teaches you how you can be a cat. To remain autonomous in a world where you are in constant surveillence and constantly prodded by algorithms manipulating our behaviour.

Here are the ten arguments presented by the author on why you should delete your social media accounts right now.

## You are  losing your free will
You're being tracked and measured constantly, and receiving engineered feedback all the time. You are being hyptonized little by little. You are slowly turning yourself into a lab animal.

The algorithms don't know you, don't understand you but can create massive difference in your life. Here's what chamath palihapitiya, a former vice president of user growth at facebook says:
> The short-term, dopamine-driven feedback loops we’ve created are destroying how society works.… No civil discourse, no cooperation; misinformation, mistruth. And it’s not an American problem—this is not about Russian ads. This is a global problem.… I feel tremendous guilt. I think we all knew in the back of our minds—even though we feigned this whole line of, like, there probably aren’t any bad unintended consequences. I think in the back, deep, deep recesses of, we kind of knew something bad could happen.… So we are in a really bad state of affairs right now, in my opinion. It is eroding the core foundation of how people behave by and between each other. And I don’t have a good solution. My solution is I just don’t use these tools anymore. I haven’t for years.

You are not a customer for social media companies. You are the product. They are addicting. And once you are addicted, you become a zombie. And zombies don't have a free will. 

The vast majority of money these companies make comes from parties who are seeking to change your behavior.

To free yourself, to be more authentic, to be less addicted, to be less manipulated, to be less paranoid, delete your accounts.

----
# Quit today to resist the insanity of our times
The problem isnt the smartphones or the internet. It's the BUMMER companies.  Author describes, bummer as a machine with six moving parts
- A for attention acquistion
- B for butting into everyone's life
- C for cramming content down people's throat
- D for directing people's behaviours in the sneakiest way possible
- E for earning money from letting the worst assholes secretly screw with everyone else
- F for fake mobs and fake society

We are all carrying around devices that are suitable for for the mass behaviour modification. Deleting your accounts now will improve the chances that yo'll have access to better experiences in the future.

# Social media is making you into an asshole
“You’re vulnerable to gradually turning into an asshole, or statistically you might very well be turning into an asshole. So, no offense, but please take the possibility seriously.”

On the internet, people are fighting with each other or  group of people. They are insulting each other saying incredibly stupid stuff. It happens so often that it has become normal.

Social media is degrading your character. Don't let your character degrade

# Social media is undermining truth
Truth is slowly dying in our times. Social media, which comprised of fake people, everything becomes fake.

Media forms that promote truth are essential for survival, but the dominant media of our age do no such thing.

# Social media is making you say meaningless
People on social media rarely speak the truth. They tell what others want to hear.

Even when the readers are real, not fake, algorithms are routing them to particular content, so their choices aren’t really independent. The measurements aren’t valid, by definition. You can’t tell someone where to go and then claim that you discovered something new because you learned where that person went. This is yet another ubiquitous problem that’s as hard to see as air.

Society as a whole has statistically shifted toward meaner behaviors because more hateful posts tend to get more attention.

# Social media is destroying your capacity for empathy
When other people are also becoming meaningless, you understand less about what's going on with them.

The degree of difference between what is shown to someone else and what is being shown is itself unknowable. The opacity of our times is even worse than it might be because the degree of opacity is itself opaque.

The internet was supposed to bring about a transparent society. The reverse has happened.

# Social media is making you unhappy
Several research have shown that social media companies make you unhappy. You can even tell by yourself how much less happy you are when you close the social media vs when you opened it.

# Social media doesnt' want you to have economic dignity
When social media companies are paid directly by users instead of by hidden third parties, then they will serve those users. It’s so simple. Someone will be able to pay to see poisonous propaganda, but they won’t be able to pay to have that poison directed at someone else . The incentive for poisoning the world will be undone.

# Social media is making politics impossible
Even when people are trying to make change through social media, the algorithms catalog their habits, actions and there preferences and dislikes.

This puts people who are trying to make a positive change in an unfacorable position. In other words, social media is seperating groups of people based on their likes and dislikes, habits and actions creating encouraging tribalism

# Social media hates your soul
Social medias are organized system to influence and guide the behaviours of a large group of people. 
Bummer companies are not just playing with your dignity and privacy, they are also playing with your soul. In the world of social medias, you are nothing more than a set of algorithms determind actions and behavior.

---
Don't reject the internet; embrace it. The inernet itself is ont the problem. Don't use BOMMER companies.

This book gives user of social media to open up a new perspective and see the reality. It gives a lot of ideas for why you should leave these social media companies even at least for a brief amount of time.


