---
title: Thus Spoke Zarathustra
author: Friedrich Nietzsche
category: Philosophy
publisher: Oxford University Press
publish_date: 2008
total_page: 384
cover_url: "https://books.google.com/books/content?id=sMHmCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 199537097
isbn13: 9780199537099
---
**Title:** Thus Spoke Zarathustra
**Author:** Friedrich Nietzsche
**Type:** #litnote #book #todevelop 

---