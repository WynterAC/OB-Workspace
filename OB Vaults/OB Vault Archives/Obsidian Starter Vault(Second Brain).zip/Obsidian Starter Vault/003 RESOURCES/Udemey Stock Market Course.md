---
---
**Creator: **
**Source: ** Udemy
**Type:** #litnote 
**Topics:** [[Trading]] [[💹Stock Market]]

---

Understand yoursel before stepping in the stock market?

What is your purpose ?

Have childrens?

Risk?

Goals?

How much tiime you can give to trading?

Are you chasing dividends?

Have family life?

---
Research tells you what to buy and charts tell you when to buy


Things to focus on:
- Rigorously minimize losses
- Don't be influenced by others, act on your own ideas
- Do your research before buying
- Be disciplined. Don't get emotionally involved and maintain absolute discipline to your plan

---- 
> - Stock market is a place where money flows from the impatient to the patient

Being wrong is acceptable, but staying wrong is not acceptable.

Hold limited number of stocks. Having a lot will make it hard for you to manage stocks
 