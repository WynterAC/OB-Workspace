---
---
**Title:** The 5 Most Productive Things to Do When You’re Too Tired To Work 
**Source:** (https://medium.com/swlh/the-5-most-productive-things-to-do-when-youre-too-tired-to-work-4157efe9091b)
**Author:** Berenike Schriewer
**Type:** #litnote 
**Topics:** [[Productivity]]
----

- For Self-employed, hard to be too tired and is rough
- Results are dependent on on the effort you put
- Working when you don't have energy can be painful 

- Determine your energy level: Rank your enery on level 1-10
	- 9-10: Do tasks that require extraordinary creativity, courage and grit.
	- 6-8:  Focus on regular tasks in your business
	- Below 5: Increase your energy level. Meditate, go for a walk, drink plenty of water
		- If you can't increase energy, give yourself an hour and try working on regular tasks
	- Too tired to work?:
		- level 5: Learn something new. Consume instead of creating
		- Level 4: Clean your inbox or do organization taskas
		- Level 3: Nurture your professional relationships
		- Level 2: Relax and do something fun
		- Level 1: Sleep or Nap