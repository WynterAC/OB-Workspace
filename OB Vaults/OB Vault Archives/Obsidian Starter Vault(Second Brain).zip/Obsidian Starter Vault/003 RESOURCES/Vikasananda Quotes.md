---
---
>  Hindu banega na musalman banega, insan ki aaulad hai insaan banega.

But like my uncle Rick once told me: “Try to make everyone happy, and you end up sad.”

He’s right. The bigger this email list gets, the more feedback we get.

Some people want the news. Others want investment advice. Or deep dive analysis. Or long think pieces. And some people just like hearing about new stuff with some light commentary from us on top.

So what do we do? I can’t make you happy, so I’m going to make me happy. 

That means I’m going to “write the email that I want to read.”

For me that means: 

-   Don’t report the news… just tell me what interesting stuff is going in crypto today?
-   …But remember, I’m busy, so summarize it for me 
-   …And remember, I’m dumb, so don’t use fancy words with me
-   …Oh and if you’re investing in something, I like money and want to hear about it

So that’s the game plan.