---
title: The Handbook (The Encheiridion)
author: Epictetus, Nicholas P. White
category: Philosophy
publisher: Hackett Publishing
publish_date: 1983
total_page: 35
cover_url: "https://books.google.com/books/content?id=9WRzxtTBkPgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: 
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 915145693
isbn13: 9780915145690
---
**Title:** The Handbook (The Encheiridion)
**Author:** "Epictetus", "Nicholas P. White"
**Type:** #litnote #book #todevelop 

---