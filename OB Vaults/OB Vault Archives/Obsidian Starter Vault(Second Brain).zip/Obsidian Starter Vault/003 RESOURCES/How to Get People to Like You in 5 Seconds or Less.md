---
---
**Source:** https://medium.com/the-mission/how-to-get-people-to-like-you-in-5-seconds-or-less-67e64cb91155
**Author:** James Altucher
**Type:** #litnote #todevelop 
**Topics:** [[Communication]][[Persuasion]]

----
- You are shy and scared to talk because you have never done it in your life.
- Want to talk to someone, be specific. Everyone wants to vomit their facts if you ask the right questions.
- Smile
	- Best way to let them know you like them. Be genuine, Don't fake it
- You brain tricks you to not talk to others. It wants comfort and your brain thinks talking to strangers is unsafe.
- We still have the same brain that our ancestors had a 10,000 years ago. During that time, talking to someone outside of your tribe might have gotten you killed. 
- Your brain will scream and shout and freeze and cause you actual physical pain if you want to talk to someone new.
- Be curious about thing that you want to know. If you are curious there's nothing bad about stopping in the middle and asking them what you want to answer.
- Be good, dress nice, smile and  be sincere and generous. people will at least stop. 

**How to be yourself?
Assume you are the dumbest person in the room. It somehow makes it easier to be yourself. We're alll in this journey together.
**