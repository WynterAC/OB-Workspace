---
---

**Source:** https://nicolascole77.medium.com/why-so-many-writers-fail-to-make-money-ed19110ac619
**Author:** [[Nicolas Cole]]
**Type:** #litnote 
**Topics:** [[Writing]]

----
- Nobody owes you shit
- You write doesn't mean  people have to read your stuff.
- Writing is not just about writing. Its not something you are born with. THIS IS WRONG
- You are in the game of thinking. want to make money writing? You can't do it by writing the same stuff everyone else has already written about. 
- Nobody is paying you to read the same stories again and again
- You have to write about new ideas, ideas that change the existing thought patterns and transform them inot powerful new conclusions. 
- Your writing can be gramatically incorrect, but if carries a strong message, and its readable, they will be erad
- Don't focus too much on what you put in the paper or type in the keyboard. Focus more on how you think and how your thoughts are different from others.