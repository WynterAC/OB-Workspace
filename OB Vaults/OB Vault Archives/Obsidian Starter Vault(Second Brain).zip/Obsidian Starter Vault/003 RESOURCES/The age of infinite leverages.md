---
---
**Source:** https://www.value.app/feed/the-age-of-infinite-leverage?utm_campaign=Visual%20%2B%20story.&utm_medium=email&utm_source=Revue%20newsletter
**Author:** Value.app
**Type:** #litnote 
**Topics:** [[Make Money Online]] [[The Great Online Game]]

----
- Leverage 100x your effort, skill and judgement
- No one in the history had this much leverage
- Age of infinite leverage 
- Our work can be replicated with no additional cost
- Leverage through capitalism, cooperation, technology
- Eight hours of work shouldn't be equal to eight hours of output today
- You can maximize the output of work to exponential degree
- Labor leverage and capital leverage: old school leverage
- Managing people is messy, many skills needed
- Money is new world leverage. You can scale well if you can manage 
- New school leverarge: Doesn't have any marginal cost of replication and is permissionless
- Blown up with internet and coding. 
- All you need is a computer and your are set
- Leveraged worker can out-produce a non-leveraged worker by a factor of one thousand or ten-thousand
- Judgement>>>How hard you work
- Follow your intellectual curiosity instead of running behind every flashy thing
- 