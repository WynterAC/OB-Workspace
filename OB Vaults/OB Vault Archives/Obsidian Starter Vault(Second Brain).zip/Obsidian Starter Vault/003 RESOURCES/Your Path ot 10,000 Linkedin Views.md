---
---
**Source:** (https://timdenning.com/linkedin-lessons-part-2/)
**Author:** Tim Denning
**Type:** #litnote
**Topics:** [[LinkedIn]] 

----
- Different platforms show different things
- Linkedin is professional business platform 
- Your content should be contexulized for the platform
- You can't just copy and paste 
- LinkedIn voice is about sounding professional. What would a business or your potential customer would like to engage with
- Write from scratch with the sound in mind
- Think as if your boss is looking over your shoulder when you are writing on linkedin 