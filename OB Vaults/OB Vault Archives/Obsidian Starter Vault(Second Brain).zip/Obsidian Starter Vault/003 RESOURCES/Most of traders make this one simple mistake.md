---
---
**Creator:** Day Trading Addict
**Source:** https://youtu.be/q58za5aJrvc
**Type:** #litnote 
**Topics:** [[Trading]]

---

- Most people play the losers game
- They try to do the impossible
- An example of changing someone with a bad attitude in a date just because she is gorgeous
- Trying to change anything is something thats extremely hard
- You can't have 90% win rate
- Its okay to have 50% win rate. 
- You only need to win 30% of the time if your Risk to reward ration is 1:3
- If you come on the market without any plan, the market is going to take you away with its flow.

**The beginners, the amateurs are the ones who are losing the most money on the market.** Those who don't have a plan. **Those who trade without a plan. They are the ones whose pocket gets ridden of.**


# Don't play a losing game
- Have a journal. Review your trades. Study. Don't try to skip the steps