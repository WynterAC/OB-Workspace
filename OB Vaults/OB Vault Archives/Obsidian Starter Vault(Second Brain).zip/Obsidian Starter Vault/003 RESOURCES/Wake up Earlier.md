---
---
Title: 
Source:
Author:
Type: #litnote 
Topics:

------------------------------------
It was the hardest fucking thing I had done in a long time. But I did it.

-   bet you could too
    
-   how much better your day would be if you accomplished your hardest, most important work first thing in the morning.
    
-   You could relax in the evening without feeling like a bum or stressing because you let another day slip by without doing what you planned.
    
-   For most of the population, 5:30 AM is not a normal time to be awake
    
-   There’s no switch you can flip to make yourself consistently wake up that early, especially if doing it for your own reasons (i.e. not doing it to avoid being fired).
    
-   It sounds extremely cheesy, but if you want to wake up earlier, you’ve got to really want it.
    
-   At some point, you’ve got to become obsessed with whatever your dream is. For me, that was writing.
    
-   I realized I wanted to be a writer.
    
-   want to be a writer. I still suck at writing, but I want to get better. I need to get better. I’m obsessed with getting better.
    
-   If I didn’t wake up earlier, I couldn’t write.
    
-   If I couldn’t write, I wasn’t a writer.
    
-   If I wasn’t a writer, I wasn’t chasing my dream
    
-   Going to bed earlier
    
-   “Winding down” before bed
    
-   Planning my morning the day before
    
-   Exercising during the day
    
-   I set an alarm the night before and say to myself…
    
-   “I have to get up at five-thirty tomorrow to write.”
    
-   Don’t skip this step. It might seem silly, but trust me, the mental pep-talk helps.
    
-   Do give yourself something to look forward to after waking up. For me, that’s a hot cup of coffee before getting down to business.
    
-   Try setting your alarm across the room if you struggle with snoozing. I used to do this but don’t anymore. For some strange reason, it actually didn’t work for me, though I’ve heard others who do it with success. I found it to be a fun game running to the alarm and seeing how fast I could dive back into bed. My brain is weird sometimes.
    
-   Having a partner to keep you accountable can make a world of difference. For me, that happened to be Mose.
    
-   Even the obsessed and highly disciplined can fall victim to the perfect storm of life’s problems. Prepare for this by having a back-up: an accountability partner to carry you through those tough times.