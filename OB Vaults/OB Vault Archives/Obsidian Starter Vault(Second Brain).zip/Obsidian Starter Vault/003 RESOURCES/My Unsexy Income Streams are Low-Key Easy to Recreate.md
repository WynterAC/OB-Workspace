---
---
**Source:** Newsletter
**Author:** Tim Denning
**Type:** #litnote
**Topics:** [[Side Hustle]] 

----
- Content Creator
	- Everyone have certain skills. Everyone is a creator. Most people have not just realized it yet. 
	- Sell E-books
		- Help people for free and comment a link to your ebook
	- Content royalities
	- Coach
		- If you can show social proof with a skill, you can coach others.
	- Sell Templates
		- Any sort of templates
		- Journal templates
		- Calendar templates
		- Notion Templates
		- Templates= shortcuts
		- People love to pay to save time
	- HIgher priced consulting
	- Web 3.0
		- Blockchain revolution
	- Affiliate marketing

Learn skills and then monetize them. Build skills. The most unsexy income sources are the easiest to recreate. 