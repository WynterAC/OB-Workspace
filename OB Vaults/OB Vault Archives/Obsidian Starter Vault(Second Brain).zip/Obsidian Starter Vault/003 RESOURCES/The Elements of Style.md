---
title: The Elements of Style
author: William Strunk, Elwyn Brooks White
category: Reference
publisher: Penguin Putnam Books
publish_date: 2005
total_page: 147
cover_url: "https://books.google.com/books/content?id=pYYUAQAAIAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 
isbn13: 
---
**Title:** The Elements of Style
**Author:** "William Strunk", "Elwyn Brooks White"
**Type:** #litnote #book #todevelop 

---