---
---
Capitulation in a financial market means a dramatic surge in selling pressure in a falling market. The investors or trades give up on the market. They think there is no chances of recovering. Capitulation happens when even the ultimate bullish people start seeing the fall and start selling their assets.

Capitulation is often regarded as a sign of the bottom of market. Here lies the biggest opportunity to make money in the market. But its not easy to spot the capitulation and neither it is to trade during capitulation. You have to have the ball of steels to trade during these times.

The bottom is not confirmed if the bulls get excited on every bounce. For capitulation to happen, there should be disbelief on bounces instead of euphoria and optimism. 

The market doesn't make it easy to make money anyways.



----
**Type:** #permanentnote 
**Topics:**
**Reference:** 

