---
---
**Source:**
**Author:**
**Type:** #litnote 
**Topics:**

----

----
- No matter how much you try to manage your time to finish your to-dos. If you don't have energy, its all uselsess
- How to have more energy
	- Sleep enough: 6 hours is not enough
	- Physical activity: Best thing you can do to increase your energy levels/ Time your workouts
	- Turn off yoru phone: Its magical. They can be immensly useful but can also sap our energy. Keep the phone down as much as possible
	- Set ambitous but realistic goals: Choose goals that stretch you and break down the bigger goals into smaller chunks help you build momentum.
	- Figure out what energizes you. 
		- Not all work is created equal. Delegate what don't make you excited and ready to jump in. 
	- Arrange your schedule to suit your energy levels.
- 