---
title: The Simple Path to Wealth
author: J. Collins
category: Personal Finance
publisher: Createspace Independent Publishing Platform
publish_date: 2016
total_page: 286
cover_url: "https://books.google.com/books/content?id=yRaMDAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Completed
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1533667926
isbn13: 9781533667922
---
**Title:** The Simple Path to Wealth
**Author:** J. Collins
**Type:** #litnote #book #todevelop 

---
There's no shortage of stuff you really want to read. You can go online and find almost anything that you want to learn. Every bit of knowledge that you aspire to gain, it's waiting for you in a book, blog post, video or a podcast somewhere.

---

People make investment and making money endlessly complex because that's how they get more profitable.

The secret to growing wealth and being rich is to spend less than you earn and investing the surplus while avoiding debt. If your lifestyle mathces or forbids your income, then you are no more than a slave.

Money can buy many things, but the best thing it can buy you is your freedom.
