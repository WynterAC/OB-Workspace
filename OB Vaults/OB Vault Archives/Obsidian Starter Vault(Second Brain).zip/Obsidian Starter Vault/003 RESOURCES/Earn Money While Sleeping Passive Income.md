---
---
**Creator:** Dr. Vivek Bindra
**Source:** https://youtu.be/DqzzzTzCPVc
**Type:** #litnote #todevelop 
**Topics:** [[Passive Income]] 

---
- If you don't find a way to make money while you sleep, you'll have to work all your life
- Build a system that will give you income without much effort.
- Don't earn with your time. Earn with your mind
- **Linear Stops** & **Residual Income**
- Multiple ways to earn passive income
	- Long-term stock
	- Rental income
	- Ebooks
	- Licensing
	- Blogger
	- Online courses
- Don't need to choose a traditional income. You can make money through any career. 
- Skill: What can be learned
- Passion: what excites you
- What you are born with: talent
- Make a course on whatever you know. Anything stock market, coding, knowledge management and anything
- **Passive income**
	- Immediate
	- Regular
	- Sustainable
	- Increasing
	- Process-oriented cashflow
- HOW TO GET LEADS and Traffic
	- Make free videos, relevent videos
	- Go on any social media platform and make videos