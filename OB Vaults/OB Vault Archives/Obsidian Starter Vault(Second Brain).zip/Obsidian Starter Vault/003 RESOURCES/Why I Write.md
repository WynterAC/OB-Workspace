---
title: Why I Write
author: George Orwell
category: Language Arts & Disciplines
publisher: 
publish_date: 1946
total_page: 100
cover_url: "https://books.google.com/books/content?id=Nb0OzgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 2382262133
isbn13: 9782382262139
---
**Title:** Why I Write
**Author:** George Orwell
**Type:** #litnote #book #todevelop 

---