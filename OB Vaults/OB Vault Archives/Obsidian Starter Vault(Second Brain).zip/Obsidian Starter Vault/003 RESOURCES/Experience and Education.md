---
title: EXPERIENCE AND EDUCATION – Premium Edition (Including Democracy & Education)
author: John Dewey
category: Education
publisher: e-artnow
publish_date: 2016
total_page: 102
cover_url: "https://books.google.com/books/content?id=9nMrDAAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 8026853849
isbn13: 9788026853848
---
**Title:** EXPERIENCE AND EDUCATION – Premium Edition (Including Democracy & Education)
**Author:** John Dewey
**Type:** #litnote #book #todevelop 

---