---
---
**Source:** https://medium.com/the-quick-club/your-reader-has-to-express-at-least-1-out-of-these-7-reactions-if-you-want-to-go-viral-4b0171a42589
**Author:**
**Type:** #litnote 
**Topics:** [[Writing]] [[Writing Tips]] 

---
- **You need to target a specific emotion**
	- LOL
	- WTF
	- WOW
	- NSFW
	- OHHH
	- FINALLY
	- YAY
- If your content, be it writing or video or tweet doesn't have any of the emotions above, you are not going viral.
- **Powerful Hooks**
	- Mythbusters
		- Everyone thinks one and you think other
		- Your contradicting statement
		- Common belief vs unpopular opinion
	- Write about what's currently trending
	- Choose polarizing topic and create some kind of narrative arc.
		- People want to know strong opinions. Bland topics don't get views
		- Once you go viral, *You are going to piss off some people. Some are going to take offenses to their sensitive asses*
	- Take things that are complicated and make them simple.
	- Don't use fancy words. Write to a 2nd-grader
	- Don't be selfish. Think about your readers. Entertain or educate them. 
	- **Play by the rules of the internet**
		- Don't feel shame for using a cliche and clickbaity headlines. Feel it only ifyou don't have good content. 
		- If you have good content, its your responsibility to make sure people read it.
		- Look at the analytics and see what people liked about it and try to recreate it again.
		- *Learn from the data you are gathering.*