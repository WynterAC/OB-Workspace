---
title: When The Scientific Secrets of Perfect Timing
author: Daniel H Pink
category: Psychology Business & Economics
publisher: Penguin
publish_date: 2019
total_page: 288
cover_url: "https://books.google.com/books/content?id=EJ9-DwAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 735210632
isbn13: 9780735210639
---
**Title:** When: The Scientific Secrets of Perfect Timing
**Author:** Daniel H. Pink
**Type:** #litnote #book #todevelop 

---