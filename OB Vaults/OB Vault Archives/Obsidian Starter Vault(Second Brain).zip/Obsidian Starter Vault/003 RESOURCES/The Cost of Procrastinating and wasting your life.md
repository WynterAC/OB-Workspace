---
---
**Creator:** Jordan Peterson
**Source:** https://youtu.be/nccvDyjvdps
**Type:** #litnote 

---

- People hate arithematic, but I like doing it.
- If you spend the productive hours in your 20s, you get the compounding effect throughout your life.
- How much your life would be worth if you weren't wasting all those hours everyday.
- Quit wasting time by your own defination. Don't waste your life. 
- People hate it when they waste their life. They feel bad. They feel anxious. You feel rotten internally.
- Look how undisciplined you are. How unstructured you are. How you can't stick to a routine. You don't have a calendar. You know nothing about the world.