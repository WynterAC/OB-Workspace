---
---
### Introduction
- Moving average is the sum of past market data. It summarizes the historical price of a particular stock.

### Use MA to find Relative Strength(Which Stocks are Strong and which are weaker ones)
- If the price is above MA, it is stronger
- The more the gap in price and MA, the more strong the stock is in Strong market

### Use MA to Find Support & Resistance
- Be patient and let the price come to you. 
- In a trending market, the price seems to respet the 50 day EMA

- If the price is above 200MA look for buying opportunities. If the price is below 200MA, look for shorting opportunities
