---
---
**Creator:** [[JIm Rohn]]
**Source:** (https://www.youtube.com/watch?v=DKvjDFTlYTw)
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]]

---


- You run the day or it runs you

- Seperate majors from minors. Put your game plan on paper. Don't mistake movement with achievement. It's easy to stya busy

- Concentration: Lack of concentration messes a lot of things. Wherever you are, be there. Take a look around. Study the people around you. Study human nature

- Say no: It's difficult. Good to say no than saying yes and backing up
- When you work, work, when you play, play: 
- Analyze how you are: "Don't give the chairman everything". Do what you are good at it. Make arrangements for things that you can't do properly. Save yourself from all the other work
- Beware of the telephone: Useful but can get you in trouble. Make sure you have an agenda before you pick a phone.
- Read all the books: 