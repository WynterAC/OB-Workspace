---
---
**Source:** https://medium.com/writers-blokke/a-highly-effective-method-for-publishing-1-3-articles-a-day-69d5df547c0f
**Author:**
**Type:** #litnote 
**Topics:** [[Writing]] [[Writing Tips]]

----
- To be better, learn from people who have already done what you want to do.
- Right side of brain= Creative, intuitive
- Left side of the brain= Analytical, cognitive, and thinking side.
- Ride side is activated during writing or creative writing, left side during editing. 
- Trying to do both at the same time is like stepping on gas and brake.
- The right want to speed up but the left wants to slow down, pause and carefully choose what's next.
-  “Write without fear, edit without mercy” — Unknown
- **Want to write faster?**
	- Bulk tasks that are similar and your brain will thank you for it.