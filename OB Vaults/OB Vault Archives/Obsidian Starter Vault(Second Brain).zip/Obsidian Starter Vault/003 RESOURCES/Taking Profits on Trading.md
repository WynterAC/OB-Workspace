---
---
**Source:** A lot of youtube videos
**Type:** #litnote [[Trading]]

---

- Don't be too greedy. It will take out all your losses
- Making profits and taking profits is different
- Learned this the hard way. Didn't cash out. 
- Applies to stocks and assets with a very bullish run-up
# Strategy
- For every 10%, the share price goes up, I take 5% off my position
# Pros
- You get to reap the rewards of the gains
- You'll have extra cash on hand 
- You won't be hit hard if the stock gets down the next down
# Cons
Migh get slightly less gains if the assets continues to run up. But its worth the peace of mind that it will bring to you.

> Its important to make money along the way because no body knows where the top is. 

You can make you own strategy. Make mistakes and learn from them. 

Be careful around round up numbers. They have psychological effect on the market.
>  Don't Gamble in The Market. Take Calculated risks. This will put you on a path to be a professional trader.

