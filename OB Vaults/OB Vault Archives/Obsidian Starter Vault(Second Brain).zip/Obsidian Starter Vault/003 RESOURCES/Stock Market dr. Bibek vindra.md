---
---
**Creator:** Dr. Vivke Bindra
**Source:** https://youtu.be/sbdW1yy8GxU
**Type:** #litnote 
**Topics:** [[💹Stock Market]] [[Fundamental Analysis]]

---




SHAREMARKET is not a gambling house house it can be predicted it can be analysed and it can be forecasted and a lot of money can be made out of share market it is not impossible to make 20% 25% 30-35% return on stock market.
Investment typestypes

Fd(5%)
Real Estate(negative)
Gold Bonds
Savings (2-3%)

#  Share Market(mutual funds or secondary market)
- Dont ask for tips from others

---
- The company should be at least 11 years old. It should have gone through all the economic cycles. Crashes and bubbles. The older the company, the better. You have to learn to know the track record.
- Growth consistency. Its growth rate should be at least twice the GDP. 
- Leadership is directly proportional to longetivity. You should see how competitive the company is how is the leadership. Check upon the CEO or management or owner of the company.
- Zero debt. Comapnies with debt are busy repaying their loans. They will not be able to pay to their shareholders. Check the DEBT TO EQUITY RATIO.
- Promoter should have at least 51% ownership in the company.
- Profit after tax should increas by 25%. Analyze the profit of their past financial history.
- Companys revenue and unit sale should increase. Also see units increased. 10%-15%.
- Net operating cash flow increased by 20%
- Return on capital employeedemployeed should be more than 20%.
- Return on Equity should be 15% at least

---
