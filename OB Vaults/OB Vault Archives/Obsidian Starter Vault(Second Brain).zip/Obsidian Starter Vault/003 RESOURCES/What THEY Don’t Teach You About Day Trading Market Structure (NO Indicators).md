---
---
**Creator:** [[The secret Mindset]]
**Source:** https://youtu.be/ljiOakOsIuI
**Type:** #litnote #todevelop [[Trading]]

---
- Establishment of market structure is the most important factor
- You have to find which side is in control 
- **Bullish:** Higher highs and higher lows
- **Bearish:** Lower lows and lower highs
- **Sideways:** Trends in a range and is in consolidation. Range breakouts
- **Principle 1:**
	- To be in active structure, the recent structure 