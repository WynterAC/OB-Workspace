---
---
**Source:** https://medium.com/swlh/act-like-you-dont-need-the-money-be-wildly-successful-835b1e3582eb
**Author:** Scott Stockdale
**Type:** #litnote 
**Topics:** [[Money]] [[Wealth]] 

----
- Start now. No funding needed
	- Don't wait for someone to come or something to happen. Have ideas? Execute on them
	- Don't be a person who is more in love with the idea of being the big-big-big without doing something useful
	- A good idea without execution is not worth much. But a not-so-good idea brough to life is better. Brilliant idea however is the holy grain
- The best plans start simple
- Thrill them and they'll tell everyone
- We want to give to those who give/ Don't hold the scarcity mindset
- There's a big difference between self-employed and being a business owner.

Lessons from book: Anything you want by derek sivers.

> “A real book is not one we read but one that reads us.” — WH Auden
	