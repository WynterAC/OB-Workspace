---
---
**Creator:** [[The secret Mindset]]
**Source:** youtube
**Type:** #litnote #todevelop [[Trading]]
---

- VSA: look for validation and divergence
	- Validation: Continuation
	- Divergence: Signal of potential change
- It takes effort for the market to rise and also effort for the market o fall
- large price up should be validated by above average volume
	- Confirms that market move is genuine and notmanipulated by smart money
- Big result with low effort= **Divergence** [Signal of trap]
	- Narrow spread candle with large volume= divergence
	- Large spread with small volume= Divergence
- **VSA must be used wit other tools**
	- Support and resistance
	- Trend lines
	- Candles
	- VSA can be used for validation
	- Tools 
- **Multiple candles divergence**
	- We first look at the divergence of one candle at first. Then we look at the 

**The effort and the result should validate one another.**


## Decide where you are in a trend before making any analysis
	- Maybe the market is at resistance, or maybe at the support and may be at the minor pullback