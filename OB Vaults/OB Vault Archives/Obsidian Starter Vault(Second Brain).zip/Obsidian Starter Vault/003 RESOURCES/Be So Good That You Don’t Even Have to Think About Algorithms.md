---
---
**Source:** https://writingcooperative.com/be-so-good-that-you-dont-even-have-to-think-about-algorithms-f6dd8cd1b8cd
**Type:** #litnote 

----
- Algorithms are not here to serve you. You are.
- They prioritize ads over your free content. 
- Algorithms have shifted from interests of users to interests of the owners of the platform.
- Understand this or die as a creator
	- Algorithms have an experience factor
		- Don't poke the algorithm with a stick
		- The algorithm will notice your behvaiours. It takes note
		- You no longer become priority
		- **Be nice to platforms you post on**
		- Cheat the algorithm by repurposing content for more than one algorithm
		- If one algorithm is being a son of a b*tch, then simply find its competitor and publish there for a while.
		- ach platform has its own quirks. Learn the quirks and then edit your content accordingly
		- ***Lazy efforts, lazy results***
		- Quality over quantity
		- It defeats most algorithms
	- Add your personality
		- Use strange words. Make up your own words. Stuff you love, talk about what's cool and trendy
	- Do research
		- Don't create with only your point of view. Do research. Back up
	- Format to make audiences life easier
	- Make the first thing you say memorable
***Stop blaming the algorithms for low-quality content that focuses on your interests and is lazy***


Create better content. Share it on multiple platforms.