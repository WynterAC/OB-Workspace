---
---
**Title:** How to Actually Achieve More in A Day than Most Normally Do in A Week
**Source:**(https://betterhumans.pub/how-to-actually-achieve-more-in-a-day-than-most-normally-do-in-a-week-e1193433c431)
**Author:** Neeramitra Reddy
**Type:** #litnote
**Topics:** [[Productivity]]

----
- Most productive days
- Do every things
- No table or insane willpower
- Honed systems, consistent habits, optimized framework

- Tips to Stay Productive
	- Sleep
		- Don't brag
		- make or break you day
	- Ruthlessly priortize
		- 24 hours not enough to do everything
		- Create two buckets: 
	- Chisel down to the finest level of detail
		- Steer away generality
		- Make them specific and impossible to interpret them in more than one way
	- Cultivate Tasks specific rituals
		- Form ans stick to rituals
	- Make it impossible to be distracted
		- Focus is the centerstone 
		- Turn off notification
		- Calm and isolated environment
		- Play same song on repeat
		- Time blocking software