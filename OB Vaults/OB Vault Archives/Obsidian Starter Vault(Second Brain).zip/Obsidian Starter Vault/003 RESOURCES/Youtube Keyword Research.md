---
---
# How to Do Keyword Research For Youtube

## Types of Keywords
- Short Tail Keywords
	- Short Tail Keywords
- Long-tail Keywords

---








