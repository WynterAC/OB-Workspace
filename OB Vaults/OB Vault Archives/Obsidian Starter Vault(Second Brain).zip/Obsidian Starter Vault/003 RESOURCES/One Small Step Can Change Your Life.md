---
title: One Small Step Can Change Your Life
author: Robert Maurer
category: Self-Help
publisher: Workman Publishing
publish_date: 2014
total_page: 228
cover_url: "https://books.google.com/books/content?id=XZTiAgAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 076118032X
isbn13: 9780761180326
---
**Title:** One Small Step Can Change Your Life
**Author:** Robert Maurer
**Type:** #litnote #book #todevelop 

---