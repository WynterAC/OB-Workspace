---
---
Price action is a chart reading technique to find buying and selling opportunities without using any indicators by analysinf the swings or the movements in the market.

Stocks always move in swing in the stock market. They never go directly from bottom to top or top to bottom. That's where we find buying and selling opportunities.

As a price action traders, we should only trade when we are either in uptrend or downtrend. Don't enter the trade when the market is consolidating.

----

**Reference: ** [[Complete Price Action Trading Complete Beginner to PRO(2021)]]
**Type:** #permanentnote 
**Topics:**[[Trading]] [[💹Stock Market]]


![[Recording 20210922092933.webm]]
