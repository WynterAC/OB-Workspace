---
---
**Source:** [https://www.wealest.com/articles/optimum-lifestyle
](https://www.wealest.com/articles/optimum-lifestyle)
**Type:** #litnote #todevelop 

----
- Not meant for working forty hours and live for weekened
- People get job first and design their life around job
- Leverage changed the game
- Design your life first and find the leveraged career that suits you
- “I want my work to help me design my preferred lifestyle, not my work to dictate what my lifestyle can be… The biggest opportunity cost is enduring a lifestyle you dislike…Thinking about opportunity cost in terms of earning potential is missing the point. If you're enduring an existence you dislike, you're missing out on a lifestyle that matches your true preferences. That's the real opportunity cost.”- Daniel Vasallo
- Have a lot of free time for thinking, walking and for exercise. 


***Don't just work hard. Think harder. Find the leverage and use it.***