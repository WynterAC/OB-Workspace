---
---
**Source:**  https://fortelabs.co/blog/para/
**Author:** Tiago Forte
**Type:** #litnote 
**Topics:** [[Build a second brain]]

----
- Projects
	- has a goal to be achieved. You can have this item to be checked off.
	- It has a deadline and timeframe: externally or self-imposed
	- They fall into areas
	- You can't cross off productivity or health. So they can't be your projects
	- You can't know if you are making progress towards your goal
- Areas
	- They require completely different ways of thinking. You have to be laser-focused towards an outcome
	- It requires introspection and self-awareness
- A project without corresponding goal is like a hobby
- IF you have a goal without a projectm its only a 'dream'
- Define your projects
- PARA gives you consistency of centralization an with adaptability of decentralization
- IT mirrors task management and project management