---
title: Mistakes Were Made (but Not By Me) Third Edition
author: Carol Tavris, Elliot Aronson
category: Psychology
publisher: HarperCollins
publish_date: 2020
total_page: 400
cover_url: "https://books.google.com/books/content?id=vZkGNIpAsTEC&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 547416032
isbn13: 9780547416038
---
**Title:** Mistakes Were Made (but Not By Me) Third Edition
**Author:** "Carol Tavris", "Elliot Aronson"
**Type:** #litnote #book #todevelop 

---