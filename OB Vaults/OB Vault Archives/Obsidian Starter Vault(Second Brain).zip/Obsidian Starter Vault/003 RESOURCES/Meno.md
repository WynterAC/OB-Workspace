---
title: Plato’s Meno
author: Plato
category: Philosophy
publisher: Lindhardt og Ringhof
publish_date: 2020
total_page: 29
cover_url: "https://books.google.com/books/content?id=sp7xDwAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Reading
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 8726627566
isbn13: 9788726627565
---
**Title:** Plato’s Meno
**Author:** – Plato
**Type:** #litnote #book #todevelop 

---