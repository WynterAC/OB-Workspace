---
---
**Source:** https://www.betterup.com/blog/manage-your-energy-not-your-time
**Author:**
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]] [[Energy Management not Time Management]]

----
- Always more to do than time
- Even if we know how to master time, feels like it isn't enough.
- Learn to manage energy and then time management will be effortless
- You need to match your energy to a task in order to complete
- How you invest your energy is more importnat that time
- You need to full engagement: physical, emotional, mental and spritual energy.
- Time is finite but energy is not. Time constant but energy not. 
- Scheduling every minute of the day might seem like good use, but it doesn't account for energy
- Some tasks require more energy than others.
- High-energy tasks can't be done productively while multi-tasking
- Lack of energy = dip in productivity



#### How to manage energy to excel time management
- Set boundaries to protect your energy levels. 
- Include rest and recovery in your plans- schedule downtime
- Schedule time for deep work- where you can have uninterrupted focus on high-impact work
- Keep a journal of  your energy levels: Energy levels vary differently from person to person adn day to day. Keep a journal to help you find what you really value and want to spend energy on?
- Learn delegation: Delegate tasks that don't energize you or what drains you.
- Managing energy will make you productive and more fulfilled in your work.
-  