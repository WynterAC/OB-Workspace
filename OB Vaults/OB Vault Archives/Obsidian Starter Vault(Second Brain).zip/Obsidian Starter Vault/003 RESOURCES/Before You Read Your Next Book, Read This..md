---
---
**Source:** https://medium.com/swlh/before-you-read-your-next-book-read-this-ee737d04b60c?
**Author:** Karan
**Type:** #litnote 
**Topics:** [[Reading]] [[Books]] [[Note Taking]]

----
- Just reading a book won't help you in anyway.
- Reading books is costly. Not the economoic cost but mental cost. Do it right or don't do it at all.
- Divide your book into parts
	- Your brain can't proces multiple information at once. 
	- Reading alone don't give you success. Plan strategize execute and achieve your goals
	- In order to go long-term you have to enjoy your reading sessions
- Mark now, take notes laters
	- Underline,, highlight or do anything. 
	- Before you begin your next reading session, go through previous days notes
- Summarize your notes
	- Don't over summerize. Make your summary understandable to person who haven't read the book/
- Revisiting is always fun
- 