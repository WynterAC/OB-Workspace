---
title: Meditations
author: Marcus Aurelius
category: Philosophy
publisher: 
publish_date: 2018
total_page: 304
cover_url: "https://books.google.com/books/content?id=xp5CvgAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Unfinished
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1945186240
isbn13: 9781945186240
---
**Title:** Meditations
**Author:** Marcus Aurelius
**Type:** #litnote #book #todevelop 

---