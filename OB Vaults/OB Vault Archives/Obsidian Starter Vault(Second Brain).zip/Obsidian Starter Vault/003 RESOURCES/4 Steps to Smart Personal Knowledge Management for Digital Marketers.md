---
---
**Source:**
**Type:** #litnote 

----
- PKM is taking over internet
- Process of collecting and and storing information for future use for content creation.
- Primary goal is to easily save them and access them when needed.
- Digital hording doesn't help you use that informaion
- Add you own context, systema nd make information easy to surface when reference/

- capture ideas as you find them
- Process and add your own context
- Incubate your ideas
	- Process your ideas through inbox and add enough context for the future.
- Make connections between different ideas
- Create New things out of those ideas.
- Incubation effect is when you have the 'aha'  moment.