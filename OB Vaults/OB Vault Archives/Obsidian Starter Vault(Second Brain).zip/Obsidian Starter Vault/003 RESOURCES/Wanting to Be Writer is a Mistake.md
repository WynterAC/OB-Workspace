---
---
**Title: ** So You Want To Be A Writer? That’s Mistake #1
**Source:** So You Want To Be A Writer? That’s Mistake #1
**Author:**Ryan Holiday
**Type:** #litnote 
**Topics:**[[Writing]] [[How to Be Better Writer]]

----
schopenhauer once observed there are two types of writers: Those who write because they have somethign to say and those who who write for the sake of writing.


Many people give advices to write better, you have to write daily, write more. But that's often true.

Nobody tells you to do something. Go out in the world and do something exciting.

Any piece of writing is good because of what it says. When the writer manages to communicate something to you, it's because of something what's within it, not how they wrote it.


ood writing saves nothing. On the other hand, a deep, compelling or stunning message can float writers who struggle to even complete a sentence.

Writing just for the sake of writing is easy, if you are just looking to be published. But to get noticed, that's the hard part.


> What matters more than any other single thing in your writing it what you are saying. If it's different, if it's interesting, if it provokes response form people you have done it.
