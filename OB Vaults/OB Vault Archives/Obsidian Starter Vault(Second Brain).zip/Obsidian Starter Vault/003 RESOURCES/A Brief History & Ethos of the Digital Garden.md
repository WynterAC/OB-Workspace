---
---

**Source:** https://maggieappleton.com/garden-history
**Type:** #litnote #todevelop 
**Topics:** [[Digital Garden]]

----
- Unlike blogs, they don't need to be polished
- They are free-form work in progress wikis
- Collection of evolving ideas
- Inherently exploratory throught linking and contextual associations
- Not refined. Half-finished thoughts that will grow and evolve over time. 
- Less rigid and less perfect than blogs
- Digital garden is a different way of thinking about our online behaviour around information
- You choose to follow your curiosity and let that trail follow you rather than any algorithm 
- [ ] Good ideas take time to germinate
- They are imperfect by design. They don't hide rough edges and claim to be a permanent source of truth
- Less performative than blog but more intentional and thoughtful than twitter
- It enables you to share what you learn as you learn it not after a decade when you are an expert
- 