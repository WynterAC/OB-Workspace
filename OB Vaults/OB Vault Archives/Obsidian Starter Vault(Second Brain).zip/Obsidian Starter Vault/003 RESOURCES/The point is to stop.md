---
---
**Source:** Newsletter
**Author:** Mark Manson
**Type:** #litnote 
**Topics:** [[Personal Development]] 

----
- Two types of people: coach people and doctor people
- Doctor people:
	- expect the doctor to fix the problem
	- Think personal growth as information to be learned rather than skill
- Coach people:
	- they understand personal growth is a skill
	- You start horrible and become somewhat good at it
	- You commit to them. You don't solve them overnight

- Don't try to be something. It will only inhibit your growth
- Skill of personal growth doesn't work like basketball or chess
- You don't need to put more effort when you get better. the less effort is required to further improve.

> Its like skiing downhill. Takes a lot of effort to go downhill but once you catch speed, the most effective thing you can do to gain speed is nothing.

"doing nothing is a surprisingl difficult skill"

You have to stop at some point. 
- The whole point is to stop so that you can be free of consciously thinkng abuot it. The way to win 'anxiety' is to stop caring abuot your anxiety. The way to win at productivity and health is to integrate them into your life so completely that you stop thinking about them compeletly.


- Once you are downhill, don't struggle to get going. Do nothing. You will fly just at the fulls peed ahead.
- 

