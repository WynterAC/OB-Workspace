---
title: The art of always being right
author: Arthur Schopenhauer
category: Philosophy
publisher: GOODmood
publish_date: 2013
total_page: 60
cover_url: "https://books.google.com/books/content?id=OpNiAgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 8862776543
isbn13: 9788862776547
---
**Title:** The art of always being right
**Author:** Arthur Schopenhauer
**Type:** #litnote #book #todevelop 

---