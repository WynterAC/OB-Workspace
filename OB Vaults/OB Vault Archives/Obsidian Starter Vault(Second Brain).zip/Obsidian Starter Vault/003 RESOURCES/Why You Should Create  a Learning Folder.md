---
---
**Title:** Why You Should Create a “Learning” Folder Now 
**Source:**  https://davidawiebe.medium.com/why-you-should-create-a-learning-folder-now-4cd89b12462b

**Author:** Andrew Wiebe
**Type:** #litnote 
**Topics:** [[Writing]] [[Creativity]] [[Note Taking]]

----

- Knowledge worker spends significant time on idea generation
- How much content do you consume?
- People consume but very few people take notes and tiny number actually apply it
- Use whatever tool you want. Make it simple and resistance free 
- Capture your ideas or you lose them
- Make a note of what you are learning
- Note down noteworthy quotes
- Note-taking might slow-down consumption 
- Reading faster is pointless if you can't use it in any part of you
- You can read more books, or you can become a master at learning and applying what you’re studying.
- It isn't easy makes you think 