---
---
**Source:** https://jamesaltucher.com/blog/1-rule-no/
**Author:** [[James Altucher]]
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]][[Personal Development]]

----
- Don't be scared to say no.
- Don't be scared to hurt someone who can then thrash you. 
- Don't be afraid to turn down the opportunity
- Here's how you can decide to say 'Yes' or 'No' to the opportunity or an offer
	- Will you learn something?
	- Is it fun?
	- Is it financially worthwhile
	- Is it worth your time?