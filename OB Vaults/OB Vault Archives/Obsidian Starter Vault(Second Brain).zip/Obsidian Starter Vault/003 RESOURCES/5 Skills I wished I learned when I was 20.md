---
---
**Source:** Newsletter
**Author:** Tim Denning
**Type:** #litnote 
**Topics:** [[Make Money Online]]

----
- Salesman
	- Learn to sell yourself
	- The basics of sales are simple
	- Understand entry-level human psycholog
	-  Give more than you take
	-   Focus on other people, not yourself
	-   Communicate your value simply
	-   Provide evidence of why someone should buy into your idea
- Unselfish Storytelling
	- Storytelling is the key. 
	- It has enormous value. 
	- It acts as a magnet to attract humans 
- Writing online
	- Normal writing and writing online are completely different
	- The best passive income is the the one you can make from the email subscribers that you later offer your products and services to .
- Sending DMs that get replies
	- The best DMs get zero self-interst
	- Talk without trying to get something out of them all the time. 
You make money online by being unselfish. No make-online-money course will teach you that. 

Making money online is easy if you master thhe skills needed
