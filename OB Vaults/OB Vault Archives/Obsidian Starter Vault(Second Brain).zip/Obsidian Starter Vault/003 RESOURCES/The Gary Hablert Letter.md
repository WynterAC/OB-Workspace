---
---
**Source:**https://thegaryhalbertletter.com/Boron/BoronLetterCh1.html
**Type:** #litnote 

----
- Take care of the most important things
- **Do important things not the urgent ones**
- Use the eisenhower matrix
- The second attempt at anything will be much easier
	- Show up the next day. Its a lot easier 
- Exercise that feels fun not that looks like work
- Wake up at same time
	- Doesn't matter morning or night person. Successful people stay either late or wake early; so that they can work without interruptions and distractions. 

***DO THINGS THAT ARE IMPORTANT, NOT THINGS THAT ARE URGENT***