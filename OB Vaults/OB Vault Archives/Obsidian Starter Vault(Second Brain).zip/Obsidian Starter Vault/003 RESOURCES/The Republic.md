---
title: The Republic
author: Plato,
category: Philosophy
publisher: John Wiley & Sons
publish_date: 2012
total_page: 389
cover_url: "https://books.google.com/books/content?id=hiryDEKhBvEC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 857083139
isbn13: 9780857083135
---
**Title:** The Republic
**Author:** Plato,
**Type:** #litnote #book #todevelop 

---