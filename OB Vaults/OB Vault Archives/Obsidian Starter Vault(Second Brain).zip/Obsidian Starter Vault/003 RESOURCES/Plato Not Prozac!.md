---
title: Plato, Not Prozac!
author: Lou Marinoff, PhD
category: Philosophy
publisher: Harper Collins
publish_date: 2012
total_page: 320
cover_url: "https://books.google.com/books/content?id=wvBwyB9bjsYC&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 62227017
isbn13: 9780062227010
---
**Title:** Plato, Not Prozac!
**Author:** Lou Marinoff, PhD
**Type:** #litnote #book #todevelop 

---