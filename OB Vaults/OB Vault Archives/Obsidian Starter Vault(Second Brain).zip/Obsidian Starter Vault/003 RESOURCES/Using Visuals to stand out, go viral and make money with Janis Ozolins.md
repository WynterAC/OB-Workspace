---
---
**Creator:** Hyperfury
**Source:** https://www.youtube.com/watch?v=1tzUXU621qU&t=9s
**Type:** #litnote 

---

- Your audience burns calories when they see your content.
- By using visuals your audience burns less calories
- If you have low credibility, people will just scroll pass you if you don't make your audience to burn energy. 
- Make them spend less energy and you will drive engagement
- Finding purpose
	- have no clear purpose but I am clear on what i don't want to do. No boss, work for myself, freedom, laptop lifestyle
- Instead of talking about advice and value, talk about struggles. Talk about the creative struggles. Emotions that resonates with people. 
- Feelings and emotions based things get more viral.
- There's tremendous power in talking to people who are doing the same thing as you do. Don't ask someone random. connect with like-minded people who are ahead of you.
- Most connections grow on twitter.
- Posting and showing up daily is the biggest secret.
- When someone sees your face, he should trust you that you are going to give you something good. Don't spam.
- Core concept is being extremely fast at conveying ideas.
- Making course
	- Make one when your audience asks from you.
	- No unnecessary BS. To the point. Only signal no noise.
	- Raw and basic
- Growing audience on twitter?
	- Have an audience
	- Good things will happen to you if you just engage your audience
- How to start?
	- Its not about design. Its a new language to communicate the idea. Communicating ideas in a noble and different way and interesting way.
	- Be fast and quick about creating when you have low credibility. Ititerate. 
