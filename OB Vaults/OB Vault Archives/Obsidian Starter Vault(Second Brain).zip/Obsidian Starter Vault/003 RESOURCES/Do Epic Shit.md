---
title: Do Epic Shit
author: ANKUR. WARIKOO
category: Self-help
publisher: 
publish_date: 2021
total_page: 312
cover_url: "https://images-na.ssl-images-amazon.com/images/I/41+grDTP2FL._SX316_BO1,204,203,200_.jpg"
status: Completed
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 9391165494
isbn13: 9789391165499
---
**Title:** Do Epic Shit
**Author:** ANKUR. WARIKOO
**Type:** #litnote #book #todevelop 

----
There is nothing new in this book. It is meant to be a reminder. It probably won't change your life but it helps you to be more aware of so that you can make better decisions in life from a state of ignorance rather awareness.

Read this book by opening any page and reflect upon the idea.

# Success and failure 
- Success means different things to different people. You have to give your definition of success and stay true to that. Don't let the world define your rules for success and failure. Success is a relationship you have with yourself.
> - Everyone is running a different race. In face we are not even in a race. We're on our own paths. Some walk. Some run.
- When you planned to do five things in the morning, but you end up doing more, that joy and emotion is true achievement.
- You are what you do, not what you say you'll do. If you commit to something and don't deliver on the promise, it means nothing.
- Luck happens to those who make things happen. Every day and every moment is an opportunitiy for you to let you actions decide your luck. Luck is the result of your hard work.
- You've got just one life. Don't live it being one person. You can be whoever you want and have as many identities as you can. Be an enterpreneur, and also an athelete and also a person who creates content.
- Explore things. Don't just sit at a place. Move out of where you are in life.
- If you can be tough mentally, you can win the world. The inner world is what drives the outer world.
- Passion is not something you find. It's something you grow. Do many things and eventually you will find one that sticks with you. Nurture it, be patient and let it lead your life.
- **Be curious.** We are born with the innate quality to ask questions. But we are forced to stop asking questions by our parents and our teachers. You are curious by nature. It's okay to ask questions that might sound dumb. Don't numb yourself. Nurturing your curiosity is the coolest thing in a world where people are scared of being called dumb.
- Neither success nor failure matters. What matters is what you become through that process.
- Most people are scared of being themselves. But it is one of the coolest ways to get attention.
- There is discomfort in doing th unconventional but there is permanent discomfort in living life as a template.
- Don't try to live life pleasing people. Its the worst way to live life. When you do so and live for external validation, you are giving the control of your life to other people.
- Make money, a lot of money. Not to buy stuffs, but to buy freedom. The biggest privilige that money can buy is freedom.
- If you are in your 20s, use it to discover yourself. Meet as many people as you can. Go to as many places as you can. Do as many jobs as you can. Find out what you are good at and what makes you happy. Then use your 30s to do that.
- **Be a leader.** Don't think everyone wants to led. 99% people want to be led. They want to be told what to do. Led them.


# Habits
- Habits will open doors of opportunities for you. They are what build you. 
- Don't try to wake up early. Sleep early. The secret is to be energized, happy and productive in the morning.
- Be curious. It's what creates opportunities more than hard work ever will.
- The most important skills today are: Humour, storytelling, managaing money, human psychology, and cold emailing.
- You have to have a plan but withot action they are nothing. 
- Stay away from social media. Because the smartest minds are working 24/7 to keep you hooked.
- Follow right set of people on social media and you'll see more opportunities. You become like the people you spend your most time with- both online and offline.
- Habits of Ankur Warikoo
	- Always carries a notebook
	- Documents everything
	- Puts everything on calendar
	- Schedules email to himself, for future
	- Uses technology for everything possible
	- Has a self- whatsapp group
	- Takes a afternoon nap
	- Sets the right environment for every task
	- Creates sensory hooks for what is important: 
		- Our senses help us drive action. Re-wire your environment for things that are your first priority.

# Awareness
- Being aware and mindful of every action you take is a vital skill. Although it's simple, most people don't exercise it. 
- Don't let you feelings of what others will say determine your actions.
- We procrastinate not because of laziness but because of fear. The fear of failure, success. Fear of rejection. We procrastinate because we don't find security in our achievements.
- Instead of chasing people's meaning of success, seek satisfaction in your own journey
- Being calm even in the harshest situations is a superpower. Calmness doesnt' mean you don't lack drive. It means having the power to turn that drive into actions. The calm itself is the fire.
- Here are the best mental models for taking tough decisions in life:
	- Ask yourself: What's the worst thing that can happen?
	- Close your eyes and vividly imagine if happening
	- Then aks, 'Will I be okay- mentally, socially, financially, physically, emotionally?
- Assume that the decisions you take are reversible and you will start to act differently. Because, Yes, mostt decisions are reversible. They are not carved in a stone.
- Be aeware, execute and repeat your decisions.
- Be busy in finding yourself instead of being busy in the rate race and never knowing yourself.
- Don't compare yourself to others. Its the biggest waste of time. 
- Addictions comes from feeling that doing something generates. **We are not addicted to things. We are addicted to the emotions that these things generate.**
- If you are in college, don't just got to educate yourself and get the degree. Use your time and opportunity to find out what you enjoy. **The purpose of college is to find yourself.** Don't just learn one subject. Learn multiple subjects. Join online communities. Freelance, travel solo. Do as many things as you can.
- Ask for help if needed. Because if you don't, the answer is always no. People will only help you if you help them understand how they can.
- Our power to imagine is both our strength and weakness. Use it to your advanatage. 
- Stop complaining. No one has ever reached the solution by complaining. Rather it amplifies the problem.
- No matter what you do, show up everyday. That's what brings results. And be patient. 
- You wil get what you seek. Not what you desire or what you dream. We always know by heart what we seek. But we may show the world that what we seek is something different.

# Enterepreneurship
- Enterpreneurship is hard. 
- Most people lack intent not the capability to do something. When your intent is sharp and clear, you are more likely to be a success.
- Enterprenurship is 90% about understanding and 10% about execution. 90% about emapthy and 10% autocracy. And 100% patience.
- Its not a profession. It's a state of mind. When you work beyond your job description to solve the right problems. If you treat your job like a business, you are an enterpreneur. If you change the status quo for better, you are an enterpreneur.
- As an enterprenur, your success depend on how close you are able to get people to their solutions.
- Somebody out there is already working on the idea you have. Don't overindex the idea. Find what is they don't know.
- Its easy to build a company but hard to build a place where people would love to come to work.
- Don't choose enterpreneurship if your primary goal is to make money, if you hate your job or if you think its cool because everyone else is doing it.


# Money 
- The greatest use of money is to buy freedom and it is the ultimate privilige. Freedom helps you make wiser choices. 
- Mistakes you should avoid with money
	- Don't take loans to buy the real estate
	- Don't invest all of your money in illiquid assets
	- Don't increase your lifestyle with increase in your income
	- Don't invest in the hope of making money fast.

- Here's what you should know about money
	- Always take taxes in consideration
	- Inflation is a real thing
	- Compounding rest on time. Give it time. Don't interrupt it.
	- Invest in places where you can withdraw cash whenever you need.
	- Have excess cash? Wait for the right moment to buy. Wait patiently for the market to drop.
	- In your 20s, live below your means. 
	- Double down on what's working rather than diversification. Diversification will not yield supernormal results. 
	- Take risks early on and don't worry about the short-term ups and downs

# Relationships
- Relationships are the places where we thrive. They are also the places where we are challanged the most. 
- All problems in the world have a root in miscommunication. All relationships thrive on communication. 
- The best way to be taught is to teach others. Break down what yo already know and teach it to others.
- Being kind is powerful. Not all wil reciprocate but its always the right thing to do/
- **Respect>>> Emapthy>>> Sympathy.** Sympathy is a form of pity. Empathy is rising above it and thinking at par with someone who is going thorough and respect is rising beyond what they are going thorough and letting them know that they are doing a beautiful job.
- Don't be around people who are not willing to heal themselves, those who are not okay with their situations and do nothing to change it. Stay away from relationships that suck the energy out of you. This is an undeniable hack for your peace. 
- Most of us do not have love, fulfilment, happiness or fitness in our life, because it requires effort.
- True friends are very rare. Those are the ones who will be tryly happy for you when you succeed.
- How you treat others is  a reflection of how we treat ourselves. The inner world is what drives the outer world.