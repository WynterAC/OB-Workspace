---
---
**Creator: **Jimrohnfan
**Source: ** (https://www.youtube.com/watch?v=CO7ybUb1n7o)
**Type:** #litnote 
**Topics:** [[Goal Setting]] [[How to Set goals JIM ROHN]]

---
Workshop

# What 5 things have you already accomplished that you are proud of?

# What Do You Want in the Next 10 Years?

--- 
- When you accomplished some goals, you need some more to accomplish.
- It's very important when you reach a goal significant, you celebrate. Celebrate a significant accomplishment.
- Punish yourself if you don't
- Celebrate with family
- Where do you go now when you have reached the goal


Sort your goals down to a small list. Rank them on 3 criterai: How excite you are about it. How long will it take? How hard is it easy? Rank from 1-10 and whatever is close to 30. That should be your first priority.

Keep a diary or Journal book to write down your goals

Do a quick reddit search

Plan and create a 6 month roadmap on how you can achieve your goal

After 6 month, re-write a 6 month plan

How far should you go? As far as you can
How many books should you read? As much as you can

---

- On your list of one year goal, which are the 4 most important
- What's got you turned on? 
- What's got you turned off?
- Why are those 4 goals important to you?

> "When the why gets stronger, the how gets easier."


You can do it all when you know why you want it. You can get up anytime. You can build any skill. You can be anyone.

What for?  (Always keep yourself asking these questions)

> Purpose is stronger than the object.

Some of your goals should be personal development.

> The person you become is more important that what you do

# What Kind of Person Must I Become to Achieve all I want


> When you knock on the door of opportunity, you must be attractive person. OR you may not be invited in.

---
The key is not to put everything on your list. The key is to put everything on a paper.

You don't have to accomplish the whole list. If you have 100 goals in the list and accomplish 80, who cares about the rest 20?

Behold & Beware of what you become in pursuit of what you become. 

> The best contribution I can make to the world is to be a better me.
