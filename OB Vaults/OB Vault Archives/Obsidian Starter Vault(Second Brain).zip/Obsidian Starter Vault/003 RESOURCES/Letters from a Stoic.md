---
title: Letters from a Stoic
author: Seneca
category: Philosophy
publisher: Penguin
publish_date: 2015
total_page: 352
cover_url: "https://books.google.com/books/content?id=hotPEAAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 141395850
isbn13: 9780141395852
---
**Title:** Letters from a Stoic
**Author:** Seneca
**Type:** #litnote #book #todevelop 

---