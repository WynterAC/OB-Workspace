---
---
**Creator:** Dr. Sten Ekberg
**Source:** https://youtu.be/XS_kjTAnpP0
**Type:** #litnote 
**Topics:** [[Health]] [[Science]] [[Nutrition]]

---

- Sugar= gulcose+ Fructose
	- gulcose Increases blood sugar, insulin resistance
	- Fructose clogs liver and cause insulin resistance
	- Avoid sugar(anything that tastes sweet)
	- Also polysaccharides(corn, potatoes, breads)-starch- No fructose
- What happens in the first few days?
	- CRAVINGS
	- Withdrawl symptoms
	- balance the metabolic machinery
	- takes 3 days to adapt
	- Regulate insulin levels
	- Sugar and carbs is an addiction just like sugar cocaine, heroin
	- When we get habituated, we get dependence
	- Sugar induces dopamine
- Exercise affects neuroplasticity. It almost affects everything
- Less cravings
- rewire taste buds
- 