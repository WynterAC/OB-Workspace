---
---
**Creator:** Bryan Jenks
**Source:**
**Type:** #litnote #todevelop 
**Topics:**

---

- Before you begin
	- Dont' focus on the shiniest tool or productivity system. Don't focus on what's popular right now or what people are using. You need to focus on what will actually get your work done, produce value and move you closer to your goal. This is what will help you move forward instead of moving in circles. You have to stop falling for the trap of trying every single siny tool out there. Ask yourself if there is any feature that you have been missing lately or does that feature add any significant value. 
- Start building. Take a note. you don't have to be with me right now. If you start now, you might get ahead of me, but you just have to start. Get your notes in the system.
- Begin Here
	- Identify what your goal is? What are you trying to get out of this? Video scripts. Organizing knowledge, writing articles, books 
- What is PKM?
	- It is a system that facilitates you to quickly capture your notes, ideas and tasks and revisit them and analyze them later. You can process them later. 
- What's your organization system? 
	- If you have rigid system, you can use folders. others you can use MOC, Johhny Decimals
- Daily Notes
	- Can help you create a different forms of notes

# Here's the system
- Goals
	- Creative output
	- An external framework for thought
	- Learning(spaced repetition, qnd more)
- Quick Capture
	- GTD
	- Obsidian mobile
- Data Filter with Dataview
- Tags vs links
	- Tags are softlinks. Tags to me are large indicators of status or groupings. I use tags regardless of context
	- Links are hardlinks. They are used with future context. 
	- Tags are like umbrellas and anything can be under it but links are like a finger pointing to a particular note
	- Not use folders to reduce workload and friction and maintain more flexibility
- Reduce friction with Map of Content
- daily notes
- Book Note
	- Take Notes as you read a book. If a book is hard to comprehend, read it by dividing it into chapters
-  Tweets
	- @threadreader app unroll to copy threads
	- Copy pictures and Images as it is
	- Twitframe
- Taking notes from podcasts is a mess
- 
	

