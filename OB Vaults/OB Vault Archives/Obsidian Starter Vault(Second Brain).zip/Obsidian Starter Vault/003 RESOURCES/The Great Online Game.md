---
---
**Source:** https://www.notboring.co/p/the-great-online-game
**Author:** Not boring
**Type:** #litnote 


----
- Not everyone can play this game but if you are reading this you can
- You are already playing the game
- Doesn't matter where you are. 
- Start playing with whatever you have; resources and skills
- You can level up pretty fast
- played by billions of people by being themselves or being someone else
- The downside is limited, but the upside infinite.
- Social media is just one piece of this game,
- The game starts when you realize you are playing a game.
- It's free simple and easy
- How well you play wil determine the rewards you get online and offline
- It unlocks opportunities in different areas of your life

> - Hit the right keys in the right order, and make money

- Four elements of successful game design.
	- *Feedback loops*
		- Get feedbacks improve on them do more of what works adnddo less of what doesn't work
	- *Variable outcomes*
		- Experiment. Play around. Some wthings will work and some wont
	- *Sense of contorl*
		- Give value with no expectation in return. Your result is dependent on your skills and efforts
	- *Connection to the game*
		- The more you level up and evolve, the better opportunitites you start receiving.
- The game rewards community and cooperation over individualism and cooperation. 
- get points for being curious, sharing, and helping with no expectations of reciprocation

> You don't have to bend atoms and be the wealthiest person in the solar system to win. You just have to play well.

- Already playing the game 
- Anyone can play the game and win. It's only a matter of knowing how the game works and creating. 
- Spend time participation online and learning.
- One random meme can send a coin to moon and make people millionaries overnight
- You are not just playing the game, you are designing it yoruself
- Have fun. Don't be too serious. It has exponential upside with compounding returns.