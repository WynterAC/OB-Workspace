---
---
**Source:** https://shreyabadonia.medium.com/i-deleted-my-4-year-old-youtube-channel-and-podcast-5f346c7697f5
**Type:** #litnote 

----
- There are so many opportunities. You can go after anyone of them.
- ***Without prioritization, there's no perfection.***
- You need to fail. Make your failure muscle strong. 
- Not expert in anything. No single priority in any one plaform
- Multiple platforms doing multiple things instead of focusing on one thing.
- As a creator, make your personal life personal. 
- Letting go of my channel, which I knew would have made me $20K-$40K in a couple of years, gives me the mental energy to get those results in a much shorter period.
-  instead of creating videos and podcasts for the algorithm, I want to do it for people who are genuinely interested in them and enjoy my ideas. And I want you to be a part of this massive change that’s coming and not a platform or the stupid algorithm.