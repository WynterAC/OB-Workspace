---
---
**Title:** Millennials Already Know How to Get Richer
**Source:** https://medium.com/swlh/millennials-already-know-how-to-get-richer-166b0f7f2418
**Author:** Tim Denning
**Type:** #litnote 


----

- Getting rich isn’t about making bucketloads of money. It’s about living differently and changing the rules of society.
- Stop falling for the traps that society has made for you.
- If you don't want to be like someone else, don't follow what they say or what they did and what they tell. That's it