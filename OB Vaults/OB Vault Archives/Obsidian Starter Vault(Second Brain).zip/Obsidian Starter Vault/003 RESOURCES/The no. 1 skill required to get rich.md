---
---
**Creator:** Naval ravikant
**Source:** https://youtu.be/4AXTmL4TC6c
**Type:** #litnote 
**Topics:** 

---


- Fuck work ethic
- not pure hardwork
- what you do, whom  you when you do and whom you do with 
- Know your direction, don't grind a lot
- **The most important skill required to be is a perpertual learning machine**
	- You can learn anything 
- If you can't do something, redo redo and redo until you can do it without any effort
- It's like hittint the gym. You will get your mental muscles tired
- You should be reading and reading and reading a lot. But a lot of junk
- **Reading wrong things in a wrong order is the worst **
- You have to be good with the fundametnals and stick to the basics and science
- Read only what's the ultimate truth. Read things that people can't fundamentally disagree with
- **Read maths, science, microeconomics and all the basic stuffs.**
- **Read originals, read classics. Start with philosophers.**
- Don't read the interpretations of the modern people who want to feed you and sell you stuffs

**Perpetual learning machine**
- Perpetual learning machine= never out of ideas
- Want to be rich? You can't work the traditional way
- You have to come up with a new skill in 9 months that will be absolute in the next 4 years. But the time in between is when you can take advantage of to get rich by being an expert in the new industry

- Don't go into all things. STick to 1-2 things that you are really obsessed with. Master these things and you will be unstoppable. 
- Be able to convice people using simple english rather than knowing 10 different languagae and vocabulary to sound smart
- 