---
title: On Bullshit
author: Harry G. Frankfurt
category: Philosophy
publisher: 
publish_date: 2005
total_page: 67
cover_url: "https://books.google.com/books/content?id=WBfnlgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 691122946
isbn13: 9780691122946
---
**Title:** On Bullshit
**Author:** Harry G. Frankfurt
**Type:** #litnote #book #todevelop 

---