---
---
**Source:** https://medium.com/mind-cafe/to-become-extremely-productive-practice-the-elon-musk-effect-7b86d94cba40
**Type:** #litnote 

----
- **[[Schedule your time]]**
	- “The most important thing about art is to work. Nothing else matters except sitting down every day and trying.”
	- Motivation requires motive
- Create time blocks with extreme care. 
- Block hours by what you need to do
- Ambitious targets- Try to do things in shorter time that would take more than you think
	- You will never be successful by staying in your comfort zone
- 
-  You can be extraordinary. You’re capable of accomplishing a lot more than you think. You can massively improve your work ethic, productivity, and many other things that are vital to creating the future you desire.
    
-   You just need to be willing to work for it.