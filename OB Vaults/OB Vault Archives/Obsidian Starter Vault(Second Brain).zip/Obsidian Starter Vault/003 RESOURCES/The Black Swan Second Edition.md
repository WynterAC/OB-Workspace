---
title: The Black Swan Second Edition
author: Nassim Nicholas Taleb
category: Business & Economics
publisher: Random House Trade Paperbacks
publish_date: 2010
total_page: 480
cover_url: "https://books.google.com/books/content?id=h2WMDQAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 081297381X
isbn13: 9780812973815
---
**Title:** The Black Swan: Second Edition
**Author:** Nassim Nicholas Taleb
**Type:** #litnote #book #todevelop 

---