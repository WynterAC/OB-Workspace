---
---
**Creator:**
**Source:**  https://www.youtube.com/watch?v=dfijk5dkito
**Type:** #litnote 
**Topics:** [[Trading]]

---
- Never enter a trade without a stop loss and the target price where you will take profits
- ATR means the amount of fluctuations that can happen at a moment.
- Use Average true range by Hpoter on Trading view
- Use SMA for more information
- Low ATR means low volatility and High ATR means high volatility
- **Risk less money in high ATR stocks**
- The lowest or highest point in ATR, **peaks means that theres something going to happen in that stock**
