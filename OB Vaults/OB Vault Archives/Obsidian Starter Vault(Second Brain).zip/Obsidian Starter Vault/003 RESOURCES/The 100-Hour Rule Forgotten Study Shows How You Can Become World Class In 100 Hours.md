---
---
**Source:** https://medium.com/accelerated-intelligence/the-100-hour-rule-forgotten-study-shows-how-you-can-become-world-class-in-100-hours-ae2f94cc2fb0
**Type:** #litnote 

----
- Purposeful practice
- Be best at a skill in just 100 sessions
- Approximately 100hours
- Challenges the 10,000 hours rule
- Time required to become great at anything varies
- More competition=More time required
- **Skill Selection**, important part of the equation
- Deliberate practice+Skill Selection+ 100 hours= World-class skill
- Select skills that are rare and valuable.
- Tim Ferris Micro skills selection process
- Break down skills into rare and valuable micro skills.
- Allows you to get the benefits of greatness within dozens of hours rather than 100s
- When you become good at one thing, you will have fun.
- Benefits of learning are exponential
- The more we learn, the more benefits
	- Better reputation
	- Better opportunities
	- Charge premium
	- Better decisions
- Stack more rare and valuable skills on top on one another. Combine them, mix them and stir them up.
- 
# Making $1000/hour with 100 hours rule
- Break skills into sub-skills/ Microskills
- Identify $1000/hour skills with little to no competition
- Find valuable skill by asking how much people will be willing to pay for your skills
- Learn $1ooo/hour skill with month-long learning challange.

*turning an intention from this article into 100 hours of deliberate practice is hard**. **Most people aren’t going to do it because the status quo of not doing anything is way easier.**