---
---
**Source:** https://medium.com/mind-cafe/youre-trying-to-do-too-much-65da31efbc40
**Author:** Scott H. Young
**Type:** #litnote

----
- A typical student has different interests
- He wants to do all these things but his enthusiasm is rarely matched with execution. 
- Trying to do several things at once is a recipe for accomplishing none of them.
- If you want to progress, you have to set clear priorites
- take one project at a time
- don't juggle them all at once
- Commit to single thing even just for a few months.
- The person who commits to three-month projects may not achieve mastery. Still, they will get further than the person who merely thinks about doing those projects.
- Beign good and thinking about being good is different thing.
- Its more fun to think about being good at something than to actually do the work to get good.
- Pick a project and see it through
- Give ideas time to incubate
- A mulit-year plan is much like to be abandoned than the 3 month plan project
- First try for a month and then go to 3 months
- Set commitment for short burst that you will follow through