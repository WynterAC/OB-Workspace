---
---
**Source:** https://www.bbc.com/worklife/article/20170612-why-you-should-manage-your-energy-not-your-time
**Author:**
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]] [[Energy Management not Time Management]]

----
- Most workers have stress chronic pains in the body.
- They work more when the key is to work less.
- We think there are not enough hours in the day to do tasks. 
- Tasks that could be done in minutes stretch to hours. while all others tasks mount up
#### Time management trap
The easy to fall into trap- Working for 8 hours straight to increase our output to impress others. 
- But it contradicts the science of performanec
- One can't maintain focus and energy for such a long time
- Getting rest and recovering not only helps performance but also lowers stress level and increase the quality of work. 

Many people turn back to the industrial indicator of productivity. 

As a worker, epecially a knowledge worker you should focus on [[Deep Work]], the concept put forward by cal newport. 

[[Deep Work]] is the uninterrupted time that you give to a task. If you can protect your [[Deep Work]] time, you can accomplish what others can't do in a week in a day.

You need down time
You need both focus and unfocused circuits in the brain. 
The key to being productive might be found in using that time effectively through embracing the slumps in our day 