---
---
**Creator:** Brian Dean
**Price:** $5000
**Link:** https://seothatworks.com
**Type:** #litnote 
**Topics:** [[SEO]] [[Courses]]

---
This sytem is the key to success with SEO. Just follow the steps and you're set. 

- **Objectives**
	- Get higher ranking with a system that works
	- Drive targeted traffic to your site
	- Scale up the entire process(outsource and get big)
- It's not easy to rank in google today. Unlike 10 years ago, when you could just post a high quality content and could rank on #1, just doing on-page SEO is not enough. 
- Don't need followers or authority, just follow the system.
- **Linkreators**
	- These are people who have the power to link to you. If you create content specially targeted at them, its pretty easy to get links.
	- Doesn't mean you should avoid your audience.
- **Finding Linkreators**
	- **Google search**
		- It's the best. Search for related term not same term. You want to avoid competition.
		- Go through the search results and add quality sites to your list. Repeat auntil you have 5-10 linkreators.
	- **In "best of" blog posts**
		- use search strings ingoogle to uncover the best list. 
		- Easy to follow and go through
		- Add solid-looking websites to your list
	- **See who links to the sites you just found**
		- Find the sites linking to websites found in step #1 and #2. if site looks good, add it to your list.
- **Find a proven topic**
	- 




- **MENTIONED WEBSITES**
	- Alltop.com
	- Ahrefs.com
	- Moz free trial
	- openlinkprofiler