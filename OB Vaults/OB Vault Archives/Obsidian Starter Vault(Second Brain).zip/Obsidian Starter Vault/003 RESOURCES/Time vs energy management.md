---
---
**Source:** https://medium.com/the-road-to-wellness/time-vs-energy-management-4895ea33ee43
**Type:** #litnote 

----
- Pay attention to what consumes your attention
- Time is finite but energy is renewable and in your contoro
- Energy is being mindful of distractions when you do something.
Create nergy audit to find what gives you energy and what drains it.

Create a graph from waking up to sleep. Choose activities that serve you the best. 

Know your peak time and valley time and reflect on your dips. Look for pattern and see if you can do something to take care of yourself during the lows so that you don't have to stay there for a long time.