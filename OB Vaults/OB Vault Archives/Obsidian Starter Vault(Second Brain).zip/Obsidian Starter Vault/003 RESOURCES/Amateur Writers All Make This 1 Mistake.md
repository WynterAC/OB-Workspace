---
---
**Source:** https://nicolascole77.medium.com/amateur-writers-all-make-this-1-mistake-418ab1fd980a
**Type:** #litnote 

----
- You are not the main character of your story. Its the reader
- Everything should be about him. 
- He is the spotlight
- He should feel luck to read such stuff
- Speak to the needs and wants of the reader
- Be selfless
- Balance between between what you wan to write about and what your audience wants to read
- Nobody cares about you. 
- Irrelevant
- You can tell personal stories and meaningful details from your own experiences while being a part of it. 
- Connect your writing with the writer. Make it relevant to him.
