---
---
**Creator:**  Above Inspiration
**Source:** https://www.youtube.com/watch?v=HhBNGdS5Kqk
**Type:** #litnote 
**Topics:** [[Time Management]] [[Time is Precious]] [[Protect your time]]

---
- Life is brief. 
- Passes quickly 
- It seems as if yesterday I was there, but time has passed so fast. Theres no moment right here
- Make priorities
- Whatever you want to do, do it now.
- Write, read, spend time, do it now whatever you want to do. 
- Everytime clock ticks, it is saying do it now.
- You are running out of time. Don't behold
- Don't hold on to more than two opinions ever.
- You get the same time every day. You can't balance it. You can't save it.
- You can't redeem you time. The days are evil. They are move evil.
- The time is now to do whatever you always wished to doo.
- The quality of your time is more important that the length.
- Invest the little time you have so that you can be better.

