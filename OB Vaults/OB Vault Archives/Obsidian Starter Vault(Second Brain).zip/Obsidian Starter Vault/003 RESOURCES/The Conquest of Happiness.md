---
title: The Conquest of Happiness
author: Bertrand Russell
category: Literary Collections
publisher: Routledge
publish_date: 2015
total_page: 200
cover_url: "https://books.google.com/books/content?id=6KPbCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 113675461X
isbn13: 9781136754616
---
**Title:** The Conquest of Happiness
**Author:** Bertrand Russell
**Type:** #litnote #book #todevelop 

---