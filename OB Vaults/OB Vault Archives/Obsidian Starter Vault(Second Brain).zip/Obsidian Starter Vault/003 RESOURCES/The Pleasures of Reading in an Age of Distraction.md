---
title: The Pleasures of Reading in an Age of Distraction
author: Alan Jacobs
category: Self-Help
publisher: Oxford University Press
publish_date: 2011
total_page: 176
cover_url: "https://books.google.com/books/content?id=i_kAAY-aV3sC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 019983167X
isbn13: 9780199831678
---
**Title:** The Pleasures of Reading in an Age of Distraction
**Author:** Alan Jacobs
**Type:** #litnote #book #todevelop 

---