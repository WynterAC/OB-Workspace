---
---
**Source:** https://medium.com/content-cafe/how-i-consistently-write-articles-in-under-30-minutes-52cb335a8c24
**Author:**
**Type:** #litnote #todevelop 
**Topics:** [[Writing]] [[Writing Tips]] 

----
- Real time edits are distracting and take a lot of time from you.
- You can 't run both creative and rational sides of the brain at the same time.
- The constant switching leaves with too much dowtime
- **What is writing**
	- Translating thoughts on your brain into text that can be read and understood. It's a thought transfer process
- Physical typing is not the most efficient way to write.
- **Talk-to-text instead**
- Makes small errors but can be removed easily with a small effort
-  Speech-to-text is just another step in the direction of writing efficiency.
- 