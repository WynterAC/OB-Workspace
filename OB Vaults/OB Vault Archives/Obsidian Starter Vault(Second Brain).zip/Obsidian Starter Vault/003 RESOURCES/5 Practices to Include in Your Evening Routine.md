---
---
**Title:** [5 Practices to Include in Your Evening Routine | by Ashley Richmond | Better Advice | Medium]
**Source:** (https://medium.com/better-advice/5-practices-to-include-in-your-evening-routine-8c9e240c526c)
**Author:** Ashley Richmond
**Type:** #litnote 
**Topics:** [[Habits]] [[Rituals]]

----

- Morning routines are everywhere but very few people talk about evening routines. They are as important as morning routines.
- Evening routines have so much power. Prepare you menally and physically for sleep.

- Put out clothes and pack your bag for next day. Reduces decision making in the morning. You are prepared for the day
- Prepare & put your phone away: at least 45 minutes before your bed, put your phone away by setting up alarm for tomorrow.
- Journa: Revuew your day. What you did and what you accomplished, What you failed to accomplish?
- Do some stretching or Yoga: It helps you to wind down. helps you to connect your body with mind
- Set up your sleep place.

[[Why You Need a Evening Routine]]