---
---
**Source:** https://medium.com/candid-conversations/3-realistic-ways-to-do-more-quality-work-using-less-time-and-effort-861b9b2f6a10
**Author:** Darshak rana
**Type:**
 #litnote 
**Topics:** [[Time Management]] [[Productivity]]

----
- Too much information 
- **Plan for a week instead of a day**
	- Find out what and how something works better for you. 
	- It a task is bigger, chunk it down. 
	- Helps to accomodate unproductive days
- **Commit to only 3 tasks per day**
	- flex your routine.
	- Don't be busy, be productive
	- do things that matters 
	- Don't try to be a do it all person, manage what you can do and what you can delegate and give others to do .
- **Commit to  one task at a time**
	- Don't even think you can multi-task especially when you are doing intense attention demanding work
	- Put all the distractions away and focus only on the task at hand for a specific time period with a lot of focus and concentration.
	- 