---
---
**Source:** https://chef-boyardeji.medium.com/my-brutally-honest-opinion-about-writing-on-medium-in-2022-452c7ac63084
**Type:** #litnote 
**Topics:** [[Writing]]

----
- Writers come and go and come back and go. 
- [ ] **Blog on medium no matter what**
	- Has zero downside
- You are late in 2022. You don't get the early movers advantage 
- Writing 4-5 articles every week won't gurantee you money. 
- You must build an e-mail list. 
- Switch your strategy
- Use medium as one of the ways to monetize your writing. and use it to build other aspects of your writing business.
- Use medium as a place to learn how to become a better writer and use traffic from the site to set yourself for long-term success.
- **E-mail marketing will never go out of style**
	- Communicate with your list regulray. Send them links to your articles once a week .
- **Go for SEO**
	- Write seo optimized blog posts on your website. and publish it in medium too.
	- [ ] Add canoncial link 

> ***Keep Medium as a central piece, but broaden your horizons too.***