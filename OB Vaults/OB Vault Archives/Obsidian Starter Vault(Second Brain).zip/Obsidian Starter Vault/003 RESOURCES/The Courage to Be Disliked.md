---
title: The Courage to Be Disliked
author: Ichiro Kishimi, Fumitake Koga
category: Self-Help
publisher: Atria Books
publish_date: 2018
total_page: 288
cover_url: "https://books.google.com/books/content?id=AWfuyQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1501197274
isbn13: 9781501197277
---
**Title:** The Courage to Be Disliked
**Author:** "Ichiro Kishimi", "Fumitake Koga"
**Type:** #litnote #book #todevelop 

---