---

---
**Creator:** David Perell
**Source:** https://youtu.be/G-lR2vpyPz8
**Type:** #litnote 
**Topics:** [[Reading]] [[Books]]

---
- Don't read to tell your friends that you read books
- This is against learning. Ineffective and stressful
- This feeds on the theory of feeding your insecurities of being called stupid
- More is not always better. Faster is not always better
- True learning requires:
	- Contemplation
	- Execution
	- Reflection
- Water in a cup method. You can't fill your brain with information like 
- Read carefully and do deepest 
- How to learn more
	- Write what you read in your own language
	- Practice spaced repitition.
- Slow down, your brain needs time to transfer information form short term memory to long term memory.