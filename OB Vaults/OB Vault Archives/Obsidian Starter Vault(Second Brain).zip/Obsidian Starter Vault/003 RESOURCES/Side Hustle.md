---
---
Side hustle is an extra gig that you do besides your primary source of income or job. Side hustle supplements your primary source of income. 

Side hustle and hobbies are not the something. Hobbies might not have a financial standpoint while side hustles feed your bank account. You can even turn your hobby into side hustle.

