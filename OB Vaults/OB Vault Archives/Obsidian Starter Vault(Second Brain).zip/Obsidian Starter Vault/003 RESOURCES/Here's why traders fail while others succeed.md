---
---

**Creator:** Trading Addict
**Source:** https://www.youtube.com/watch?v=yudED57WWdw
**Type:** #litnote #todevelop 
**Topics:** [[Trading]]

---

| Traders                                                             | Gamblers                                                                     |
| ------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| Focus on long-term profitability, growth and consistency            | Want to make quick money without any work                                    |
| A Valid trading plan and keeps optimizing on the way                | No strategy and trades based on the noise                                    |
| Obey risk management principles. No over-leverage                   | Blow their account with over-leverage                                        |
| Trades with high probability setup only when entry criteria are met | Random positions, overtrades and irrational decisions                        |
| Accept loss and don't get personal                                  | Never want to take loss and gets emotional. Often involve in revenge trading |
| Treat trading as a business                                         | Treat trading as a casino                                                    |


Have a strict plan. Practice. Backtest. Do your work. Be disciplined about your trades. Separate yourself from the crowd.



You don't need to trade every time. The best strategy is to do nothing sometimes. Trade and lose with a high-quality setup instead of winning an low-quality setup.
- **Take Right trades** 



