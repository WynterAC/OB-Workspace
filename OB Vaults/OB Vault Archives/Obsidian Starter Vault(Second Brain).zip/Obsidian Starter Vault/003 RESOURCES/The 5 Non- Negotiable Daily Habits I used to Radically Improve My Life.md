---
---
**Source:** https://medium.com/better-advice/the-5-non-negotiable-daily-habits-i-used-to-radically-improve-my-life-f96aef3f5a56
**Author:** 
**Type:** #litnote 

----
- Nobody is born successful. They become by making habits. They do things unsuccessful people don't like to do.
- Writing:
	- Write in order to think not the other way around
	- Put pen to Paper
	- Think better when forced to articulate a position or an argument
	- Writing for mind= Gym for body 
- Reading: 
	- Highest leverage activity
	- You get the lifetime wisdom of another person for the cost of lunch
	- It seperate you from the rest of the beings
- Exercise:
	- Your body and mind have a symbiotic relationship
- Mindfulness:
	- It connects you to the present moment
- Connections
	- 4 types of connection: people, purpose, passion and nature
	- Be more intentional about how and who you spend your time with
	- Lack of any of these= chroinc stress and burnout

---
Make life better. Stand out from the crowd. Invest in your habits. Invest in yourself.