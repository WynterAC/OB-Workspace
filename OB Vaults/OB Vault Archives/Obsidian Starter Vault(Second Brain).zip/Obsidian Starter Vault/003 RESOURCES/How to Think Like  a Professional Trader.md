---
---
**Creator: ** Mark Douglas
**Source: ** Mark douglas- How to think like a professional trader (1-4)  https://www.youtube.com/channel/UCqIV5j7va0x7JHS-VJsNNcw
**Type:** #litnote 
**Topics:** [[💹Stock Market]] [[Trading]]

---

#### Part-1

# Why should you think like a professsional trader?
A professional trader makes money consistently. His sole income is derived from trading. Other people give you money to make money for them. A professional trader has learned how to make money consistently.
When we are in a winning trade, we have to be consistently making decisions on where we're going to take profits.
Consistent traders lose their money all the time.
We all conform to the same problems and situations. 

Trading isn't easy just because it's just a mouse click away. There are some very sophiscated psychological skills that you need to master before you trade.
All of these skills are founded in learning how to trade without fear. 

> Everything you do wrong as a trader is a result of fear and what you are afraid of and the effects fear has on the perception of the market information.
> You have to learn more about yourself than learning about markets.
> You have to evolve beyond the typical mindset to fill the gap between your potential and bottomline
---
#### Part-2
Trading without fear is the primary skill you need to develop if you want to consistently make money.          

---

4 videos available on youtube. Read his book.