---
---

**Source:** https://perell.com/essay/why-peter-thiel-searches-for-reality-bending-secrets/
**Type:** #litnote 


----
- Everybody has a map of how the world works, 
- Incomplete by dogma or because its incomplete
- Obsession with secrets
- Think of people who still don't understand bitcoin. 
- What is a secret? ***The important truth that very few people agree with?***
- The world has important and undiscovered truths.
- The downfall of Nokia because they didn't took the leap
- Its easy to laugh at Nokia, yet their decision aligned  it is stupidity. 
- Do interrogate the dogmas of the day.with the common knowledge at that time. 
- Disagreeing with something because majority believes
- Surround yourself with independent thinker
- Online education is another secret. 
- The secret is that there are still many secrets left to discover