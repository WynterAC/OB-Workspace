---
---
**Source:** https://medium.com/publishous/how-you-can-make-the-most-of-summary-services-like-blinkist-eaaa52e77df3
**Type:** #litnote 
**Topics:** [[Reading]] [[Books]]

----
- Summary services can give you tempting promise- you will gain more knowledge in less time.
- Brain not recording device
- You don't acquire everything you read
- No cross-checking
- You lack complexity and context.
- Summaries compromise on depth and meaninng
- Fluff invites you to deeper reflections and questions
- **Adler's four levels of reading**
	- Level 1:
		- Reading and understanding means mastery
	- Level 2: 
		- Quick chat with the author to determine whether you should read or not
	- Level 3:
		- Reading but its like writing in the sand
		- Passive reading is not the same as mastering the ideas behind it
	- Level 4:
		-  Relating different books on same topic until you master it fully.
		- Compare, argue and explore questions 
		- Construct analysis of the subject which is not available in any of books
		- Best way to read.
**Not all books are created equal. Most are not worth your time but some can change our life**

so quickly browse through summaires to find if the book is worth a read or not.

