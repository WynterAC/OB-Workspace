---
---
**Source:** https://medium.com/swlh/a-simple-way-to-write-an-article-that-hits-googles-front-page-96a85b35afab
**Author:**
**Type:** #litnote 
**Topics:** [[SEO]] 

----

- Making money = Being infront of as many readers a s possible
- Google can help you
- Create searchable and insightful content is challenging.
- **Please the search engines**
	- Keyword research to know the people interested in your topic.
		- Check your topic's monthly volume and competition. 
		- Aim for middle to low competition and get at least 100 global monthly searches.
	- On page optimization
- **Spy on your competitors**
	- Know who is already there. You have to create a longer and better content that theirs
- **Add Sementically related keywords**
- **Optimize H1**
	- Google's ranking signals{for search engine}
- Optimized Meta-title and description
	- For users to catch their atention
- **Optimized introduction to hook readers and keep them reading**
- **Optimized H2, H3**
	- For giving structure to your content and improve reading experience 

> “You will significantly reduce your working hours and increase your output if you start writing for your readers.” 