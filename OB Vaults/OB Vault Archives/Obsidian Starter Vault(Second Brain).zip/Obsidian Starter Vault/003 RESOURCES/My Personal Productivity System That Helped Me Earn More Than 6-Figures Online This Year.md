---
---
**Source:** https://medium.com/curious/my-personal-productivity-system-that-helped-me-earn-more-than-6-figures-online-this-year-173fea21bc8
**Author:** Tim Denning
**Type:** #litnote  
**Topics:** [[Productivity]] 

----
- You are lost if you don't have a system you work with
- Productivity system
	- **Say 'no' like you are married to each other**. Don't spray your focus
	- Exercise, plants, sun and naps. Do whatever you can to increase your energy. **You perform only as good as you are energized**
	- **Get a second brain**. So that you put off the mental pressure of remembering. **Use your brain to think only not to store information.**
	- Brainstorm. **Write 10 ideas every single day.** Fire up your creativity. **The future is reserved for creative workers not productive workers.** Understand this.
	- Take rest and come back with more energy and enthusiasm
	- Use a productivity system to design your life.
