---
---
**Source:**  https://sites.google.com/site/steveyegge2/you-should-write-blogs
**Author:** Google sites
**Type:** #litnote 
**Topics:** [[Content Creation]] [[Writing Tips]]

----
- Write from your soul not what you were taught in school.
- Have empathy for your audience. Understand it at a fundemetal leval. It makes you  a better person
- You can delete your blog if you change your mind. No one will remember it. Everyone will forget about it, almost as if you'd un-written it
- Your opinions spice of your wriging
- People respect your opinion even if they disaggree with you

# Nobody will read  my  blog
- People will read when the time is right
- more relevent piece= more people reading
- Getting idea infront of people is not easy
- Nobody reads your blog until its good
- Write honestly and people will eventually find there way there
- No self promotion needed. 
- Write for fun
- Don't worry about people. Just write it


# Blogging is narcissistic
- Be down-to-earth
- Don't have illusion of grandeur even if you become famous
- You are still struggling with really hard problems
