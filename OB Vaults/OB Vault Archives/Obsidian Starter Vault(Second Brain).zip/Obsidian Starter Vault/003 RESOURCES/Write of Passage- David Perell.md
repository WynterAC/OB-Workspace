---
---
**Creator:** David Perell
**Price:** $7000
**Link:** https://writeofpassage.school/
**Type:** #litnote  [[Courses]]
**Topics:** [[Writing]] [[Content Creation]] 

---

# Welcome
- **Welcome letter**
	- group of enthusiastic writers, five-week sprint, writing process and creative output
	- By end, a system for writing consistently, published articles and distribution.
	- Have a sense of what it means to be the citizen of the Internet. 
	- Bi-directional learning.
	- Be challanged but never confused. 
- **Welcome Video**
	- Pushing yourself to be a better writer. This is gonna be difficult. Designed to be difficult, infact.
	- Make friends
	- Have a habit of shipping.(you don't have to caught up in perfection but don't publish sloppy writing either)
	- Strive to produce and publish excellent work
	- More than writing course, being a citizen of the internet
	- Writing online is like having an agent working for you 24/7
- **Assignments**
- **Digital Postcard Setup guide**
	- Choosing digital postcar
		- Convertkit vs substack the best
		- Use converkit if you want to seperate emails and your online home
- **Getting Started:**
	- Course overview
		- 