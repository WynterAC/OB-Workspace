---
title: Mind Full to Mindful
author: Om Swami
category: Sprituality, Mindfulness
publisher: Black Lotus
publish_date: 2018
total_page: 192
cover_url: "https://books.google.com/books/content?id=LJNAvwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 9352777638
isbn13: 9789352777631
---
**Title:** Mind Full to Mindful
**Author:** Om Swami
**Type:** #litnote #book #todevelop 

---