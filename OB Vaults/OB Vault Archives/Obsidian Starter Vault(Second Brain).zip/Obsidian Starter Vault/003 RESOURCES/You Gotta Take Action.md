---
---
**Creator: **
**Source: ** (https://www.youtube.com/watch?v=oBPKgcfp0y0)
**Type:** #litnote 

---

- You gotta keep going and take action.
- Do what you can right now
- Don't neglect something
- Don't let neglect destroy your life, your future and career
- Do something
- Once you start doing something, life will give you opportunities to do something better
- You start first with the smallest disciplines
- All disciplines affect each other
- Everything affects everything else
- Everything matters although something matter more than the other
- Take care of your diciplines when they are small
- Don't disregard or neglect the small. They are what builds your foundation
