---
title: Sapiens
author: Yuval Noah Harari
category: Non-fiction, History
publisher: 
publish_date: 2017
total_page: 491
cover_url: "https://books.google.com/books/content?id=FILmrQEACAAJ&printsec=frontcover&img=1&zoom=5"
status: Unfinished
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 9522794708
isbn13: 9789522794703
---
**Title:** Sapiens
**Author:** Yuval Noah Harari
**Type:** #litnote #book #todevelop 

---