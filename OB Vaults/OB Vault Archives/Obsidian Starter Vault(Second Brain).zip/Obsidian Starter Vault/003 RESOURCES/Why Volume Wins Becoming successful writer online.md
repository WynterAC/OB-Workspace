---
---
**Creator:** Nicolas Cole
**Source:** https://youtu.be/0ApZWdXv8Ys
**Type:** #litnote 
**Topics:** [[Writing]] [[Writing Tips]]

---
- Sit down to write, think that's what the audience want, It doesn't perfrom well
- You spend a short time to create and put it out there and it catches fire
- **You never know what's gonna work and what's not gonna work with the algorithm
- You only know that the more you produce and ship, the more likely you are able to expect a exponential outcome.
- Think of your conten piece as a library. The more you write, the bigger your library and the bigger your library, the more people you attract
- 90% of your library will not perform well.
- Writing is a not a linear game, it is a exponential game.
- 
