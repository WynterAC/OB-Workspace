---
---
# Social Media Doesn’t Change Opinions — It Only Amplifies Them

> “That was a really great comment. I’m going to change my mind about this. Thank you for the wonderful conversation!”

Said fucking nobody on social media ever.