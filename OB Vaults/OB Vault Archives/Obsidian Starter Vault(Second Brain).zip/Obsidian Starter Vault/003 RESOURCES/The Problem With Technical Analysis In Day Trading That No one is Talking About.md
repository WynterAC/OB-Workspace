---
---
**Creator:** [[The secret Mindset]]
**Source:** Youtube
**Type:** #litnote #todevelop 

---

- Its easy to find support and resistance and find trades by looking at the past chart. But its hardest when the next candle hasn't formed to do these
- There is no Perfection in trading
	- Price rarely turns at the perfect line
- The price action have no mind of its own. Its a collective action of supply and demand
- Trade small and give proper sizing so that you can give flexibility for trades to breathe.
- **Market Reversal doesn't occur immediately(rare case)**
	- It always takes time for all the buyers or all the sellers to be wiped out
	- The reversal doesn't come from a one signal or one candle
- Relying solely on indicators without knowing how to read the price action is a major mistake
	- Don't clutter your screen too
	- Indicators provide purely objective analysis
- Don't use wrong indicators in wrong context
- **Listen to what the price tells you?**
	- Who is in control?
	- Who is pushing the market?
	- Is the momentum gaining or losing?
	- How do trends relate to each other?
- **Context and confluence is what matters in technical analysis**
- Predictive vs reactive, what are you?
- 

Tecnhincal analysis is subjective. Its not a science. It is open to subjective analysis


> If you ask 3 technicians what the price is revealing, you will get 4 different replies 
