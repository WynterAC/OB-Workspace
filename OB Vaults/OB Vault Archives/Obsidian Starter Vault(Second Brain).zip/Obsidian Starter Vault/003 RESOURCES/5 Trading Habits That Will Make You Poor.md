---
---
Creator: Rayner Tao
Source: 
Type: #litnote 
Topics: [[💹Stock Market]] [[Trading]] [[Mistakes Traders Make]]

---


# Don't Chase The Market
Don't think you know the market. When you think the market is going higher or is going to go down and you enter to trade to catch on the momentum, the market is watching you.
The moment you do trade, it starts reversing in bearish engulfing or bullish engulfing.
When you heart tells to enter, usually it's not the right time to enter. Just sit back with your hands closed.
Whenever your heart tells you to enter a trade, ask yourself: Is there a logical reason to enter a trade? Is there enough value in my trade? Can I set stop loss?
And if the answer is no: Don't place the trade

# Fixed Position Trade

# No Trading Plan
Don't trade without a plan. Have a fixed plan to exit the market. Don't wait for the market to go higher and higher because that just never happens.  Make a stop loss and the amount you want the return.

# Adjusting Stop Loss
Don't make adjustments to your stop loss. Sometimes it may backfire.

# Itcy Fingers
Don't trade on your emotions and feelings. your feeling and actions are different evey time when you open a chart. This creates inconsistent trading. It will hurt you int he long run. Stop looking for action in the market. If the trade is there, it is ther.