---
---
**Title:** How Do Some People Succeed So Quickly? They Approach Life Like This 
**Source:**  https://medium.com/the-ascent/how-do-some-people-succeed-so-quickly-they-approach-life-like-this-336cb060115f
**Author:** Nicolas Cole
**Type:** #litnote 
**Topics:** [[Success]] 

----
- Prespective
	- It's all about prespective
	- Some see as a loss  a victim and the other a change maker
-  Every single moment, of every single day, you are “practicing” something.
	- You practice something everytime
	- If you are not reading, you are practicing not reading
	- If you criticize and blame others, you are practicing lack of responsibility
	- View your world this way and you will realize every single moment, every single time you are practicing something
	- whatever it is you’re practicing dictates how consciously (or unconsciously) you move toward or away from where it is you actually want to be: whether that’s a destination, a physical place, or an emotional state.
- Comfort, No Baby
	- If something is easy, you've plateaued. You are growing only if it's hard. 
	- Comfort is the sign of stagnancy
	- The moment the path becomes easy, you’ve begun to regress. Doing the same thing you’ve been doing won’t push you any further.
	- Now is not the time to sit back and relax. Hustle work you ass off. Get out of your comfort zone and feel uncomfortable. That's the only way if you want to grow.
- You don't be disciplined, You mind ways to practice discipline
	- The question isn’t, “How can I be more disciplined?”
	- The question is, “How can I practice discipline, right now?”