---
---
**Creator:** [[🧔Dr. Yogi Vikasananda]]
**Source:** https://youtu.be/2h459P4h1xc
**Type:** #litnote 

---

- Engineers spend millions and millions for making ant-sesmic buildings.
- They can build rather normal buildings with less money but its not useful for the long-term.
- Just like the earthquakes, there are adversities that occur in life
- Today you can do whatever you want. You can eat whatever you want, watch whatever you want, You can do whatever you want. 
- But tomorrow is quite different
- If you build a normal life. If you spend your now seeking pleasures, you will be shattered by small adversities that come into your life
- You will be sick. You will be depressed. You will fall apart
---

Magnesium is importatn
Available in green vegetables, grains, banana, etc.
Improves immune system, makes you better

---
Do bad things occasionally. If you don't, it will stop you against your nature.

The people who think themselves as good are the worst. They have the biggest ego. Aahankar


---
Life is given to you for experiment, don't live the same life every single day. Do something new every day. Don't live the same life 1000 times
