---
title: To Kill a Mockingbird
author: Harper Lee
category: Fiction
publisher: Random House
publish_date: 2004
total_page: 307
cover_url: "https://books.google.com/books/content?id=JQGv8eqVMrMC&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 99466732
isbn13: 9780099466734
---
**Title:** To Kill a Mockingbird
**Author:** Harper Lee
**Type:** #litnote #book #todevelop 

---