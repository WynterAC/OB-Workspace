---
---
**Source:** https://perell.com/note/open-mode-and-closed-mode/
**Type:** #litnote 

----
- Beer mode- discover new ideas
- Coffee mode- state of focus
- Coffee mode not easy to defire, not given much importance
- Best ideas come from aliveness. From openesss. From being able to work in loose state