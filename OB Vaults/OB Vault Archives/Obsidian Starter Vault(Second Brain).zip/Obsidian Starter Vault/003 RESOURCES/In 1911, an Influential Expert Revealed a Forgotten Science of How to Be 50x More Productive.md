---
---
**Source:**https://medium.com/accelerated-intelligence/in-1911-an-influential-expert-revealed-a-forgotten-science-of-how-to-be-50x-more-productive-8828f86eb1c9
**Type:** #litnote 

----
- Drop in productivity for too long will cause revolution
- Why can't a person with a laptop do more than people from 1970s?
- Even the significant shifts in history, don't show increaseed productivity
- Productivity paradox
- What we are taught is wrong
- Technology is not the booster of produtivity
- The production process is fires. The gasoline is what accelerates fires
- **Using unoptimized process with quick hacks and tools is shallow productivity**
- 
- Here are the tips:
	- Prioritize your day with a to-do list
	- Break down your tasks into micro-tasks
	- Measure and standardize the time it takes to complete each task


One-third of today's worlds knowledge workers can be reduced, or eliminated. 

- Productivity doesn't makes us machines
- Productivity is good. 


> The more efficient we are at doing our works, the more time we can have for a slow deep living, instead of living based on consumption. 
> 
