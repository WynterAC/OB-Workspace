---
---
**Creator:** David Perell
**Source:** https://www.youtube.com/watch?v=lNJ33ImlZzs
**Type:** #litnote #todevelop 
**Topics:** [[Note Taking]] [[Build a second brain]]

---

- Information uncaptured= information lost
- Capture all the best ideas
- Gives you superhuman powers
- If you read,it = 99% of you work is done. Hit export or save
- Build capturing habit and read intentionally
- There are two types of readers:
	-  Someone who reads everything that comes his way. He doesn't filter information. Reads what someone wants him to read
	- Someone who reads because he is curious. He wants to learn more and want to explore more.
- Create boundaries for internet chaos and what can reach your brain. 
- Save, read, and intentionally save the best ideas.
- Stop reactivity. Don't just read whatever pops up. 
- You can find get quality information if you read reactively.
- Ask yourself if what you are reading makes any sense at all.
- Be a curator. Only allow the best of the best ideas to be stored in your system.
- Don't focus on click-baits.
- You need a mindset shift
	- Treat information as food you eat
	- More food doesn't necessarily means better. Be intentional about what you consume
- Every information has value. you can gain something from everything you read. 
- Having a system can help you get value for your whole life. Only save the best ideas.
- What platfoms to use?
	- Over time you may switch different platforms. It's OK. It's called the evolution of tech.
- What kinds of stuffs to save?
	- Things that inspire you
	- Your personal experiences or ideas
		- When you do something or learn something, take 5 minutes to review and reflect on it. 
		- Adding your personal perspective and ideas gives you an edge over th competition
	- Things that are easily lost
	- Useful information
- Why not use google?
	- The information is not easily retrievable. It is not personalized. It is not as good and as quality as you have when you curate it yourself.
	- 
