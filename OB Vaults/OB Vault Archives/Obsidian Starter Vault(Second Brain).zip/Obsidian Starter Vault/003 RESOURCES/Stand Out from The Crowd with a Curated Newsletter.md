---
---
**Source:** https://www.campaignmonitor.com/blog/email-marketing/curated-email-newsletters/
**Author:** Stand Out from The Crowd with a Curated Newsletter
**Type:** #litnote  
**Topics:** [[Newsletter]] [[Content Creation]] 

----
- Email marketing is the most effective channel
- Requires time and energy to create
- Better way is to create a curated newsletter
- It can drive results for your business
- Include latest news, tops, interesting things you've read
- How to create great curated newsletter
	- Don't try to sell
	- Short and simple
	- Make it compelling to encourage ctr
	- Make it easy to unsubscribe
- Aggregates interesting or popular content around a specific subject
- Find the best of the best materials and pull it together
- Helps to
	- Stay in the top of mind
	- Build thought leadership
	- Share interesting findings and resources
- How to
	- Choose your topic
	- Read stuffs to recommend
	- Align your content curation with your products of goals
	- Build a list with incentive + simple subcribe option
	- Get amazing content to send 
- Read a lot about your chosen topic
- 