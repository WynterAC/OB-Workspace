---
---
**Source:** https://medium.com/the-ascent/decide-where-you-want-to-be-in-10-years-and-get-there-in-6-months-ce390596d76f
**Author:** Vincent Carlos
**Type:** #litnote #todevelop 
**Topics:** [[Goal Setting]] [[Personal Development]]

----
- Could have started your journey alot earlier
- Could have been further ahead than where you are right now
- Not curious
- Don't seek new ideas and ways to do things
- Don't try to figure all on your own
- Want to go fast, have to cut the learning curve
- Read a lot
- Read people and articles and books from them who have done what you are looking to do
- Building and learning on your own will take years
- Became the linkedin top voice in less than 4 months
- Follow the shorter less conventional path
- Seek out new ideas,be curious learn from others and go faster

The penalty of trying to do everything through trial and error is that you will have to achieve everything you’re going to achieve 20 times slower.

Use your time to improve yoursel and learn better instead of trying to figure it all out on your own
