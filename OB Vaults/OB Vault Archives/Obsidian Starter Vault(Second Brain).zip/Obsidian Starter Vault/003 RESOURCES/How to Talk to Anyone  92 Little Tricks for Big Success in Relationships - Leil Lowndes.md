---
title: How to Talk to Anyone 92 Little Tricks for Big Success in Relationships
author: Leil Lowndes
category: Family & Relationships
publisher: Mcgrawhill
publish_date: 2003
total_page: 368
cover_url: "https://books.google.com/books/content?id=LQt6mAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Unfinished
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 007141858X
isbn13: 9780071418584
---
**Title:** How to Talk to Anyone : 92 Little Tricks for Big Success in Relationships
**Author:** Leil Lowndes
**Type:** #litnote #book #todevelop 

---
- You only have 10 seconds to show you are a somebody
	- The exact moment two humans lay eyes on each other has awesome potency. As they say 1st impression is the last impression. How you look and how you move makes more than 80% of someone's first impression. Our brain gets a sixth sense about someone before we even had the time to process the rational thought. People meet with hundreds if not thousands of people everyday. So how can you stand out of the crowd and be an interesting person. Here are the few tips:
		- Smile
			- Smile makes you magically different but a quick smile won't do the required work. There are so many fake smiles that are out there. A big, warm and genuine smile is an asset. Don't smile instantanously when you greet someone. . Look at their face, delay for a second and smile. This makes the other person feel special and the smile was just for them.
		- Eye contact
			- They say your eyes are the personal grenades that have the power to detonate peoples emotions. You can use your eyes as psychological weapons.
			- Exaggerated eye contact can be extremely advantegous, especiall between sexes. When you consciously increase your eye contact, people will feel they have captivated you.
			- Even if you have to look away, do it slowly and reluctantly. If you make your eyes sticky in a conversations, you'll be treated with such a difference
			- Eye contact is an extremely effective technique you can use to communicate better with people you know. But if you use this technique with people you have never met, it might not go as good as you think. Mind that.
		- Posture
			- Your posture is your biggest success barometer. A great posture a heads-up look, a confident smile and a direct gaze protrays you as a winner. 
		- 