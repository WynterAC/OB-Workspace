---
---
**Title:**  The 3 Things that Helped Me Go from Painfully Shy to Confident
**Source:** https://medium.com/the-ascent/the-3-things-that-helped-me-go-from-painfully-shy-to-confident-7d8f884b980
**Author:** Neeramitra Reddy
**Type:** #litnote 
**Topics:** [[Confidence]] [[Personal Development]]

----

I try to avoid conversations, keep a low profile and reside in library. Most of my friends were not the ones whom I wanted to be around. Making others miserable in the name of humor was theri daily routine. Bu it's insane how much change you can feel if you just surround yourself with the right people. Your confidence and self-esteem is elevated automatically.

One question you should ask yourself to find if your surrounding is good or not is this: 
"How do these people make me feel?"

If they don't make you feel excited, inspired or motivated, you should think twice before commiting yourself around them. You don't have to entertain any toxicity.

> Blood-ties don't matter- a positive friend over a toxic relative any day

Confidence is the direct representation of your value and by working on yourself, you increase your value. 
You have to arrive at acceptance with your flaws. The environment you surround yourself with doesn't matter if you don't accept your flaws.
Be proud of your flaws. They are what makes you human.


