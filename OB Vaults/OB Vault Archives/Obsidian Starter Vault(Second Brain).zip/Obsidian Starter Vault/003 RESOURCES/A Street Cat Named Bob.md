---
title: A Street Cat Named Bob
author: James Bowen
category: Biography & Autobiography
publisher: A Thomas Dunne Book for St. Martin's Griffin
publish_date: 2018
total_page: 320
cover_url: "https://books.google.com/books/content?id=-12EuQEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 1250217385
isbn13: 9781250217387
---
**Title:** A Street Cat Named Bob
**Author:** James Bowen
**Type:** #litnote #book #todevelop 

---