---
title: One Up On Wall Street
author: Peter Lynch
category: Business & Economics
publisher: Simon & Schuster
publish_date: 2000
total_page: 304
cover_url: "https://books.google.com/books/content?id=-w6CL62dBn4C&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 743200403
isbn13: 9780743200400
---
**Title:** One Up On Wall Street
**Author:** Peter Lynch
**Type:** #litnote #book #todevelop 

---