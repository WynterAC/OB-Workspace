---
---
**Creator:** David Foster
**Source:** https://youtu.be/ms2BvRbjOYo
**Type:** #litnote #todevelop 
**Topics:** 

---

-  The most obvious and important realities are often the hardest to see and talk about. This is the point of the fish story
- The same experience can mean two totally different things to two different people with different beliefs and experiences
- Learning how to think means being a little less arogant. It measn to have a critical awareness about yourself and your certainities.
- Self-centeredness is our default setting. 
- Whats hard is to be attentive and paying attention to whats infront of you instead of getting hyptonized by whats going inside your head. 
- Learning to think means having some sense of control over how and what you think.
- Being conscious and aware about what you choose to think abobut
- Mind is and excellant servent but a bad master.
- 