---
title: How to Make Money in Stocks
author: William J. O'Neil
category: Business & Economics
publisher: McGraw-Hill Companies
publish_date: 2002
total_page: 288
cover_url: "https://books.google.com/books/content?id=lRH-zfgFKFUC&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 71373616
isbn13: 9780071373616
---
**Title:** How to Make Money in Stocks
**Author:** William J. O'Neil
**Type:** #litnote #book #todevelop 

---