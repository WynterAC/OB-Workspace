---
---
**Source:** http://michaeldsimmons.com/5-hour-rule-if-youre-not-spending-5-hours-per-week-learning-youre-being-irresponsible/
**Type:** #litnote 
**Topics:** [[Learning]]

----
- Learning= best investment of our time
- We spend our lives collecting, spending, lusting after, and worrying about money — in fact, when we say we “don’t have time” to learn something new, it’s usually because we are feverishly devoting our time to earning money, but something is happening right now that’s changing the relationship between money and knowledge.
- Knowledge is incredibly valuable
- Who don't learn are at-risk group.
- Knowledge is the new money. It serves as medium of exchange and store value 
- New technologies are being developed very quickly. so there's a deficit of people with needed skills that creates the potential for high compensation. 
- The faster you learn and master the new knowledge, the more opportunities you explore yourself to.
- Each of us needs to find the right portfolio of books, online courses, and certificate/degree programs to help us achieve our goals within our budget.
- Learning is no longer a luxury. It's a necessity.
- Find the time for reading and learning even if you are really busy and overwhelmed.
- Increase the results you receive from each hour of learning by using proven hacks that help you remember and apply what you learn.