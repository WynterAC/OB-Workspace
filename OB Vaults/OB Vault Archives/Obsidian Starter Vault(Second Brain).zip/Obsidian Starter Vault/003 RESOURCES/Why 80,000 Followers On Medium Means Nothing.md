---
---
**Title:** [The Future Of Digital Writing: Why 80,000 Followers On Medium Means Nothing | by Nicolas Cole | Sep, 2021 | Medium]
**Source:** (https://nicolascole77.medium.com/the-future-of-digital-writing-why-80-000-followers-on-medium-means-nothing-9e1d66c9c2b7)
**Author:** Nicolas Cole
**Type:** #litnote 
**Topics:** [[Writing]] [[Make Money Online]] 

----

Just because your writing doesn't gain any views don't mean you are a bad writer. Your views or the number of followers don't mean shit. Because the performance oa any one individual piece really doesn't matter.

The only thing that's going to win in the battle of writing online is to produce quality content in volume. Nobody knows you even exist until you hit that publish button. 

Algorithms on the different social media and all the other platforms are changing. They are shifting from followers based algorithm to engagement based algorithm. 

Instead of chasing followers, you should be actually building a big beautiful library of quality contennt. 

