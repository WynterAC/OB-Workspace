---
title: Trade Your Way to Financial Freedom
author: Van K. Tharp
category: Business & Economics
publisher: McGraw Hill Professional
publish_date: 2006
total_page: 352
cover_url: "https://books.google.com/books/content?id=_hLzpVIg2sMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 71658130
isbn13: 9780071658133
---
**Title:** Trade Your Way to Financial Freedom
**Author:** Van K. Tharp
**Type:** #litnote #book #todevelop 

---