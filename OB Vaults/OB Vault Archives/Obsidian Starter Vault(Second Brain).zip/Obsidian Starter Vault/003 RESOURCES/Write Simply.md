---
---
**Title:** Write Simply
**Source:** http://www.paulgraham.com/simply.html?ref=refind
**Author:** Paul Graham
**Type:** #litnote 
**Topics:** [[Writing]][[Writing Tips]]

----

Write using simple words and sentences. simple Easy to understand. Readers will deeply engage.

Writing fancy words makes the read do the extra work. You don't be cool.

Non-native english readers are more. 

Writing about difficult topics don't mean you can use difficult words

Simple writing keeps you honest. 

Don't write fancy stuff by accident. 

[[Use simple words in your writing]]