---
---
**Author:** Medium
**Type:** #litnote 

----
- Your articles can't be a good hit if you are just making noise in an empty room
- What's in it for the reader?
- Will they find value in it? Entertainin? Educating? Inspiring?
- Why they spend time with you?
- Don't write solely for pleasure
- Do platform research
- Use time and energy to learn
- 