---
---
**Source:** https://writingcooperative.com/the-key-to-become-a-wildly-successful-writer-with-millions-of-views-is-a-writing-system-583f6b34ed28
**Author:** Tim Denning
**Type:** #litnote 

----
- Writing success doesn't happen by accident
- No system = No success, Failure forever
- **Write every day**
	- Start every how-to- listicles
- **Walk to let ideas marinate**
	- Walk in nature and the articles will write themselves in head
	- Sit down then and brain dump before you forget them
- **Write headlines and dot points before you sit down**
	- Sitting down without a headline and dots means, you are already fucked.
	- Start your car with a full tank not empty tank.
- **Write article blueprints on non-writing days**
- **Hide your phone from yourself**
	- Don't let the dopamine addicted brain see your best friend. Write without a phone in the room. 
- **Be ready to write down ideas**
	- Have a pen and paper or device.
	- Your writing will have more energy when you do. Don't let that vanish
- **Write headlines every single day**
	- Your headlines are the most important part of your writing
- **Read proactively**
	- Read whatever you want. Reading adds new ideas to your existing ideas
	- **Schedule your writing time**
		- There's no writing career without  a writing schedule.
		- Make sure you make one in your calendar

> By designing a system, you design your future life