---
title: Trade Like a Stock Market Wizard How to Achieve Super Performance in Stocks in Any Market
author: Mark Minervini
category: Business & Economics
publisher: McGraw Hill Professional
publish_date: 2013
total_page: 336
cover_url: "https://books.google.com/books/content?id=i5ZdR7mekpEC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 71807233
isbn13: 9780071807234
---
**Title:** Trade Like a Stock Market Wizard: How to Achieve Super Performance in Stocks in Any Market
**Author:** Mark Minervini
**Type:** #litnote #book #todevelop 

---