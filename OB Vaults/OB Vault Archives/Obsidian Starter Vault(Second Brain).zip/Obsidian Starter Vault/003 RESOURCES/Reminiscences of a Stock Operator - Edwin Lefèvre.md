---
title: Reminiscences of a Stock Operator
author: Edwin Lefèvre
category: Business & Economics
publisher: Wiley
publish_date: 2006
total_page: 288
cover_url: "https://books.google.com/books/content?id=1t3IwAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: Reading
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 471770884
isbn13: 9780471770886
---
**Title:** Reminiscences of a Stock Operator
**Author:** Edwin Lefèvre
**Type:** #litnote #book #todevelop 

---