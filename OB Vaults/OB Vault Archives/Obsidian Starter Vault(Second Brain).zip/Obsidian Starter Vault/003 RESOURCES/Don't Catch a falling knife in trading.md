---
---
Entering high leverage trades just because you feel like you're going to double your money is the most irresponsible form of trading. High leverage have more chances of you gettin liquided. Lower your leverage. Save your capital. That's important than anything else in the market.

Catching a knife, especially on a bottomless asset have no real "RR ratio". The risk on a bottomless asset is always **-99%**


----
**Type:** #permanentnote 
**Topics:** [[Trading]]
**Reference:** Nebraskangooner on Twitter during LUNA pulldown


