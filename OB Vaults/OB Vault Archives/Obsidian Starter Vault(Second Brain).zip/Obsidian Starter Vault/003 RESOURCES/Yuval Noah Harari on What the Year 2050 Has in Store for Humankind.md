---
---

**Source:** https://www.wired.co.uk/article/yuval-noah-harari-extract-21-lessons-for-the-21st-century
**Type:** #litnote
**Topics:** [[Future]]

----
- The meaning of being human is changing
- Teach the skill of reinvention to your childrens
- Nothing is certain as of how the world will look like in future
- technology is growing so fast and so fasft
- Education system still focuses on cramming information
- In past it made sense information was scarce. 
- Information was blocked. NO TV, No radio, No Internet. Even the libraries had not much.
- Now you are only at fingertips away for getting the worlds informatoin
- Censors no longer block information rather they are busy spreading misinformation or distracting us with irrelevancies.
- We don't know what skills we will need in the future. 
- The most important one will be to deal with change, to learn new things and to preserve your mental balance in unfamiliar situations. 
- reinvent yourself again and again. 
- Even our mental structures will be saved in clouds
- Algorithms will do everything
- The only certanity is change
- "Who am I" will be the most urgent and complicated question than ever before.
- The harder you work on something, the harder it will be to let go of that thing. 
- Reconnecting neurons and rewiring your synapses is a hard work.
- Holding yourself to one idea for too long makes you leave behind
- To stay relevant, you will need to constantly learn and reinvent yourself
- Teaching to keep mental balance is more important than teaching a physics equation or the cause of the first world war.
- The teachers themselves lack the mental flexibility that today wants because they are the product of the old educational system.
- Almost everybody agrees that no matter the achievements, the educational system is bankrupt. But so far there's not a viable alternative. Certainly not a one that can be implemented in a large skill
- Most of the things that old people will tell you is not a timeless wisdom rather a outdated bias. What they believe about the world is not true. 

In the past, you follow adults not now. The adults don't understand the world.

Technology is not bad. It can help. But its not here to help. The model of internet or especially technology is not to help you.
- Giving too much power to technology gurantees a life of misery.
- If you don't know what you want in life, technology can shape your life and take control.
You will serve technology instead of it serving you.

People are glued to their phones. Who is in control? The more Ai improves, the easier it will be to manipulate humans. 

Coca-cola, facebook, the government, everyone are racking up to hack you. 

They are in a rack to hack you not your smartphone or your computer. We are living in an era of hacking humans. 


Run faster than algorithsms. Get to know yourself before the algorithms know you. Leave all your illusions behind. They are heavy.

