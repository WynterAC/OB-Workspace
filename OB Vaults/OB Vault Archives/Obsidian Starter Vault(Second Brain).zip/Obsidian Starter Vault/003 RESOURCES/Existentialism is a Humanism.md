---
title: Existentialism is a Humanism
author: Jean-Paul Sartre
category: Philosophy
publisher: Yale University Press
publish_date: 2007
total_page: 128
cover_url: "https://books.google.com/books/content?id=IfNqvQXbuk8C&printsec=frontcover&img=1&zoom=1&source=gbs_api"
status: To Read
start_read_date: 
finish_read_date: 
my_rate: 
book_note: 
isbn10: 300115466
isbn13: 9780300115468
---
**Title:** Existentialism is a Humanism
**Author:** Jean-Paul Sartre
**Type:** #litnote #book #todevelop 

---