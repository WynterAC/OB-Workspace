---
---
**Creator:** Eva Keiffenheim
**Source:** https://youtu.be/vgwfkzQ_S9Q
**Type:** #litnote 

---
- 80% of people are not learning effectively
- **Forgetting is essential for learning**
	- Everybody forgets, The forgetting curve
	- Your ability to retain something decrease with time
	- Unless you disturb the forgetting curve
- **learning is more efficient when its hard**
	- Working memory and long-term memory
	- The more you learn, the more you can remember
	- Previously learned knowledge acts as a framework for new learning
	- You can google things but you can't outsource your memory
	- Working memory- 3-5 things
	- You can't process much information
	- Goal is not to remember some random one thing but to remember thousand things which taken together helps to solve problems and make better sense of the world
- **Your long-term memory capacity is vast**