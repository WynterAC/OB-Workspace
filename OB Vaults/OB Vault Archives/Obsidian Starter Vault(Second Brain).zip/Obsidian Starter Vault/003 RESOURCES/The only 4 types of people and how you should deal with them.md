---
---

**Creator: ** [[🧔Dr. Yogi Vikasananda]]
**Source: ** https://www.youtube.com/watch?v=sG1A2oEHiIw
**Type:** #litnote 
**Topics:** [[Communication]] 

---

There are only 4 types of people

The Role Model (punya aatma)
He lives for others. He thinks for others. This doesn't mean he doesn't do anything for himself. He, in himself is content and is helping others in outside. These are the types of people who live for others but also are working on themselves..

Whenever you find this type of man, make him happy. Whenever you can do something, do to make a better relationship with this man. Because whatever he might have, he believes in giving away. He will help you in your life maybe in knowledge, money or in any other matter.

We wil alaways find these 4 types of people infront of us. We should behave accordingly. It will be a difficult process.

Now write down the name of all people you know and categorize them into one type.

The reason why you are failing in human relationship is because you are treating all the people same. You may be avoiding the person whom you need to make happy and you may be trying to make them happy whom you need to avoid.

Going to fishing. want to bait fish? You can't use a piece of pizza burger. you like it. want to capture fish? you use substance as bait which is more dear to fish. And that's worms.
Maybe you don't like it. Even if you don't like worms, you will have to use them as bait.

If you keep on insisting to use bait as something that you love, you will fail miserably.

Use this metamphor in real life. You are a fisherman. Your sole aim is to capture more fishes i.e human. Now don't take me wrong. Think this in a positive way.

If you want to win people and want them to contribute to your success, there is only one way, treat them individually.
You can't treat all of them the same, because it will not work.

There are four types of fishes in the world and to know what to give to whom is immensly valuable.

This is not something that you can get insight of just by reading this post. I want you to write down the names of people you meet on a daily basis and categorize them into the given four types and treat them accordingly. You can also  evaluate yourself in which category you fall into.

Just because blackforest cake is your favorite, you can't give it to an infant baby. Because what he needs in milk not some cake

It is also a way to be truly happy and content with ourselves. Often times, we don't 

Whenever you are meeting new individuals, ask yourself a question, "What type of person is infront of me?"

We are always surrounded by people. Even if you meditate for 2 hours in the morning, you'll be among other people for the rest of your day. 

If you don't treat people right, they will start attacking you not always directly but also indirectly. If you mediated in the morning they'll say, "I don't think you are going anywhere doing meditations, do you. Stop doing this shit "

If you identify the type of person and treat them the right way they'd have said this instead,"My man! I never knew you meditated. I can see changes meditation have done to you."
