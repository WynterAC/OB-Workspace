---
---
**Creator:** [I Lost A Lot Of Money Day Trading, Until I Understood Smart Money Manipulation - YouTube](https://www.youtube.com/watch?v=T2gm3nx4eAU&ab_channel=TheSecretMindset)
**Source:**
**Type:** #litnote #todevelop 
---

- Markets are manipulative in many ways
- Main price movements are funneled down to limited no. of market makers
- They are the ones who determine the market movement.
- They have significant advantage over others
- They have priviliged informations
- The result of smart money is shown in volume and price spread 
- Smart money can create gap ups, gap downs and many other things at your expense
- Good and bad news both are opportunities
- When there's no volume in the market, it means that they are not currently active on the market.
	- Increasing or decrease in price without change in demand means the trend won't continue for long time
- Its the activity of the professional trader that causes noticable changes in the volume not the activity of retail trader.

> Volume is the key, not price

Humans are conditioned to act like a herd. The smart money knows this.

> Greed and fear are the evil emotions that will make us poor in trading.

The market follow some consistent patterns.

- Smart money seduces traders to make trades in the wrong direction.

- You must learnt to play with the players and follow their path.