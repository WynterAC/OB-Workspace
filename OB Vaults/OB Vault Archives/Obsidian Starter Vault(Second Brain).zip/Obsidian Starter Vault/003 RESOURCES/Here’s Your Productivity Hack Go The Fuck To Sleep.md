---
---
**Source:** [](https://thoughtcatalog.com/ryan-holiday/2015/07/heres-your-productivity-hack-go-the-fck-to-sleep/?utm_source=pocket_mylist)
**Author:** Ryan Holiday
**Type:** #litnote 
**Topics:** [[Sleep]] [[Productivity]]

----
- Sleep can't be skimped atleast not for long
- Sleep is the source of all health and energy- Schopenhauer
- People say "sleep when you are dead" like its  some badge of honor to sleep less
- Short-sigheted strategy
- Handle your shit and priorities right 
- Burn yourself in a few years, or play the long-game
- Law of diminishing returns. Their ego and stubborness that keeps them going.
- If you are a security guard or a factory worker, the longer you stay the more you make
- But if you work with your minds, the clearer you think and the better our mental and physical state, the better we will do.
- Best productivity tip: Wake up early: Less distractions. time to focus. you are in contorl.
- Conservation of energy. Never stand up when you can sit down, and never sit down when you can lie down. - Winston Churchill

eff Bezos has said that he’s “more alert and…thinks more clearly” if he gets his sleep and that “I just feel so much better all day long if I’ve had eight hours.”

[[sleep is the best productivity hack]]