---
---
**Source:** https://anthony-moore.medium.com/pretend-your-time-is-worth-1-000-hour-and-youll-become-100x-more-productive-6ab2302b8e8c
**Author:** Anthony Moore
**Type:** #litnote 
**Topics:** [[Time Management]] [[Productivity]]

----
- No one's is gonna value your time as you do
- The hack is about saying no to anything that doesn't excite you or propel you forward in life.
- Don't give you time, attention and efforts to others just because they ask for it.
- Place a high value on your time and act on it
- Make you increadibly valuable and powerful
- Being busy is a form of mental illness- Tim Ferris
- You have to be productive and effective not busy
- If you are busy, watch what you are doing and assess what you are doing
- Life is wasted by doing thankless work for ungrateful takes that don't deserve your time in the first place.
- People who are successful are not busy, they are fouced.
- Intend to invest your time wisely. Don't act on auto-pilot. Think what you are doing before you actually do it. 
- Whatever you do, do with complete focus. 
- Treat yourself as the most expensive thing in the world. If you don't nobody ever will
- Say no to almost everything that comes your way
- Treat yourself and your time well

