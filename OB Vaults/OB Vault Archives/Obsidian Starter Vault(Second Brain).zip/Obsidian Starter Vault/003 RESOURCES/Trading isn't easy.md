---
---
Just because trading is one mouse click away doesn't mean its easy. Its one of the hardest skill to learn. 

Because in trading, you are fighting with yourself. You need to master your mind before you can make money in the market.

You have to learn to control the very emotions that makes us human. Fear and greed. 

----
**Type:** #permanentnote 
**Topics:** [[Trading]]
**Reference:** [[How to Think Like  a Professional Trader]] 

