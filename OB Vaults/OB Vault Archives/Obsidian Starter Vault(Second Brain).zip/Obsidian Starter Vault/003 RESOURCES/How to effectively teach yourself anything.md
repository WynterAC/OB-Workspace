---
---
**Creator:** Artem Kirsanov
**Source:** https://youtu.be/NuTU9YFqZqQ
**Type:** #litnote 
**Topics:** [[Learning]]

---

Metalearning reasearch
- Learning how to learn this subject and how its laid out.
- Know why you want to learn and how you can start
- Research the subject and see what comes over and over again
- Go to wikipedia and see what comes more often. 
- Find the central idea of the subject you want to learn about. 

# How to learn it
Focus 
Directness

