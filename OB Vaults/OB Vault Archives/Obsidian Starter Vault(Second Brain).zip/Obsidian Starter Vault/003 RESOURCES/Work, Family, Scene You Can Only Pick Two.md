---
---

**Source:** [Work, Family, Scene: You Can Only Pick Two - RyanHoliday.net (instapaper.com)](https://www.instapaper.com/read/1459747419)
**Author:** Ryan Holiday
**Type:** #litnote 
**Topics:** [[Work-life Balance]] 

----
- Artists life is about tradeoff
- Work, family or fun. Pick ony two. You can't get all three. If you try you won't get any of it.
- If you want family and work, you have to trade off parties, fancy dinners and night outs with friends.
- You are not an exception. You can't have it all. even if you try you will end up in a burned out mess.
- Say no to a lot of stuffs. Not just the small things but also the big things. Hangouts, dinners, group texts all of them
- It's about tradeoffs. You can't have it all. You have to pick two and move on.
- 