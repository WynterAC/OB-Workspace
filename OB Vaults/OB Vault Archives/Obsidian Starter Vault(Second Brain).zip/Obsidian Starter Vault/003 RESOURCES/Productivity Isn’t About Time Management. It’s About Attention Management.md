---
---
**Source:** https://medium.com/@AdamMGrant/productivity-isnt-about-time-management-it-s-about-attention-management-ce622139b1a5
**Author:** Adam Grant
**Type:** #litnote 
**Topics:** [[Productivity]] [[Time Management]]

----
- Culture obsessed with Productivity
- Read books on getting things on getting things done
- Told that only if you could plan your schedule better, you could reach productivity nirvana.
- Time management is not the solution. It a part of the problem.
- There are only 24 hours in a day. 
- Better option is attention managementL Prioritize people and projects that matter and it won't matter how long anything takes.
- Attention managemet= focusing on getting things done for the right reasons, in right places and at the right moments.
- Productivity struggles are not caused by lack of efficiency rather the lack of motivation.
- Only if you pay attention to why you're are excited about a project and who will benefit from it, you'll naturally be pulled into it by intrinsic motitvation.
- People perform worse on boring tasks. Their focus goes back to intersting tasks disrupting the focus.
- Do a boring task after you have finished a moderately interesting one. Save most exciting task as a reward for afterward.
- If you’re trying to be more productive, don’t analyze how you spend your time. Pay attention to what consumes your attention.
