---
---
**Creator:** Iman Trading
**Source:** https://www.youtube.com/watch?v=4rq-NXRugdE&t=36s
**Type:** #litnote #todevelop 
**Topics:** [[💹Stock Market]] [[Trading]] 

---

- Teach others to learn. If you want to remember something for long time
Memorize things that you don't need for lifetime.
- Knowledge is not understanding. e-mc2.  Do presentations because it will benefit my own learning experience as well as help others.
- 99% trading information is garbage.

- Surprise and Demand
	- Bigger traders and institutional traders not looking at 30 seconds or 5 minutes chart. They look at bigger time frames
	- When price gets too high, big and institutional players traders who actuall move the market sell and when price gets low, they buy.
	- **The Law of Supply**
		- The higher the price of something, more sellers will come.
		- Demand>supply= price up. Supply>Demand. It goes down
	- Volume profiles help you to see the quantity of traders
	- Market is simple. Buy low and sell high. 
	- You don't need to make market complicated. 
	- You don't need an edge or the system to be profitable. 
	- All you need to know is how to follow the shadow of the people and the markets.
	- 1:3 risk reward ratio
	- **Anxiety and Trading**
		- Have a clear plan and it will reduce anxiety
- Supply and Demand
	- The old zones are less significant. **recent zones are more important than the older ones.**
	- **Pay attention to the bigger time frame**
	- Peaks and Valleys
	- ***Strong setups are when there is a fast and large price move up***
- Time-frames
	- Don't overanalyze the market
	- **Use daily hourly or 15 or r minutes for entries**
	- **Use largers time frames to view the trend**
> 	- ***You don't want to become a buyer after a large rally, and you never want to become a seller after a large selloff.***
- *The faster the price leaves a area, the higher probability the price will turn there again.*
- The less time a price stays in a zone, the stronger is the level
- **Stop loss 1 Tick under the demand zone**
- We can be wrong sometimes. 
- Don't overcomplicate trading
- You don't need to know 50 indicators to make money in the market
- **We don't need a cutting edge strategy. We need to be a good follower**