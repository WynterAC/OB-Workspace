---
---
**Title:** [This 10-Minute Routine Will Increase Your Clarity And Creativity |
**Source:**(https://medium.com/mind-cafe/this-10-minute-routine-will-increase-your-clarity-and-creativity-336cb82e3797)
**Author:** Benjamin Hardy
**Type:** #litnote 
**Topics:** [[Productivity]] [[Mindfulness]] [[Creativity]]

----

- Subconscious never rests. 
	- controls all your functions
	- Whatt happens at subconscious level, affects conscious level
	- Direct subconscious mind to create what you seek
- [[Never Go to Sleep Without a Request to Your subconscious]]
	- common practice for famous and successful people 
	- intentionally direct their subconscious
	- Before sleep write things that you're trying to accomplish and meditate on them
	- Ask question related to them. Be more specific. Your subconscious will work when you sleep
- 10 Minutes after waking up
	- tap into subconscious
	- Don't check your phone the second you are awake
	- dump your thoughts and meditate
	- Focus on output that input
	- Write whatever comes down to your mind
	- Practice this skill. Be consistent and automatic at achieving creative brusts.
- designer of the reality. Thoughts- blueprint of the life you are building. Channel your thinking- make goals inevitable to achieve.