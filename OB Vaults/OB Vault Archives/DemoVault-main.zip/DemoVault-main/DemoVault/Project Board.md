---

kanban-plugin: basic

---

## Todo
- [ ] [[; Automate data analysis for email lead data|Automate data analysis for email lead data]]
- [ ] [[; Find startups to invest in|Find startups to invest in]]



## Waiting



## In Progress

- [ ] [[; Read and summarize top 5 copywriting books|Read and summarize top 5 copywriting books]]
- [ ] [[; Course 1|Course 1]]
- [ ] [[; Course 2|Course 2]]
- [ ] [[; Course 3|Course 3]]
- [ ] [[; Q1 2022 Lead Gen with Cold Emails|Q1 2022 Lead Gen with Cold Emails]]
- [ ] [[; Running Plan Q1 2022|Running Plan Q1 2022]]


## Completed



## Discarded





%% kanban:settings
```
{"kanban-plugin":"basic","metadata-keys":[{"metadataKey":"subtitle","label":"","shouldHideLabel":true,"containsMarkdown":true},{"metadataKey":"goal","label":"Goal","shouldHideLabel":false,"containsMarkdown":true}]}
```
%%