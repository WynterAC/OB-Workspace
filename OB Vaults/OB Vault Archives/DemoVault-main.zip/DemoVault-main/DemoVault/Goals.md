---

kanban-plugin: basic

---

## Physical

- [ ] [[2022-02-11 - Run 1000 km in 2022|Run 1000 km in 2022]]


## Knowledge

- [ ] [[2022-02-11 - Learn Python|Learn Python]]
- [ ] [[2022-02-11 - Learn Copywriting|Learn Copywriting]]


## Life

- [ ] [[2022-02-11 - Finish College|Finish College]]


## Professional

- [ ] [[2022-02-11 - Reach $10.000 MRR|Reach $10.000 MRR]]


## Wealth

- [ ] [[2022-02-11 - Invest in startup|Invest in startup]]




%% kanban:settings
```
{"kanban-plugin":"basic","metadata-keys":[{"metadataKey":"Progress","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Target","label":"","shouldHideLabel":false,"containsMarkdown":false},{"metadataKey":"Timespan","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Reason","label":"","shouldHideLabel":false,"containsMarkdown":true},{"metadataKey":"Bar","label":"","shouldHideLabel":true,"containsMarkdown":true},{"metadataKey":"Projects","label":"","shouldHideLabel":true,"containsMarkdown":true}]}
```
%%