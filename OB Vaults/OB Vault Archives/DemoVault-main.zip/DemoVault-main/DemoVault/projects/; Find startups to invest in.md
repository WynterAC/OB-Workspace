---
tags: project
alias:
  - Find startups to invest in
status: Todo
subtitle: Do proper research and look for startups in high-growth areas.
---
%%
Goal:: [[2022-02-11 - Invest in startup|Invest in startup]]
%%

# Find startups to invest in

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 