---
tags: project
alias:
  - Q1 2022 Lead Gen with Cold Emails
status: In Progress
subtitle: Cold email lead generation into sales funnel.
---
%%
Goal:: [[2022-02-11 - Reach $10.000 MRR|Reach $10.000 MRR]]
%%

# Q1 2022 Lead Gen with Cold Emails

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 