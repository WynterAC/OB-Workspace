---
tags: project
alias:
  - Read and summarize top 5 copywriting books
status: In Progress
subtitle: To do learning in public.
---
%%
Goal:: [[2022-02-11 - Learn Copywriting|Learn Copywriting]]
%%

# Read and summarize top 5 copywriting books

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 