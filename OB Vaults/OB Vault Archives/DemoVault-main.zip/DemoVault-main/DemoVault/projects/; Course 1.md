---
tags: project
alias:
  - Course 1
status: In Progress
subtitle: 5th semester course.
---
%%
Goal:: [[2022-02-11 - Finish College|Finish College]]
%%

# Course 1

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 