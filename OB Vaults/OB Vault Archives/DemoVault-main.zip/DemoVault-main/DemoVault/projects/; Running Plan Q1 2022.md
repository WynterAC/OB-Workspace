---
tags: project
alias:
  - Running Plan Q1 2022
status: In Progress
subtitle: Periodic overload running plan for maximizing distance.
---
%%
Goal:: [[2022-02-11 - Run 1000 km in 2022|Run 1000 km in 2022]]
%%

# Running Plan Q1 2022

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 