---
tags: project
alias:
  - Automate data analysis for email lead data
status: Todo
subtitle: Would help immensely in seeing patterns.
---
%%
Goal:: [[2022-02-11 - Learn Python|Learn Python]]
%%

# Automate data analysis for email lead data

## Project Info

## Thoughts 

## Resources

## Review questions

## Tasks
- [ ] 