# Christian's Obsidian Demo Vault
Demo vault for Obsidian stuff by Christian.

This acts as a showcase for various stuff I create or compile with [Obsidian](https://obsidian.md). Enjoy! 

If you liked this, you can buy me a coffee using the sponsor/donation links in the sidebar. This helps me create more stuff🚀. Thank you!

#### Disclaimer
You can use the contents of this vault for whatever you want. If you want to share it, do give proper attribution (link back here). Do not sell or distribute it without my permission.