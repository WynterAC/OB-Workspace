This will explain zotero to obsidian; probably should also mention zotfile. 
Big ticket: need the mdnotes plugin for zotero, better bibtex, zotfile