A template is a file that gets copied into a new note. 

Make a new empty note. 

Select 'insert template'. Right now, your choices are 'atomic note' and 'project note'. 

Your choice will get inserted into the empty note; this will ensure consistency in your note taking. 

If you don't like the headings etc, you can find the templates in the `_templates` folder and can modify them how you like.

## installing from scratch

core plugin
-turn on template
-make a folder in your vault to hold the template
-make a new note there, put in it the material you always want to have appear
- go to template settings (nb **not** _templater_)
- specify the name of the folder
- now when you make a new note, you can hit the 'insert template' button and the material from your template note will copy over