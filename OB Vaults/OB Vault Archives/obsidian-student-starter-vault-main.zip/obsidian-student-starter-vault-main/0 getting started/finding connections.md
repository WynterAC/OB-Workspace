the magic happens through backlinks and outgoing links

the graph is useful

journey plugin will find paths through your work

basic explanation of the idea of atomic notes, zettles etc