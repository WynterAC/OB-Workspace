## How to OCR an image

Assuming that you have configured tesseract correctly (see [[configuring OCR for Windows]] and [[configuring OCR for Mac]]): ^1d3324

- drag and drop an image into the images-for-ocr subfolder
- create a new note in obsidian; with that new empty note the focus,
	- hit the templater icon `<%` and select `ocr-win` if on windows or `ocr` if on mac
	- select your image
	- wait; in a few moments the text should be dumped into your empty note.
