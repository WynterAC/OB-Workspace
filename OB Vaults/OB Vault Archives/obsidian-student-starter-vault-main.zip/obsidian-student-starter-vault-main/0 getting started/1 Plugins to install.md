## Core

A number of the core plugins are switched on by default.

You need to check/turn on the following _additional_ core plugins from the settings menu (the cogwheel icon):

- outgoing links
- daily notes
- templates

## Community plugins 

- if you need to:
	- go to settings, community plugins and turn 'safe mode off'
	- browse the community plugins (or enter in the search bar) for these ones:

- citations
- kanban
- note refactor
- sliding panes (andy's mode)
- templater
- journey (this one is more optional)
