---
title: "The Enchantment of Modern Life: Attachments, Crossings, and Ethics."
authors: "Jane Bennett"
year: 2001
tags: 
date: 01-01-2021
---

The Enchantment of Modern Life: Attachments, Crossings, and Ethics.

[Open in Zotero](zotero://select/items/@bennettEnchantmentModernLife2001)


### Summary

### Own thoughts

### Related topics / notes