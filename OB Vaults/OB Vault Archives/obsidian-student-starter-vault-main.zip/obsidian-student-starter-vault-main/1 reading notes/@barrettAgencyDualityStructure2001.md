---
title: Agency, the duality of structure, and the problem of the archaeological record. In, Archaeological Theory Today
authors: John Barrett
year: 2001
tags: 
date: 
---

Agency, the duality of structure, and the problem of the archaeological record. In, Archaeological Theory Today

[Open in Zotero](zotero://select/items/@barrettAgencyDualityStructure2001)


### Summary

### Own thoughts

### Related topics / notes