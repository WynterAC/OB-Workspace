---
tags: 
date: {{date}}
project: 
---

## main idea

## literature review

- insert links to notes as appropriate here with regular `[[` and `]]` OR embed by putting a `!` in front of the brackets

- add connecting tissue between the notes and embeds. 

## Map of Content 

- add links to notes, make notes, as appropriate here