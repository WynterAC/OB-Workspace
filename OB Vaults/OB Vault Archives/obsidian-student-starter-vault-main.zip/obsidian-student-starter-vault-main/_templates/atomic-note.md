---
tags: 
date: {{date}}
---

## Observation

## Citation

## Own thoughts

## Related topics / notes
