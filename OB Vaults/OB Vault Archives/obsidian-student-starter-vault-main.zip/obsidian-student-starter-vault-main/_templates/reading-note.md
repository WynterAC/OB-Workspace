---
title: " "
authors: "Last name, first name"
year: ""
tags: 
date: {{date}}
project:
---

{{title}}

[Open in Zotero]({{zoteroSelectURI}})


### Summary

### Own thoughts

### Related topics / notes