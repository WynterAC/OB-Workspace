import nltk
nltk.download('stopwords')

import nltk
nltk.download('punkt')

import en_core_web_sm

nlp = en_core_web_sm.load()
