---
tags: sensorium
date: 2021-06-23
project: hist5706-paper1
status: in-progress
due-date: 2021-10-10
---

## main idea

I want to explore how sonification technquies can be used to foster historical consciousness, for #hist5706-paper1

## literature review

+ [[@perryEnchantmentArchaeologicalRecord2019]] might be an excellent place to start, especially where she discusses how enchantment [[moves us towards ethical action]].
+ 
