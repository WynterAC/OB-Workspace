---

kanban-plugin: basic
show-checkboxes: true

---

## To do

- [ ] zotero to obsidian
- [ ] can I also link to a note here? yes I can!  [[importance of enchantment]]
- [ ] and you can have as many kanban boards as you like


## Doing

- [ ] explain the complete workflow


## Done

- [x] write the configuring simple templates note


