---
tags: [timeline, anothertag]
---

# WWII

info goes here

```html
<span 
      class='ob-timelines' 
      data-date='1939-09-01' 
      data-title='WWII' 
      data-class='orange' 
      data-img = '' 
      data-type='range' 
      data-end="1945-09-02-00"> 
</span>
```

anothertag