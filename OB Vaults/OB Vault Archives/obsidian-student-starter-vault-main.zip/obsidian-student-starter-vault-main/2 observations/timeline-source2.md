---
tags: [timeline, anothertag]
---

Info goes here

```html
<span 
      class='ob-timelines' 
      data-date='1945-01-01' 
      data-title='Cold War' 
      data-class='orange' 
      data-img = '' 
      data-type='range' 
      data-end="1992-01-02-00"> 
</span>
```

