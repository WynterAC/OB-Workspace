---
tags: #enchantment
date: 2021-06-16
---

## Observation
Perry argues that fostering a mode of 'enchantment' towards archaeological work can help make the case for why archaeology matters.

## Citation
[[@perryEnchantmentArchaeologicalRecord2019]]

## Own thoughts

The problem with digital work: what makes for an enchanting experience? 

## Related topics / notes
