---
banner: "![[Kitchen.jpeg]]"
banner: "![[Kitchen.jpeg]]"
banner_y: 0.55
cssclass: dashboard
banner_x: 0.5
---
<div class="title">Family Recipes</div>

# Family Favorites
- Kids
	- [Mac n' cheese](https://www.allrecipes.com/recipe/218992/impromptu-mac-and-cheese/)
	- [[Smores]]
	- [[Almond Peanut Butter]] 
	- [Grandma's Banana Bread](https://www.allrecipes.com/recipe/23810/grandmas-banana-bread/)
- NFL Sundays
	- [Nacho cheese deep](https://www.allrecipes.com/recipe/72097/fat-boy-nacho-cheese-dip/)
	- [Jalapeno Popper Wantons](https://www.allrecipes.com/recipe/166991/jalapeno-popper-wontons/)
	- [[Spicy-Sweet Buffalo Popcorn]]

# Recipes to try
- Breakfest
	- [Southwest Breakfast Burritos](https://www.allrecipes.com/recipe/214583/southwest-breakfast-burritos/)
	- [Caramelized French Toast](https://www.allrecipes.com/recipe/24571/caramelized-french-toast/)
	- [Green Eggs And Hash Omelet](https://www.allrecipes.com/recipe/259185/green-eggs-and-hash-omelet/)
- Lunch
	- [Greek Farro Salad](https://www.allrecipes.com/recipe/244326/greek-farro-salad/)
	- [Peanut Butter Noodles](https://www.allrecipes.com/recipe/11835/peanut-butter-noodles/)
- Dinner
	- [Sesame Seared Tuna](https://www.allrecipes.com/recipe/71698/sesame-seared-tuna/)
