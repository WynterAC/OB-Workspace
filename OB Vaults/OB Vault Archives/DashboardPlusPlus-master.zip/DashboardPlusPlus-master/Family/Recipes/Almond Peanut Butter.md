---
banner_x: 0.5
banner_y: 0.55
banner: "![[Kitchen.jpeg]]"
---