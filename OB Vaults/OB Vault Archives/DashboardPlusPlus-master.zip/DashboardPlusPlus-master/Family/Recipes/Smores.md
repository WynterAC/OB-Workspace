---
banner: "![[Smores.jpeg]]"
banner_x: 0.5
banner_y: 0.55
---

# Ingredients
Original recipe yields 4 servings

## Ingredient Checklist
-   4 whole graham crackers, broken into two square halves 
-   2 tablespoons chocolate-hazelnut spread (such as Nutella®) 
-   2 tablespoons marshmallow creme 

## Directions
#  Step 1
    
Spread 1 1/2 teaspoons chocolate-hazelnut spread onto 4 of the graham cracker halves. Spread 1 1/2 teaspoons marshmallow cream onto the remaining 4 graham cracker halves. Press 1 chocolate-hazelnut graham cracker half together with 1 marshmallow cream half. Repeat with remaining graham crackers.