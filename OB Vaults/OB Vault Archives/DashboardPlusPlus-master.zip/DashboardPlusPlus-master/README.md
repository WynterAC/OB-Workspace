# Information
This repository is an Obsidian vault that demonstrates using the Dashboard++ method for organizing and navigating notes. For further details, see this article for a detailed description:

* [Dashboard++ — a simple organization and navigation method for Obsidian Vaults](https://tfthacker.medium.com/dashboard-a-simple-organization-and-navigation-method-for-obsidian-vaults-2b1982d023a0)

You can find me on Twitter [@TfTHacker](https://twitter.com/TfTHacker)

Or better yet, watch a video on how to install this from Sergio:

[![](images/YouTubeFromSergio.png)](https://youtu.be/AatZl1Z_n-g)


## Say Thank You

If you are enjoying this solution then feel free to buying me a coffee on [https://ko-fi/TfTHacker](https://ko-fi.com/TfTHacker).

Please also help spread the word by sharing your enthusiasim for this plugin on Twitter, Reddit, or any other social media platform you regularly use. 

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/N4N16TNFD)
