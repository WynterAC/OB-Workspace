---
banner: "https://images.unsplash.com/photo-1635957985447-76f1d2ca2c5a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1469&q=80"
banner_icon: ✨
type: dashboard
description: My 'so-imagined' dream life...
banner_x: 0.5
---

---
**Tags**:: #dashboard
**Links**::[[📰 Dashboard]]

---

<div
  style="
    width: 80%;
    height: 100px;
    font-size: 64px;
    background: rgb(242,225,1);  
background: radial-gradient(circle, rgba(242,225,1,0.6) 20%, rgba(231,128,14,0.6) 100%);
    padding-left: 16px;
    border-radius: 16px;
    font-weight: 800;
  "
>
 ✨ Dream Life
</div>

---

<div style="
	 height: 50px;
	 background: rgba(134, 140, 108);
	 font-size: 24px;
	 font-weight: 600;
	 border-radius: 24px;
	 padding-top: 8px;
	 ">☁ What are you doing today to create your dream life?</div>

### In my dream life, I...

- [ ] 1
- [ ] 
---
