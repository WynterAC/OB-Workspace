---
banner: "![[advanced-goal-tracker-banner.jpg]]"
banner_icon: 🗻
type: dashboard
description: Goal tracker Dashboard
banner_y: 0.38667
banner_x: 0.5
---

---
**Tags**:: #dashboard
**Links**:: [[📰 Dashboard]]

---


<div style="
	padding-left: 16px;
	border-radius: 24px;
	border: 2px dashed grey;
	 font-size: 48px;
	 background-color: rgba(17, 233, 248, 0.2);
	 ">🗻 Advanced Goal Tracker</div>


# [[🗻 Advanced Goal Tracker Board]]


## Current Goals
```dataview
TASK
FROM "Life/🗻 Advanced Goal Tracker Board"
WHERE state = "🚧"
```

---
---
