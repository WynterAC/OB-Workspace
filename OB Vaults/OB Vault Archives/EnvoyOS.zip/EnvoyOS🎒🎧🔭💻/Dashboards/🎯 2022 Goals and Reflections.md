---
banner: "https://images.unsplash.com/photo-1507187632231-5beb21a654a2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1501&q=80"
banner_icon: 🌞
type: dashboard
description: My Goals
banner_y: 0.07667
---

---
**Tags**:: #dashboard #life
**Links**::[[⚛️ Life]]

---
# 2022 Goals and Reflections
---

## Fitness/Health
- 1
- 2

---
## Skills

- 1
---
## Learning

- 1

---
## Personal

- 1

---
## Personal Projects

- 1

---
## Academic

- 1
---


# **2022 Growth**

- ### How do you want to feel in 2022?
    - #### 1
- ### What does this year mean to you?
    - #### 1
- ### What are you worried about?
    - #### 1
- ### What do you want to learn more about or develop?
    - #### 1
- ### What are you committed to in 2022?
    - #### 1
- ### What does this day, next year look like?
    - #### 1


---
---
