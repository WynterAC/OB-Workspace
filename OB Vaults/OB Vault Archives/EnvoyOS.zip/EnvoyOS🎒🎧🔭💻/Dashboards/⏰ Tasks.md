---

kanban-plugin: basic
description: Kanban Board for Tasks

---

## ❌ Not Started

- [ ] 💰 English Auction Blog Article<br>[[💰 English Auction]]
- [ ] Flash Minting ERC-20<br>[[Flash Minting ERC-20]]


## 📅 Scheduled



## 🚧 In Progress

- [ ] Listen to Lanny on Tidal
- [ ] 👥 CrowdFund Smart Contract<br>[[CrowdFund Smart Contract]]


## ✅ Completed

- [ ] 🌳 Merkel Tree Blog Article<br>[[🌳 Merkel Tree Whitelist]]
- [ ] Listen Maisie Peters on Tidal
- [ ] 💡 Objects in JavaScript<br>[[Objects]]




%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%