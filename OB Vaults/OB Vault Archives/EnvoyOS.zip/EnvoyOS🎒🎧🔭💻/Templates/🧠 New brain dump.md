---
banner: ""
banner_icon: 
---

---
**Tags**:: #brain-dump
**Links**::[[📰 Dashboard]]

---

<% await tp.file.move("/Life/brain dump/" + tp.file.title) %>

## My wonderful new idea