---
banner: ""
type: notebook
description: notebook description
---

---
**Tags**:: #notebook 
**Links**:: [[📔 Notebooks]]

---

<% await tp.file.move("/Notebooks/" + tp.file.title) %>

---
