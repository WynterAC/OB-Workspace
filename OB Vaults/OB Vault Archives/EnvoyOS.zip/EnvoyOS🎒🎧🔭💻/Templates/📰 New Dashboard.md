---
banner: ""
banner_icon: 
type: dashboard
description: A basic structure file that can be used to create dashboards
---

---
**Tags**:: #dashboard
**Links**::

---
<% await tp.file.move("/Dashboards/" + tp.file.title) %>

## Dashboard Info

You can [[👩‍🌾 Gardening Tips/🪴 Sowing Your Garden/🎯  Create Custom Dashboards|🎯 Create Custom Dashboards]] easily using the `dataview` plugin and SQL-like query language.

---
