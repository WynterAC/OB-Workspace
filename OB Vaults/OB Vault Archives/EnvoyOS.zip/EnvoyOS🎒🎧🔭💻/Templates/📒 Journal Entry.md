---
banner: ""
---

---
**Tags**:: #journal
**Links**:: [[📒 Journal]]
**Topic**::

---

# Entry <% tp.date.now("DD-MM-YYYY") %>
<% await tp.file.move("/Journal/" + tp.file.title) %>

---
