---
banner: ""
type: artist
---
---
**Name**::
**album**:: 
**genre**:: 
**Tags**:: #artist 

---
<% await tp.file.move("/Notebooks/My Favorite Artists/" + tp.file.title) %>

### Back to [[🎵 My Favorite Artists]]
