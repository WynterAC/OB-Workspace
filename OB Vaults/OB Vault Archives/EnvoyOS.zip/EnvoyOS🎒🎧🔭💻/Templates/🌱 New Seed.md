---
type: idea
description: 
---

---
**Tags**:: #idea #knowledge-management 
**Links** ::[[🪴 Grow Room]]

---
<% await tp.file.move("/Seed Box/" + tp.file.title) %>
## What is your next great idea?


