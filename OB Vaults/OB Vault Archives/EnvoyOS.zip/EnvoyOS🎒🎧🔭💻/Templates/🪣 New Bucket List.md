---
banner: ""
type: bucket-list
---

---
**Tags**:: #bucket-list
**Links**:: [[🪣 Bucket List]]
**stage**::
**why**::

---

<% await tp.file.move("/Life/Bucket List/" + tp.file.title) %>

---
