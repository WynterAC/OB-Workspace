---

kanban-plugin: basic
description: Goal Tracker

---

## 🆕 New Goals



## 🏁 Started



## 🚧 In Progress

- [ ] Complete Obsidian Vault<br>[state:: 🚧]


## ✔️ Completed



## ⏸️ On Hold





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%