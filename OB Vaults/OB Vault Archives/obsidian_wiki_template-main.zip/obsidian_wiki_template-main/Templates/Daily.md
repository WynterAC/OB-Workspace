- `Date:` {{title}}
- `Reviewed Date:`
- `Status:`

---

## Temporary Notes or Excerpts
- 

## Thoughts
- 

## People and Organizations
- 

## Papers and Books
- 

## Articles, Videos and Podcasts
- 

## My Projects
- 

## Software Tools
- 

## Colorful Life
- 

## Terms to Learn
- 

## Language


## TODO
	Add todo tags to show on the todo list. Move project todos to My Projects when prepared.

- [ ] 