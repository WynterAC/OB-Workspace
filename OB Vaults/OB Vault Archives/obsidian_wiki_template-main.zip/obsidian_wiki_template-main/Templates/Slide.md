# {{title}}

Speaker: Wei Wang
Date: {{date}}

---

## SUBTITLE

<div style="width: 100%;">
	<!-- THE LEFT COLUMN -->
		<div style="width: 48%; float: left; margin-right: 4%;">
			<p>- Level 1</p>
			<p>&nbsp &nbsp - Level 2</p>
			<p>&nbsp &nbsp &nbsp &nbsp  - Level 3</p>
		</div>
	<!-- END THE LEFT COLUMN -->
	
	<!-- THE RIGHT COLUMN -->
		<div style="width: 48%; float: left;">
			<p>Add other things</p>
			<p>Add other things</p>
			<p>Add other things</p>
		</div>
	<!-- END THE RIGHT COLUMN -->
</div>

---

Thank you for Listening!

---

- `Tags:`
- `Keywords:`
- `Subject:`
- `What for:`
- `Presented Date:`
- `Status:`