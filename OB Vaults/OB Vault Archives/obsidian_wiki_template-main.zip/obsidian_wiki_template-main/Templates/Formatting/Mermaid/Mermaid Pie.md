```mermaid
pie
    title Key elements in Product X
    "Calcium" : 42.96
    "Potassium" : 50.05
    "Magnesium" : 10.01
    "Iron" :  5
```

[mermaid live editor](https://mermaid-js.github.io/mermaid-live-editor/)
