<details>
	<summary>Outline</summary>
	Details
</details>