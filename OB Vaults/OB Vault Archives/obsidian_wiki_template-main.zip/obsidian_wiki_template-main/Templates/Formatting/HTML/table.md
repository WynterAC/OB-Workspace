| xxxx | xxxx |
| ---- | ---- |
| xxxx | xxxx |

<table>
  <tr>
    <th rowspan="2">Worker</th>
    <th>Monday</th>
    <th>Tuesday</th>
    <th>Wednesday</th>
  </tr>
  <tr>
    <td>xx</th>
    <td>xx</th>
    <td>xx</th>
  </tr>
</table>