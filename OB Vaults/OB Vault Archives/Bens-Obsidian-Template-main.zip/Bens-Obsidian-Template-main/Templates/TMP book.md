# <% tp.file.title %>

links: [[📚 Books]]
Typ: #📚  
Author: [[@]]
published: [[]]
started: 
finished: 

# What is the book about?
# What is the Problem?
# Quotes
# Questions
# Interesting mentions
# Notes