📅 [[<% tp.date.now("YYYY") %>-W<% tp.date.now("WW") %>]]
## Work Log:
### Tasks
#### ToDo

#### Working on

#### Done

---
### Meeting Notes
#### Daily


--- 
## Notes


