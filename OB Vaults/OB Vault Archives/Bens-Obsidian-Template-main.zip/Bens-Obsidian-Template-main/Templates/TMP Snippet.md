#🧰
🔗:
🏷️: [[Snippets]]
📅: [[<% tp.date.now("YYYY-MM-DD") %>]] 

# <% tp.file.title %>

### Notes


### Code

```


```