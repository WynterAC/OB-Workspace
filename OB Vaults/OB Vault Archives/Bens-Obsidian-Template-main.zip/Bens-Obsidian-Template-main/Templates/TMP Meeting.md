📅: [[<% tp.date.now("YYYY-MM-DD") %>]]
🧍🧍‍♂️: 
🏷️: #📆

## ✔️ToDos

## 📓 Notes
