📅: [[2021-01-01]]
🧍🧍‍♂️: [[@Steffi]]
🏷️: #📆 [[P Garden]]

## ✔️ToDos
- [ ] drive to [[@Steffi]] and borrow wheelbarrow

## 📓 Notes
The path needs to be redone and the lawn mown.
To carry stones for the path I can get a whelbarrow from Steffi.
