#🗺️ 🔗:[[000 📇Index]]
# 📚 Books

## currently reading
```query
tag:reading
```

## read ToDo
```query
tag:read tag:todo
```

## read
```query
tag:read
```


## Want to read

### Productivity / Self Improvement
[[Checklist Manifesto: How to Get Things Right]] 
[[Essentialism: The Disciplined Pursuit of Less]] 

### Novels
[[1984]]