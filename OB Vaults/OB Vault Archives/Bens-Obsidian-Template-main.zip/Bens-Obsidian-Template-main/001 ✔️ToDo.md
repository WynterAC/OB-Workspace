#📇 [[000 📇Index]]
# ✔️ToDos

## Open Tasks in Vault
```query
task-todo:"" 
```

## Notes that have to be worked on
```query
tag:todo
```


## Inbox
- [ ] Do stuff  📆: [[2021-01-02]] ✔️: 

## Have ToDo

## Want ToDo

## Done
- [x] Prepare Meeting  📆: [[2021-01-01]] ✔️: [[2021-01-01]]