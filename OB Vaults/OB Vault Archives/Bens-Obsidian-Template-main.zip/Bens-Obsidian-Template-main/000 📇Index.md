# 📇 Index
This is the entry point and central point of the vault.

## 📋Lists
[[001 ✔️ToDo]]
[[002 💭Top of Mind]]
[[090 🔖Bookmarks]]
[[091 🔖Read Later]]


## 🗺️ Maps
[[🔍Interessts]]
[[🧑People]]
[[📓Study Notes]]
[[🤹Projects]]
[[📚 Books]] 

## Sources
When clicked on the tag it appears in the search.

#🌍/🎬 video / youtube / movie 
#🌍/💻 website / blog
#🌍/🎧 podcast
#🌍/📖 magazine article
#🌍/📃 scientific papers 
#🌍/📅 events / presentations / workshops / weninars etc.


## 📅Journal
[[2021]]
