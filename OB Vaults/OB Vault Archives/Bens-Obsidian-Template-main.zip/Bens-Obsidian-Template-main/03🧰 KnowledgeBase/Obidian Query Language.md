#🧰
🔗: [[Obsidian]]
🏷️: [[Snippets]]
📅: [[2021-06-02]] 

# Obidian Query Language



```query
tag:#todo
```

```query
path:Journal
```