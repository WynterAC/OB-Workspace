#🤹 

# Garden
## People involved
[[@Steffi]], can help carry things 

## ToDos
- [ ] get rid of weeds
- [ ] mow the lawn
- [ ] repair path

## Notes
This red tree is nice

![](https://upload.wikimedia.org/wikipedia/commons/b/b0/NLS-Garten_4.JPG)

## Links
[Robotic lawn mower - Wikipedia](https://en.wikipedia.org/wiki/Robotic_lawn_mower)

## Meetings
```query
[[P Garden]] tag:#📆
```

## Other mentions
```query
[[P Garden]] -tag:#📆
```