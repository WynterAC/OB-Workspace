#📇 [[000 📇Index]]

# 💭 Top of Mind
What goes on in my head and I don´t want to forget it.

---

📆[[2021-01-01]]  I like oat milk. How is it made? Can I make it myself?
