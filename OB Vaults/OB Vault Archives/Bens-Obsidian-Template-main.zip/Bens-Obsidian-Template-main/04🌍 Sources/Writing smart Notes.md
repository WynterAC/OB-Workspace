#🌍/💻 
🔗: [[Notes]]
🏷️: [[How to Take Smart Notes – One Simple Technique to Boost Writing, Learning and Thinking – for Students, Academics and Nonfiction Book Writers]]
📅: [[2021-01-01]]
🧑: [[@Curtis McHale]]
🌍: [How to Take Smart Notes - YouTube][https://www.youtube.com/watch?v=uCrWIanRYnM]

# Writing smart Notes
## Notes

There are 3 types of notes
1. **Fleeting Notes**
Articels [[📃Source Notes]] Ideas, thoughts that come up. Saved in your inbox / daily notes.

2. **Literature notes**
Notes you take from books.

3. **Permanent Notes** 
Describe the ideas and concepts in you own words, inspired by your fleeting notes. [[📃bit notes]]
No copy and paste!

4. Topic Notes
Notes that contain multiple ideas / concepts from your permanent notes.

Write short and expressive notes.
