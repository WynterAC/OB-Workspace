 #🌍/🎬 
🔗: 
🏷️: [[📚 Books]] #todo write notes
📅: [[2021-06-04]] 
🧑: [[@WheezyWaiter]]
🌍: https://www.youtube.com/watch?v=3mKmyPDm0Sg

# How to read more books

## Notes

1. WHY?
	1. Good books are good
	2. Learning
	3. Helps finding sleep
	4. relaxes
	5. creative inspiration
	6. change in perspective
2. Have a book everywhere
3. Read multiple
4. have a book ready before finishing one
5. read a little bit at a time
6. Quit often
7. Grab a book instead of phone
8. Learn how to find a good book
9. Read on every occation
10. Have a book beside your bed, read first thing, last thing day
11. Audiobooks / wokout etc. Biographies best

