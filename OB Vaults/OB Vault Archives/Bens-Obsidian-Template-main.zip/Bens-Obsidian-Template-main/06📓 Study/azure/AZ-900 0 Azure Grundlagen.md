[[📓Study Notes]]  Azure AZ-900
https://docs.microsoft.com/de-de/learn/paths/az-900-describe-cloud-concepts/

# [[Azure]] Grundlagen Teil 1: Beschreiben der wichtigsten Azure-Konzepte
## [[AZ-900 1.1 Einführung in Azure-Grundlagen]] ✔


