#🗺️ 🔗: [[000 📇Index]]
# 🧑People


```query
tag:🧑 -path:"Templates"
```