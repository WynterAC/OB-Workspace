# @Niklas Luhmann 
#🧑
Company: -
Titel: -

---

# Notes
Inventor of the [[Zettelkasten System]].

# Links
```query
[[@Niklas Luhmann]]
```