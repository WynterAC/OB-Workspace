#💡
🔗: [[Notes]] [[📃note type]] [[📃literature notes]]

# Source Notes
When I find an interesting piece of information it gets saved as  #🌍 [[📃Source Notes]] with some initial notes and remarks. This notes are also categorized by there type / where they come from.
#🌍/🎬 video / youtube / movie 
#🌍/💻 website / blog
#🌍/🎧 podcast
#🌍/📖 magazine article
#🌍/📃 scientific papers 
#🌍/📅 events / presentations / workshops / weninars etc.


## Template
filename: Title
#🌍 <-- note type with sub category
🔗:  <--- what bit does it links to?
🏷️:  <--- what is also related to this?
📅: <--- link to the current day / daily note
🧑:  <--- who is the creator / author?
🌍: <--- weblink

# Title <--- title same as filename

## Notes <-- here goes the content