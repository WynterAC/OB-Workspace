#💡
🔗: 

# Permanant Note

See [[Atomic Notes]]

--- 
Source: