#💡
🔗:  [[Obsidian]] [[IT]]

# Markdown
Markdown is a lightweight markup language for creating formatted text using a plain-text editor.
See [[Markdown Demo]]
Charts can be made with [[Mermaid Flowcharts Demo]]