#🗺️  🔗:[[🔍Interessts]]

# IT

- [[Cloud]]
	- [[Azure]]
	- [[AWS]]
[[Markdown]]
[[Backup]]


## Web

## Software
[[Obsidian]]

## Coding


### Snippets
```query
[[Snippets]]
```