#🗺️  🔗:[[🔍Interessts]]

# Science

[[Astrononmie]]
[[Physik]]
[[Mathematik]]
[[Biologie]]

