#💡
🔗:  [[Notes]]

# Daily Notiz
Daily Notes sind produktive Notizen.
Sie werden verwendet um den Tag zu dokumentieren und zu planen.
Hier werden zu erledigende und erledigte Aufgaben abgelegt.
Generelle Notizen und Meeting Notizen festgehalten. Die Daily Notes sind angepinnt und immer offen um umgehend neue Tasks hinzufügen zu können oder Notizen zu schreiben.

---
## Template
filename: year-month-day, [[2021-01-01]]

 📅 [[2021-W22]] <--- current week
## Work Log:
### Tasks
#### ToDo <--- open tasks
 - [ ] open to do 
#### Working on <--- currently working on
- [ ]  working on
#### Done <--- finished tasks
- [x] finished task
---
### Meeting Notes
#### Daily


--- 
## Notes





### a word on tasks
Obsidian as a feature to search for tasks, open or done, see in  [[001 ✔️ToDo]].
I don´t want the moved tasks to show up there, but for journaling / logging reasons I still want to see what was done / on the ToDo list that day. So unfinished tasks don´t get deleted from the daily notes, they get moved to the next day and marked with an M so the search for open tasks don´t shows them in all the old notes multiple times.

- [ ] Open Task
- [x]  Done Tasks
- [M]  Task moved to next day
- [C]  canceled task