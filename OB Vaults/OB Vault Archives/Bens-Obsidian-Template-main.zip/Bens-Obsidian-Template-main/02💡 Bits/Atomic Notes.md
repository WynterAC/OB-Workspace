#💡
🔗: [[Notes]] [[Schreiben]] [[Writing smart Notes]]

# Atomic Notes

Notes broken down in to one topic. Also see [[📃bit notes]]
In the  [[Zettelkasten System]] also known as [[Permanant Note]].

--- 
Sources: [[How to Take Smart Notes – One Simple Technique to Boost Writing, Learning and Thinking – for Students, Academics and Nonfiction Book Writers]]