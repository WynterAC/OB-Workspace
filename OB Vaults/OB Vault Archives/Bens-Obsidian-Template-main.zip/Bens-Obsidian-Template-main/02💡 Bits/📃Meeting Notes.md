#💡
🔗: 

# 📃Meeting Notes
Here I track the meetings with.
Who was there, what where the topics, what has to be done?

--- 
Source:

---
## Template
filename: date topic

📅: [[<% tp.date.now("YYYY-MM-DD") %>]] <--- date of the meeting
🧍🧍‍♂️: <--- who is with me in the meeting
🏷️: #📆 <--- where is this meeting related to, project / topic...

## ✔️ToDos <--- what doings came up?

## 📓 Notes <--- what was discussed?
