#💡
🔗:  [[Notes]]

# Zettelkasten System

Zettelkasten is a note taking system by [[@Niklas Luhmann]].
It breaks down ideas and concepts into small bits that fit on a index card and links them together.

--- 
Source:
[[How to Take Smart Notes – One Simple Technique to Boost Writing, Learning and Thinking – for Students, Academics and Nonfiction Book Writers]]
[My Digital Note-Taking System | Idea Storage and Idea Factory - YouTube ](https://www.youtube.com/watch?v=8hbGweed6-E)
[How to Take Smart notes - YouTube ](https://www.youtube.com/watch?v=uCrWIanRYnM)
[What Makes A Good Zettelkasten Note - YouTube](https://www.youtube.com/watch?v=Q4JqjbQZ6_Q)