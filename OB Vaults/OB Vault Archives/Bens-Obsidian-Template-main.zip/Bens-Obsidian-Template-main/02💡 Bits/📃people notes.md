#💡
🔗: 

# 📃people notes
Here I take notes of people I want to remember.
Creators, Authors, people I work with...

--- 
Source:

---
## Template
filename: @Name Lastname
# Name Lastname <--- who is it?
#🧑 <--- note type
Company: <--- where does the person work?
Titel:  <--- what is the title?

---

# Notes <--- thinks I want to remember


# Links <--- where is this person mentioned
```query
[[📃people notes]]
```