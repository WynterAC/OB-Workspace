#💡
🔗:  [[Writing smart Notes]] [[Zettelkasten System]]


# Notes
Notes are recordings of text.
In [[Obsidian]] I have multiple [[📃note type]]s.

## Links
[Link 1](https://joshwin.imprint.to/post/how-i-use-obsidian-to-manage-my-goals-tasks-notes-and-software-development-knowledge-base)

