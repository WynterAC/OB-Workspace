#💡
🔗:  [[📃note type]]

# 📃literature notes
All the books I read have a literature note. Here I summarize the contents, make notes/remarks and save quotes to cite if needed.

--- 
Source:

---
## Template
filename: booktitle
# Title <-- Book title

links: [[📚 Books]] <--- what is it connected with?
Typ: #📚  <--- note type
Author: [[@]] <--- who wrote it?
published: [[]] <-- when was it published
started:  <-- when did I start reading
finished:  <--- when did i finish that book?

--> the questions come from [[How to read more books]]
# What is the book about?
# What is the Problem?
# Quotes
# Questions
# Interesting mentions
# Notes