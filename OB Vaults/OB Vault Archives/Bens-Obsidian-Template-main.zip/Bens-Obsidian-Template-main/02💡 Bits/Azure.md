#💡
🔗: [[Cloud]]

# Azure

Azure is Microsofts cloud service.

--- 
Sources: