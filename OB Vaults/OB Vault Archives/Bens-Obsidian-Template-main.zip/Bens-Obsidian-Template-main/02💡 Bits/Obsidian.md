#💡
🔗:  [[IT]] [[Tool]] [[Personal Knowledge Management]] [[Zettelkasten System]]

# Obsidian
Obsidian is an awesome tool for personal knowledge management.
It is based on [[Markdown]] files, stored locally on your pc.

--- 
sources: 
https://obsidian.md/
https://help.obsidian.md/Index
https://forum.obsidian.md/
[Obsidian: my new knowledge base or base for knowledge](https://niklasblog.com/?p=25043)
