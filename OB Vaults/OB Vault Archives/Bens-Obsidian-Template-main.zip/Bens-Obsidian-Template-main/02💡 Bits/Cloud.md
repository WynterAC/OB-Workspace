#💡
🔗: [[IT]]

# Cloud

The cloud is just someone elses computer.

## Cloud Services
[[Azure]]

--- 
Sources: