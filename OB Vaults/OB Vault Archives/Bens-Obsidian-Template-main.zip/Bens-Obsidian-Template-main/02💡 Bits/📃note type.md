## Knowledge
[[📃bit notes]]
[[📃Knowledge Base Notes]]
[[📃Source Notes]]
[[📃literature notes]]

## Productivity
[[📃daily notes]]
[[📃Meeting Notes]]
[[📃people notes]]