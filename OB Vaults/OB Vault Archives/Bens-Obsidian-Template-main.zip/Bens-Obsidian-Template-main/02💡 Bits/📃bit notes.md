#💡
🔗:[[Notes]] 

# bit notes
Bit notes contain small bits of information / ideas / concepts, broken down to a single topic.
They are also known as atomic notes or permanent notes.

Sources:
[[How to Take Smart Notes – One Simple Technique to Boost Writing, Learning and Thinking – for Students, Academics and Nonfiction Book Writers]]

---
## Template

#💡  <--- type of note
🔗: <-- what connects to this?

# title <-- title, self explaining ;)
<-- here goes the description

--- 
Source: <-- what are the sources the information came from