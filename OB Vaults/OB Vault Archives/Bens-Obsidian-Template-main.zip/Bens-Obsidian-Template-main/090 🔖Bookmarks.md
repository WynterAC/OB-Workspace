#📇 [[000 📇Index]]
# 🔖Bookmarks
[[091 🔖Read Later]]


## Tools
[Obsidian](https://obsidian.md/)