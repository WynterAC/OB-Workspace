---
summary: 
character: []
pov: 
draft: 
date: <% tp.date.now("YYYY-MM-DD") %>
grammarly: 
is_scene: true
revisions_completed:
---
# <% tp.file.title %>


