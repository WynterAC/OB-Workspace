---
date: <% tp.date.now("YYYY-MM-DD") %>
amount: "{{VALUE:Amount}}"
type: expense
project: "{{VALUE:Project}}"
tags:
  - expenses
submitted: false
---
# [[<% tp.file.title %>]]
