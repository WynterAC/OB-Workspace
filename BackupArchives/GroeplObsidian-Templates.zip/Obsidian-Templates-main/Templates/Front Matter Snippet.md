---
tags: type/note
aliases: 
lead: +++ Lead paragraph goes here +++
visual: "![[image.jpg]]"
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
template-type: Frontmatter
template-version: "1.7"
---