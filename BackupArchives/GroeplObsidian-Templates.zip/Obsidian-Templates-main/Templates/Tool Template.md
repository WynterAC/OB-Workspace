---
tags: type/tool type/term 
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
lead: +++ Term definition goes here +++
visual: "![[image.jpg]]"
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Tool
template-version: "1.8"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!-- Short description of TOOL goes here -->



## Usage
<!-- Why I am using this tool? The use case -->

It is a preferred tool to …

Here are my pros and cons from this use case:


## Pros
-  


## Cons
- 

---
# Back Matter
## Source
<!-- Always keep a link to the source- --> 
- 

## Tasks
<!-- What remains to be done with this note? --> 
- 

## References
<!-- Links to pages not referenced in the content -->
- 
