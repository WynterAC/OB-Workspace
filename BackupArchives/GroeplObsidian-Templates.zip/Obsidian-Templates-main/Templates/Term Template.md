---
tags: type/term
aliases: 
lead: +++ Term definition goes here +++
source: +++ source undefined +++
visual: "![[image.jpg]]"
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
template-type: Term
template-version: "1.11"
---

# {{Title}}

<!-- Term definition and source from frontmatter goes here. Also used for Dataview glossary. -->

> [!Definition]
> `= this.lead`
>  — `= this.source`

<!-- Additional term description if needed -->


---
# Back Matter
## Source
<!-- Always keep a link to the source- --> 
- 

## Tasks
<!-- What remains to be done with this note? --> 
- 

## References
<!-- Links to pages not referenced in the content -->
- 

## Template Help
<!-- Links to external help pages on GitHub. -->
- [Basic Template Structure](https://github.com/groepl/Obsidian-Templates#basic-template-structure)
- [How to Use Links](https://github.com/groepl/Obsidian-Templates#how-to-use-links)
- [How to Use Tags](https://github.com/groepl/Obsidian-Templates#how-to-use-tags)
- [How to Search Notes](https://github.com/groepl/Obsidian-Templates#how-to-search-notes)
- [Plugins Needed](https://github.com/groepl/Obsidian-Templates#obsidian-plugins-needed)
- [Find Latest Updates](https://github.com/groepl/Obsidian-Templates)

