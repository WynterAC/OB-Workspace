---
tags: type/structure structure/bujo
# --- Learn more about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases: 
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: BuJo Weekly
template-version: "1.3"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}


![[{{monday:gggg-MM-DD}}]] 
![[{{tuesday:gggg-MM-DD}}]] 
![[{{wednesday:gggg-MM-DD}}]] 
![[{{thursday:gggg-MM-DD}}]] 
![[{{friday:gggg-MM-DD}}]] 
![[{{saturday:gggg-MM-DD}}]]
![[{{sunday:gggg-MM-DD}}]]