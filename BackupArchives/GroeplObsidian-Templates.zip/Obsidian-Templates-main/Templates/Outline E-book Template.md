---
tags: type/chapter target/ebook 
aliases:
title_short: "e1"
chapter: "0.0"
version: "0.1"
book_version: 0.18
status: draft
word_count: 0
feedback: 0
bar: <progress max=100 value=0></progress><br>0% first ideas
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
published:
template_type: Ebook
template_version: "1.12"
---
<!--  
status: draft, final, published, revised 
bar: <progress max=100 value=0></progress><br> 0% first ideas 
		10% takeaway promised, 20% used for teaching, 30% value offered  
		40% front-loaded value, 50% high value-per-page, 60% value tested
		70% feedback received, 80% value improved, 90% finally polished, 100% recommended 
-->

# {{Title}} - e1

```dataviewjs 
var progress_bar = (dv.current().bar);
var note_status = (dv.current().status);
dv.paragraph(progress_bar + ', ' + note_status);
```

<!-- Main content of this chapter -->
. 


---
# Back Matter
## Tasks
<!-- What remains to be done do get the final version? --> 

- [ ] Prepare final version 
- [ ] Publish on GitHub
- [ ] Review and revise

## Feedback
<!-- What remains for you to consider in the draft version? --> 
**0.14**
- 

## Table of Content
<!-- Links to chapters from e-book -->
- [Contents - e1](Contents%20-%20e1.md)


## References
<!-- Links to pages not referenced in the content -->
- 

## Template Help
<!-- Links to external help pages on GitHub. -->
- [Basic Template Structure](https://github.com/groepl/Obsidian-Templates#basic-template-structure)
- [How to Use Links](https://github.com/groepl/Obsidian-Templates#how-to-use-links)
- [How to Use Tags](https://github.com/groepl/Obsidian-Templates#how-to-use-tags)
- [How to Search Notes](https://github.com/groepl/Obsidian-Templates#how-to-search-notes)
- [Plugins Needed](https://github.com/groepl/Obsidian-Templates#obsidian-plugins-needed)
- [Find Latest Updates](https://github.com/groepl/Obsidian-Templates)










