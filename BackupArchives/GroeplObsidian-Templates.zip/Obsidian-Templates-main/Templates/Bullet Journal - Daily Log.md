---
tags: type/structure structure/bujo
aliases: 
tasks: 1
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
template-type: BuJo Daily
template-version: "1.5"
---

## Tasks