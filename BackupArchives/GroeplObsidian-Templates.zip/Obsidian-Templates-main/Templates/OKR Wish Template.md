---
tags: okr/wish
# --- More about "How to use tags": https://forum.obsidian.md/t/how-to-use-tags/
aliases:
lead: +++ Lead paragraph goes here +++
visual: "![[image.jpg]]"
# --- Install plugin: https://github.com/blacksmithgu/obsidian-dataview
created: {{date}}, {{time}}
modified: {{date}}, {{time}}
# --- Install plugin: https://github.com/beaussan/update-time-on-edit-obsidian
template-type: Note
template-version: "1.1"
# --- Find latest updates: https://github.com/groepl/Obsidian-Templates
---

# {{Title}}

<!--  Main idea of my thoughts -->

> [!Note]
> `= this.lead`

<!-- Other content of my note  -->


---
# Back Matter
## Source
<!-- Always keep a link to the source- --> 
- 

## Tasks
<!-- What remains to be done with this note? --> 
- 

## Questions
<!-- What remains for you to consider? --> 
- 

## Terms
<!-- Links to definition pages. -->
- 

## References
<!-- Links to pages not referenced in the content. -->
- 