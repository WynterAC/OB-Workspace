<%_* 
tp.user.qxx_script().removeEmptyLine()
//avoid lost data
tR += tp.file.selection();
_%>