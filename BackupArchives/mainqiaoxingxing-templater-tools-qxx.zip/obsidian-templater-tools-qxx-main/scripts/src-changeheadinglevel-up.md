<%_* 
tp.user.qxx_script().changeHeadingUp()
//avoid lost data
tR += tp.file.selection();
_%>