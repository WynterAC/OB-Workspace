<%_* 
tp.user.qxx_script().toggleUL()
//avoid lost data
tR += tp.file.selection();
_%>