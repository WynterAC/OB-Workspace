<%_* 
tp.user.qxx_script().changeHeadingDown()
//avoid lost data
tR += tp.file.selection();
_%>