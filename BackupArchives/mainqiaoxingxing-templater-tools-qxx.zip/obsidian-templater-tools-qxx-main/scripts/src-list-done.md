<%_* 
tp.user.qxx_script().toggleListDone()
//avoid lost data
tR += tp.file.selection();
_%>