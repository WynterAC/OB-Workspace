<%_* 
tp.user.qxx_script().startup(tp);
_%>