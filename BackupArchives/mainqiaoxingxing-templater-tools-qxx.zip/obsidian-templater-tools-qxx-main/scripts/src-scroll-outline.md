<%_* 
tp.user.qxx_script().scrollToOutline()
//avoid lost data
tR += tp.file.selection();
_%>