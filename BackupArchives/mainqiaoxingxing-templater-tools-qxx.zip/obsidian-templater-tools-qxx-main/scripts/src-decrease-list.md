<%_* 
tp.user.qxx_script().decreaseIndentOfList()
//avoid lost data
tR += tp.file.selection();
_%>