# My Obsidian Setup
## Description
A place to store and share some of my templates, scripts. snippets, and other files I use in Obsidian.

## Disclaimer
Some of my snippets include moddified snippets created by others, such as (but not limited to)
- [DashboardPlusPlus](https://github.com/TfTHacker/DashboardPlusPlus)
- [MinerBanner](https://github.com/KuiyueRO/Obsidian-Miner/blob/main/md/MinerBanner.md)
- [Checkboxes Origami Theme](https://discord.com/channels/686053708261228577/702656734631821413/1110960596129681520)
- [Canvas Header Image](https://www.reddit.com/r/ObsidianMD/comments/11n389p/i_made_a_css_snippet_to_give_your_canvas_cards_a/)

## License
Shield: [![CC BY-SA 4.0][cc-by-sa-shield]][cc-by-sa]

This work is licensed under a
[Creative Commons Attribution-ShareAlike 4.0 International License][cc-by-sa].

[![CC BY-SA 4.0][cc-by-sa-image]][cc-by-sa]

[cc-by-sa]: http://creativecommons.org/licenses/by-sa/4.0/
[cc-by-sa-image]: https://licensebuttons.net/l/by-sa/4.0/88x31.png
[cc-by-sa-shield]: https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg