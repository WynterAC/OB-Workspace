# Time of starting dose
- 
# Things to note
- Mood
- Engagement with tasks
- Thoughts
- Appetite
- Physical
- Headaches
- Times of occurrences
# Notes
<% await tp.file.rename(tp.date.now("YYYY-MM-DD"))%>