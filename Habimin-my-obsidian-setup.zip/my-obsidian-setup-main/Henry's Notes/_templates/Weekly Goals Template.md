# This week's objectives
- [ ] 
# Overview
> [!calendar-plus]+ Unscheduled
> ```tasks
> no due date
> group by priority
> ```

> [!calendar-x]+ Overdue
> ```tasks
> ((due before today) AND (not done)) OR (done today)
> group by priority
> ```

