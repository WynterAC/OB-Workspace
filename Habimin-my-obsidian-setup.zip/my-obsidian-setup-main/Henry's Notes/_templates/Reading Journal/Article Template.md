---
title: 
authors: 
publisher: 
source: 
archived-link: 
categories: 
description: 
first-published: ""
status: Not Read
finished-date: ""
tags:
---
# `VIEW[{title}][text]`
By `VIEW[{authors}][text]` from `VIEW[{publisher}][text]`
Original Link: `VIEW[{source}][link]`
Archived Link: `VIEW[{archived-link}][link]`
## Description
`VIEW[*{categories}*][text(renderMarkdown)]`
First published `VIEW[{first-published}][text]`
`VIEW[{description}][text]`
# My Notes
Status: `VIEW[{status}][text]`
Finished `VIEW[{finished-date}][text]`
