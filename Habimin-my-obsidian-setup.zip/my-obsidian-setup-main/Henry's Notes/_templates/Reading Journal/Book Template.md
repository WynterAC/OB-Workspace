---
title: 
subtitle: 
authors: 
categories: 
description: 
pages: 
first-published: ""
cover: _attachments/_book-covers/placeholder.png
status: Not Read
percent-read: 
time-spent-reading: 
dates-last-read: []
rating: 
tags:
---
`VIEW[!\[\[{cover}|200\]\]][text(renderMarkdown)]`
# `VIEW[{title}][text]`
`VIEW[*{subtitle}*][text(renderMarkdown)]`
By `VIEW[{authors}][text]`
## Description
`VIEW[*{categories}*][text(renderMarkdown)]`
First published `VIEW[{first-published}][text]`
`VIEW[{pages}][text]` pages
`VIEW[{description}][text]`
# My Notes
Status: `VIEW[{status}][text]`
Finished `VIEW[{finished-date}][text]`
My Rating: `VIEW[{rating}][text]` out of 5